This directory contains the Derby databases used for the examples. 
They will be created when the examples are run.