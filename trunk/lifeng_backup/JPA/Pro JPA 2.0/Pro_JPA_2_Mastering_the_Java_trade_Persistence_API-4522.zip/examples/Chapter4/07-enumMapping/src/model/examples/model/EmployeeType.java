package examples.model;

public enum EmployeeType {
    FULL_TIME_EMPLOYEE,
    PART_TIME_EMPLOYEE,  
    CONTRACT_EMPLOYEE 
}
