package examples.stateless;

public interface ProjectService {
    public void assignEmployeeToProject(int projectId, int empId);
    public void updateProjectStatistics();
}

