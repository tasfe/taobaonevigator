package examples.stateless;

public interface ProcessingService {
    public void process();
}

