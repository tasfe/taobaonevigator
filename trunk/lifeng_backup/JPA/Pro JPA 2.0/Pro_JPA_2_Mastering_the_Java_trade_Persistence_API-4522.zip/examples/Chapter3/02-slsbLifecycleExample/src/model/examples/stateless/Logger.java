package examples.stateless;

public interface Logger {
    public void logMessage(String message);
}
