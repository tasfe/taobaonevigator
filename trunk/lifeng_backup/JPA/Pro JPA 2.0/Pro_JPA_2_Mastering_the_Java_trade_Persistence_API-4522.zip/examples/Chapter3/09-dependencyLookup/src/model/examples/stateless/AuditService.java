package examples.stateless;

public interface AuditService {
    public void audit();
}

