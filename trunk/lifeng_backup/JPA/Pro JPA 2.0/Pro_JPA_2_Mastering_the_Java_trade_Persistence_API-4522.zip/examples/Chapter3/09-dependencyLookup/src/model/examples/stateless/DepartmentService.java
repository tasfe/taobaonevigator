package examples.stateless;

public interface DepartmentService {
    public void performAudit();
}

