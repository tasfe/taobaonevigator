package examples.model;

public enum PhoneType {
    Home, Mobile, Work
}
