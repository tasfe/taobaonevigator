set feedback off
set heading off
set termout off
set linesize 1000
set trimspool on
set verify off
spool C:\China-Workspace\PaymentGateway\db\drop_objects.lst
SELECT 'DROP ' || OBJECT_TYPE || ' ' || OBJECT_NAME ||';'   FROM USER_OBJECTS
WHERE OBJECT_TYPE <> 'TABLE' AND OBJECT_TYPE <> 'INDEX' AND OBJECT_TYPE<>'PACKAGE BODY' AND 
OBJECT_TYPE<>'TRIGGER'  AND OBJECT_TYPE<>'LOB' AND OBJECT_TYPE<>'SEQUENCE'
UNION ALL 
SELECT 'DROP ' || OBJECT_TYPE || ' ' || OBJECT_NAME ||' CASCADE CONSTRAINTS;'   FROM USER_OBJECTS
WHERE OBJECT_TYPE = 'TABLE';
spool off;