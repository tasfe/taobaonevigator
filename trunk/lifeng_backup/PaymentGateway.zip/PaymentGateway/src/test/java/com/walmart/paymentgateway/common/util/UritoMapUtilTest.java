package com.walmart.paymentgateway.common.util;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
/**
 * Test class for UriToMapUtil
 * 
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class UritoMapUtilTest {

	

	@Autowired
	UriToMapUtil  uriToMapUtil;
	@Test
	public void convertUriToMapWithCDATA(){
		
		String testString = "<![CDATA[http://www.walmart.cn/?body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5]]>";
		Map<String, String> map;
		String input_charset="gbk";
		map = uriToMapUtil.convertUriToMap(testString,input_charset);
		assertNotNull(map);
	}
	@Test
	public void convertUriToMapwithURL(){
		
		String testString = "http://www.walmart.cn/?body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5";
		Map<String, String> map;
		String input_charset="gbk";
		map = uriToMapUtil.convertUriToMap(testString,input_charset);
		assertNotNull(map);
	}
	@Test
	public void convertUriToMapwithQueryString(){
		
		String testString = "?body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5";
		Map<String, String> map;
		String input_charset="gbk";
		map = uriToMapUtil.convertUriToMap(testString,input_charset);
		assertNotNull(map);
	}
	@Test
	public void convertUriToMapwithQueryStringTwo(){
		
		String testString = "body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5";
		Map<String, String> map;
		String input_charset="gbk";
		map = uriToMapUtil.convertUriToMap(testString,input_charset);
		assertNotNull(map);
	}
	@Test
	public void convertUriToMapwithQueryStringThree(){
		
		String testString = "body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5?";
		Map<String, String> map;
		String input_charset="gbk";
		map = uriToMapUtil.convertUriToMap(testString,input_charset);
		assertNotNull(map);
	}
}
