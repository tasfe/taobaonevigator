package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeEntity;
import com.walmart.paymentgateway.model.TransactionEventStatusEntity;
import com.walmart.paymentgateway.model.TransactionTypeLkEntity;
import com.walmart.paymentgateway.service.util.StaticDataProvider;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
public class StaticLookUpDaoTest extends TestCase {

	@Autowired
	StaticLookUpDao staticLookUpDao;

	@Test
	public void findServicePayMethodCode() {

		for (String srvProviderPaycode : StaticDataProvider.srvProviderPaycode) {
			SrvProviderPayTypeCodeEntity paycodeList = staticLookUpDao
					.findServicePayMethodCode(srvProviderPaycode);
			assertNotNull(paycodeList);
			assertNotNull(paycodeList.getExtPayCode());
			LogSupport.debug("Payment Code Service Provider "
					+ paycodeList.getExtPayCode());
			assertNotNull(paycodeList.getIntPayCode());
			LogSupport.debug("Payment Code Payment System Mapped "
					+ paycodeList.getIntPayCode());
		}

	}

	@Test
	public void findDomainInfoByName() {

		DomainLkEntity domainByName = staticLookUpDao
				.findDomainInfoByName("WALMART.CN");
		assertNotNull(domainByName);
		assertNotNull(domainByName.getName());
		LogSupport.debug("DomainLkEntity found when Name = "
				+ domainByName.getName());
	}

	@Test
	public void findDomainInfoById() {

		DomainLkEntity domainById = staticLookUpDao.findDomainInfoById(1L);
		assertNotNull(domainById);
		assertNotNull(domainById.getDomainPk());
		LogSupport.debug("DomainLkEntity found when ID = "
				+ domainById.getDomainPk());
	}

	@Test
	public void findChannelInfoByName() {

		ChannelLkEntity channelByName = staticLookUpDao
				.findChannelInfoByName("ONLINE.ESTORE");
		assertNotNull(channelByName);
		assertNotNull(channelByName.getName());
		LogSupport.debug("ChannelLkEntity found when Name = "
				+ channelByName.getName());

	}

	@Test
	public void findChannelInfoById() {

		ChannelLkEntity channelById = staticLookUpDao.findChannelInfoById(1L);
		assertNotNull(channelById);
		assertNotNull(channelById.getchannelPk());
		LogSupport.debug("ChannelLkEntity found when ID = "
				+ channelById.getchannelPk());
	}

	@Test
	public void findRequestOriginInfoByName() {

		for (String requestOrginCode : StaticDataProvider.requestOrginCode) {
			RequestOriginLkEntity requestOrginByName = staticLookUpDao
					.findRequestOriginInfoByName(requestOrginCode);
			assertNotNull(requestOrginByName);
			assertNotNull(requestOrginByName.getName());
			LogSupport.debug("RequestOriginlLkEntity found when Name = "
					+ requestOrginByName.getName());
		}
	}

	@Test
	public void findRequestOriginInfoById() {

		RequestOriginLkEntity requestOrginById = staticLookUpDao
				.findRequestOriginInfoById(1L);
		assertNotNull(requestOrginById);
		assertNotNull(requestOrginById.getRequestOriginPk());
		LogSupport.debug("RequestOriginlLkEntity found when ID = "
				+ requestOrginById.getRequestOriginPk());

	}

	@Test
	public void findTransactionTypeByName() {

		for (String transactionTypeCode : StaticDataProvider.transactionTypeCode) {
			TransactionTypeLkEntity transactionByName = staticLookUpDao
					.findTransactionTypeByName(transactionTypeCode);
			assertNotNull(transactionByName);
			assertNotNull(transactionByName.getName());
			LogSupport.debug("TransactionTypeLkEntity found when NAME = "
					+ transactionByName.getName());
		}
	}

	@Test
	public void findTransactionStatus() {

		// same as findTransactionTypeByName
	}

	@Test
	public void findTransactionTypeById() {

		TransactionTypeLkEntity transactionById = staticLookUpDao
				.findTransactionTypeById(1L);
		assertNotNull(transactionById);
		assertNotNull(transactionById.getTransactionTypePk());
		LogSupport.debug("TransactionTypeLkEntity found when ID = "
				+ transactionById.getTransactionTypePk());

	}

	@Test
	public void findTransactionEventStatusByName() {

		TransactionEventStatusEntity transEventByName = staticLookUpDao
				.findTransactionEventStatusByName("PAY_URL_CREATED");
		assertNotNull(transEventByName);
		assertNotNull(transEventByName.getName());
		LogSupport.debug("TransactionEventStatus found when Name = "
				+ transEventByName.getName());

	}

	@Test
	public void findTransactionEventStatusById() {

		TransactionEventStatusEntity transEventById = staticLookUpDao
				.findTransactionEventStatusById(1L);
		assertNotNull(transEventById);
		assertNotNull(transEventById.getTransactionEventStatusPk());
		LogSupport.debug("TransactionEventStatus found when ID = "
				+ transEventById.getTransactionEventStatusPk());
	}

	@Test
	public void findAllServiceProvider() {

		List<SrvProviderEntity> providerList = staticLookUpDao
				.findAllServiceProvider();
		Set<SrvProviderPayTypeEntity> payTypeEntitySet = null;
		Set<SrvProviderPayTypeCodeEntity> payCodeEntitySet = null;
		assertNotNull(providerList);
		LogSupport.debug("providerList size " + providerList.size());
		for (SrvProviderEntity providerEntity : providerList) {
			assertNotNull(providerEntity.getName());
			LogSupport.debug(" Provider Name " + providerEntity.getName());
			payTypeEntitySet = providerEntity.getSrvProviderPayTypes();
			assertNotNull(payTypeEntitySet);
			for (SrvProviderPayTypeEntity payTypeEntity : payTypeEntitySet) {
				assertNotNull(payTypeEntity);
				LogSupport.debug("Payment Mode " + payTypeEntity.getName());
				assertNotNull(payTypeEntity.getName());
				payCodeEntitySet = payTypeEntity.getSrvProviderPayTypeCodes();
				assertNotNull(payCodeEntitySet);
				for (SrvProviderPayTypeCodeEntity payCodeEntity : payCodeEntitySet) {
					assertNotNull(payCodeEntity);
					LogSupport.debug("Payment Code Service Provider "
							+ payCodeEntity.getExtPayCode());
					assertNotNull(payCodeEntity.getExtPayCode());
					LogSupport.debug("Payment Code Payment System Mapped "
							+ payCodeEntity.getIntPayCode());
					assertNotNull(payCodeEntity.getIntPayCode());
				}
			}
		}
	}

}
