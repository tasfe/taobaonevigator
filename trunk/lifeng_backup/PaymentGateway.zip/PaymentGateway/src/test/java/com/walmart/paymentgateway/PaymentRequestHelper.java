package com.walmart.paymentgateway;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.Customer;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PaymentRequest;

/**
 * 
 * @author sgopisetty
 *
 */
@Component
public class PaymentRequestHelper {

	
	public static PaymentRequest  createPaymentServiceRequest()
	{
		ObjectFactory reqfactory = new ObjectFactory();
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();

		PayUrlRequest payUrlType = reqfactory.createPayUrlRequest();
		payUrlType.setPayURLServiceCode("ALP-DIRECT");
		payUrlType.setReturnUrl("https://");

		/*CodRequest cod = reqfactory.createCodRequest();
		cod.setCodServiceCode("WAL-COD");*/

		
		payUrlType.setAmount(new BigDecimal("0.01"));
		payUrlType.setCorrelationId("payURL1233");
		payUrlType.setChannel("ONLINE.ESTORE");

		
		/*cod.setAmount(new BigDecimal("1.00"));
		cod.setCorrelationId("cod1233");
		cod.setChannel("ONLINE.ESTORE");*/
		
		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId("o1234");
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getPayUrlRequest().add(payUrlType);
		//paymentRequestType.getPayUrlRequestOrCodRequest().add(cod);
		
		return paymentRequestType;
		
	}
	public static PaymentRequest  createAlipayPaymentRequest(String payCode,String amount,String orderId,String returnURL,String correlationId)
	{
		ObjectFactory reqfactory = new ObjectFactory();
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();

		PayUrlRequest payUrlType = reqfactory.createPayUrlRequest();
		payUrlType.setPayURLServiceCode(payCode);
		payUrlType.setReturnUrl(returnURL);

		/*CodRequest cod = reqfactory.createCodRequest();
		cod.setCodServiceCode("WAL-COD");*/

		
		payUrlType.setAmount(new BigDecimal(amount));
		payUrlType.setCorrelationId(correlationId);
		payUrlType.setChannel("ONLINE.ESTORE");

		
		/*cod.setAmount(new BigDecimal("1.00"));
		cod.setCorrelationId("cod1233");
		cod.setChannel("ONLINE.ESTORE");*/
		
		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId(orderId);
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getPayUrlRequest().add(payUrlType);
		//paymentRequestType.getPayUrlRequestOrCodRequest().add(cod);
		
		return paymentRequestType;
		
	}
	/*public PaymentRequest  invalidPayCode()
	{
		ObjectFactory reqfactory = new ObjectFactory();
		
		//Paymen = reqfactory.createPaymentService(requestObj);
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		

		PayUrlRequest payUrlType = reqfactory.createPayUrlRequest();
		payUrlType.setPayURLServiceCode("INVALID");
		payUrlType.setReturnUrl("https://");


		ServiceCode serviceCodeType = reqfactory.createServiceCode();
		serviceCodeType.setPayUrlRequest(payUrlType);

		TransactionRequest transactionRequestType = reqfactory.createTransactionRequest();
		transactionRequestType.setAmount(new BigDecimal("1.00"));
		transactionRequestType.setCorrelationId("pg1233");
		transactionRequestType.setPaymentServiceCode(serviceCodeType);
		transactionRequestType.setTenant("ONLINE.ESTORE");

		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId("o1234");
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getTransactionRequest().add(transactionRequestType);
		return paymentRequestType;
		
	}
	public PaymentRequest  createCodRequest()
	{
		ObjectFactory reqfactory = new ObjectFactory();
		
		//Paymen = reqfactory.createPaymentService(requestObj);
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		


		CodRequest cod = reqfactory.createCodRequest();
		cod.setCodServiceCode("WAL-COD");

		ServiceCode serviceCodeType = reqfactory.createServiceCode();
		serviceCodeType.setCodRequest(cod);

		TransactionRequest transactionRequestType = reqfactory.createTransactionRequest();
		transactionRequestType.setAmount(new BigDecimal("0.01"));
		transactionRequestType.setCorrelationId("cod123");
		transactionRequestType.setPaymentServiceCode(serviceCodeType);
		transactionRequestType.setTenant("ONLINE.ESTORE");

		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId("cod1234");
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getTransactionRequest().add(transactionRequestType);
		return paymentRequestType;
		
	}*/
	public PaymentRequest  createAlipayBankRequest()
	{
		ObjectFactory reqfactory = new ObjectFactory();
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();
		//Paymen = reqfactory.createPaymentService(requestObj);
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		//PaymentRequestType request = reqfactory.createPaymentRequestType();
		

		PayUrlRequest payUrlType = reqfactory.createPayUrlRequest();
		payUrlType.setPayURLServiceCode("ALP-BJRCB");
		payUrlType.setReturnUrl("https://");



		payUrlType.setAmount(new BigDecimal("1.00"));
		payUrlType.setCorrelationId("pg1233");
		payUrlType.setChannel("ONLINE.ESTORE");

		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId("o1234");
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getPayUrlRequest().add(payUrlType);
		
		return paymentRequestType;
		
	}
}
