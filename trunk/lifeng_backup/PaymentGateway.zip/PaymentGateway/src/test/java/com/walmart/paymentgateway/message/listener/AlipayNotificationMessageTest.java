package com.walmart.paymentgateway.message.listener;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;


import com.walmart.paymentgateway.MessageSenderUtil;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.PaymentNotification;
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class AlipayNotificationMessageTest {

	/**
	 * @param args
	 * @throws JAXBException 
	 * @throws IOException 
	 */
	
	String qName  ="queueForPaymentNotificationReceive";
	@Test
	public  void sendCdataNotification() throws JAXBException, IOException {
		// create JAXB context and instantiate marshaller
		JAXBContext context = JAXBContext.newInstance(PaymentNotification.class);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//CdataMessageTest test = new CdataMessageTest();
 
     // get an Apache XMLSerializer configured to generate CDATA
        XMLSerializer serializer = getXMLSerializer();
        System.out.println("********* ******* ");
        Writer writer = new StringWriter();
        serializer.setOutputCharStream(writer);
        
        // marshal using the Apache XMLSerializer
        m.marshal(createMessage(), serializer.asContentHandler());
       String xml = writer.toString();
       assertNotNull(xml);
       LogSupport.info("CDATA Message ******* "+xml);
       MessageSenderUtil sender = new MessageSenderUtil();
       sender.sendMessage(writer.toString(), qName);
	}
	public static void main(String[] args) throws JAXBException, IOException {
		// create JAXB context and instantiate marshaller
		JAXBContext context = JAXBContext.newInstance(PaymentNotification.class);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		AlipayNotificationMessageTest test = new AlipayNotificationMessageTest();
 
     // get an Apache XMLSerializer configured to generate CDATA
        XMLSerializer serializer = getXMLSerializer();

        // marshal using the Apache XMLSerializer
        m.marshal(test.createMessage(), serializer.asContentHandler());
        Writer writer = new StringWriter();
        serializer.setOutputCharStream(writer);
	}
	private PaymentNotification createMessage(){
		
		String notificationMsg = "body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5";
		PaymentNotification paymentNotification  = new PaymentNotification();
		paymentNotification.setProvider("ALIPAY");
		paymentNotification.setMessage(notificationMsg);
		return paymentNotification;
	}
	 private static XMLSerializer getXMLSerializer() {
	        // configure an OutputFormat to handle CDATA
	        OutputFormat of = new OutputFormat();

	        // specify which of your elements you want to be handled as CDATA.
	        // The use of the '^' between the namespaceURI and the localname
	        // seems to be an implementation detail of the xerces code.
		// When processing xml that doesn't use namespaces, simply omit the
		// namespace prefix as shown in the third CDataElement below.
	        of.setCDataElements(
				    new String[] { "ns1^foo",   // 
						   "ns2^bar",   // 
						   "^Message" });   // 

	        // set any other options you'd like
	        of.setPreserveSpace(true);
	        of.setIndenting(true);

	        // create the serializer
	        XMLSerializer serializer = new XMLSerializer(of);
	       // serializer.setOutputByteStream(System.out);

	        return serializer;
	    }

}
