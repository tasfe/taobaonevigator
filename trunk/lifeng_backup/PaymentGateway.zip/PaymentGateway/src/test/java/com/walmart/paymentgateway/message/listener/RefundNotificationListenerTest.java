package com.walmart.paymentgateway.message.listener;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.jms.Destination;


import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.walmart.paymentgateway.service.domain.RefundNotification;


/* This test class create an expected refund xml from webservice gateway and put the xml message
* as text message to Refund Notification Queue
* */
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class RefundNotificationListenerTest extends TestCase {
	
	@Autowired 
	JmsTemplate jmsTemplate; 
	RefundNotification message = null;
	@Autowired
	@Qualifier("queueForRefundNotificationReceive")
	Destination destination;

	@Test
	public void testRefundNotificationListenerInvoked(){
		message = createMessage();
		assertNotNull(message);
		MessageListenerDelegate mockRefundNotificationListener = mock(MessageListenerDelegate.class);
		mockRefundNotificationListener.receive(message);
		verify(mockRefundNotificationListener,times(1)).receive(message);
	}
	@Test
	public void testRefundNotificationSending(){
		
		message = createMessage();
		assertNotNull(message);
		this.jmsTemplate.convertAndSend(destination, message);
	}
	
	private RefundNotification createMessage(){
		
		String notificationMsg = "http://vrthomas.corp.walmart.com:8080/Alipay/AlipayResponse?body=sams+club+merchantise&buyer_email=alipay_test%40alipay.com&buyer_id=2088102151633543&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7xs9gugL7HLNNKl1byWwKHAnXtM9DN3WNGw1wRoXyq36s%252BvZZu&notify_time=2011-03-25+02%3A02%3A52&notify_type=trade_status_sync&out_trade_no=20110324110112&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=sams+club&total_fee=1.00&trade_no=2011032546320854&trade_status=TRADE_SUCCESS&sign=d2e31071f004201f92dcbc111324901a&sign_type=MD5";
		RefundNotification refundNotification  = new RefundNotification();
		refundNotification.setProvider("ALIPAY");
		refundNotification.setMessage(notificationMsg);
		return refundNotification;
	}
	
	
}
