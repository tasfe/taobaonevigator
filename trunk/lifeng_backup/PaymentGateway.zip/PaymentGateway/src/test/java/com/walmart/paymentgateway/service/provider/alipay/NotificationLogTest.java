/**
 * 
 */
package com.walmart.paymentgateway.service.provider.alipay;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.dao.AlipayServiceDao;
import com.walmart.paymentgateway.model.AlipayNotificationEntity;
import com.walmart.paymentgateway.model.AlipayPaymentNotificationEntity;

import junit.framework.TestCase;

/**
 * @author sgopisetty
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = false)
@Transactional
public class NotificationLogTest extends TestCase {
	

	
	@Autowired
	private AlipayServiceDao alipayServiceDao;
	
	/***
	 * 
	 * @param pParameter
	 * @throws Exception
	 */
	@Test
	@Transactional
	public void logPayNotification() {
		LogSupport.debug("Start logPayNotification () ");
		
		AlipayPaymentNotificationEntity payNotificationItem = new AlipayPaymentNotificationEntity();
		AlipayNotificationEntity alipayNotificationEntity = logNotification();
		String buyerEmail = "buyer_email"; //pParameter.get("buyer_email");
		//Timestamp gmtCreationTime;
		//Timestamp gmtPaymentTime;
		//String isTotalFeeAdjusted = pParameter.get("notify_id");
		String outTradeNo = "12132123";
		String paymentType = "payment_type";
		//BigDecimal quantity = ConvertUtil.toBigDecimal(pParameter.get("notify_id"));
		String sellerEmail = "seller_email";
		String sellerId = "seller_id";
		BigDecimal totalFee = AlipayUtil.toBigDecimal("100.00");
		String tradeNo = "34234";
		String tradeStatus = "trade_status";
		//BigDecimal unitPrice = ConvertUtil.toBigDecimal(pParameter.get("notify_id"));
		if (null != alipayNotificationEntity) {
			payNotificationItem.setBuyerEmail(buyerEmail);
			payNotificationItem.setOutTradeNo(outTradeNo);
			payNotificationItem.setPaymentType(paymentType);
			payNotificationItem.setSellerEmail(sellerEmail);
			payNotificationItem.setSellerId(sellerId);
			payNotificationItem.setTotalFee(totalFee);
			payNotificationItem.setTradeNo(tradeNo);
			payNotificationItem.setTradeStatus(tradeStatus);
			payNotificationItem.setAlipayNotification(alipayNotificationEntity);
			
			alipayServiceDao.createPayNotification(payNotificationItem);
		}
		
		
		LogSupport.debug("Existing from logPayNotification() ");
		
	}
	
	/***
	 * 
	 * @param pParameter
	 * @return
	 * @throws ParseException 
	 */
	private AlipayNotificationEntity logNotification()  {
		LogSupport.debug("Start logNotification () ");
		
		AlipayNotificationEntity notificationItem = new AlipayNotificationEntity();
		String notifiyId = "notify_id";
		Timestamp notifyTime = AlipayUtil.toTimestamp("2011-09-16 05:01:12");
		String notifyType = "notify_type";
		//String notifyValidationStatus = pParameter.get("");
		String sign = "sign";
		String signType = "sign_type";
		//String signValidationStatus = pParameter.get("");
		notificationItem.setNotifyId(notifiyId);
		notificationItem.setNotifyTime(notifyTime);
		notificationItem.setNotifyType(notifyType);
		//notificationItem.setNotifyValidationStatus(pParameter.get(""));
		notificationItem.setSign(sign);
		notificationItem.setSignType(signType);
		//notificationItem.setSignValidationStatus(pParameter.get(""));
		LogSupport.debug("Exit from logNotification () ");
		return alipayServiceDao.createNotification(notificationItem);
	}
	




}
