package com.walmart.paymentgateway.dao;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;
import com.walmart.paymentgateway.model.AlipayNotificationEntity;
import com.walmart.paymentgateway.model.AlipayPaymentNotificationEntity;
import com.walmart.paymentgateway.service.provider.alipay.AlipayUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
/**
 *  Test class for AlipayServiceDao 
 */
public class AlipayServiceDaoTest extends TestCase {

	@Autowired
	AlipayServiceDao alipayServiceDao;
	
	@Test
	public void findAllAccountConfig() throws ServiceDataAccessException{
		
		List<AlipayAccountConfigEntity> alipayAccountConfigEntityList = alipayServiceDao.findAllAccountConfig();
		assertNotNull(alipayAccountConfigEntityList);
	}
	@Test
	public void createNotification() throws ServiceDataAccessException{
		
		AlipayNotificationEntity alipayNotificationEntity = new AlipayNotificationEntity();
		Timestamp notifyTime = AlipayUtil.toTimestamp("2011-09-16 05:01:12");
		alipayNotificationEntity.setNotifyId("testnotifyid");
		alipayNotificationEntity.setNotifyTime(notifyTime);
		alipayNotificationEntity.setNotifyType("testnotificationtype");
		alipayNotificationEntity.setNotifyValidationStatus("FAIL");
		alipayNotificationEntity.setSign("testsignature");
		alipayNotificationEntity.setSignType("MD5");
		alipayNotificationEntity.setSignValidationStatus("FAIL");
		alipayServiceDao.createNotification(alipayNotificationEntity);
		assertNotNull(alipayServiceDao.find(alipayNotificationEntity.getAlipayNotificationPk(), AlipayNotificationEntity.class));
		AlipayNotificationEntity queriedEntity  = alipayServiceDao.find(alipayNotificationEntity.getAlipayNotificationPk(), AlipayNotificationEntity.class);
		assertEquals("testnotifyid", queriedEntity.getNotifyId());
	}
	@Test
	public void createPayNotification() throws ServiceDataAccessException{
		
		
		AlipayPaymentNotificationEntity payNotificationEntity = new AlipayPaymentNotificationEntity();
		BigDecimal totalFee = AlipayUtil.toBigDecimal("0.01");
		payNotificationEntity.setBuyerEmail("testBuyerEmail");
		payNotificationEntity.setOutTradeNo("1");
		payNotificationEntity.setPaymentType("1");
		payNotificationEntity.setSellerEmail("testSellerEmail");
		payNotificationEntity.setSellerId("testSellerId");
		payNotificationEntity.setTotalFee(totalFee);
		payNotificationEntity.setTradeNo("testTradeNo");
		payNotificationEntity.setTradeStatus("testTradeStatus");

		AlipayNotificationEntity alipayNotificationEntity = new AlipayNotificationEntity();
		Timestamp notifyTime = AlipayUtil.toTimestamp("2011-09-16 05:01:12");
		alipayNotificationEntity.setNotifyId("testnotifyid");
		alipayNotificationEntity.setNotifyTime(notifyTime);
		alipayNotificationEntity.setNotifyType("testnotificationtype");
		alipayNotificationEntity.setNotifyValidationStatus("FAIL");
		alipayNotificationEntity.setSign("testsignature");
		alipayNotificationEntity.setSignType("MD5");
		alipayNotificationEntity.setSignValidationStatus("FAIL");
		alipayServiceDao.createNotification(alipayNotificationEntity);

		
		payNotificationEntity.setAlipayNotification(alipayNotificationEntity);
		alipayServiceDao.createPayNotification(payNotificationEntity);
		assertNotNull(alipayServiceDao.find(payNotificationEntity.getAlipayPaymentNotificationPk(), AlipayPaymentNotificationEntity.class));
	}
	@Test
	public void findPayNotification() throws ServiceDataAccessException{
		
		AlipayPaymentNotificationEntity payNotificationEntity = new AlipayPaymentNotificationEntity();
		BigDecimal totalFee = AlipayUtil.toBigDecimal("0.01");
		payNotificationEntity.setBuyerEmail("testBuyerEmail");
		payNotificationEntity.setOutTradeNo("1");
		payNotificationEntity.setPaymentType("1");
		payNotificationEntity.setSellerEmail("testSellerEmail");
		payNotificationEntity.setSellerId("testSellerId");
		payNotificationEntity.setTotalFee(totalFee);
		payNotificationEntity.setTradeNo("testTradeNo");
		payNotificationEntity.setTradeStatus("testTradeStatus");

		AlipayNotificationEntity alipayNotificationEntity = new AlipayNotificationEntity();
		Timestamp notifyTime = AlipayUtil.toTimestamp("2011-09-16 05:01:12");
		alipayNotificationEntity.setNotifyId("testnotifyid");
		alipayNotificationEntity.setNotifyTime(notifyTime);
		alipayNotificationEntity.setNotifyType("testnotificationtype");
		alipayNotificationEntity.setNotifyValidationStatus("FAIL");
		alipayNotificationEntity.setSign("testsignature");
		alipayNotificationEntity.setSignType("MD5");
		alipayNotificationEntity.setSignValidationStatus("FAIL");
		alipayServiceDao.createNotification(alipayNotificationEntity);

		
		payNotificationEntity.setAlipayNotification(alipayNotificationEntity);
		alipayServiceDao.createPayNotification(payNotificationEntity);

		assertNotNull(alipayServiceDao.findPayNotification("testTradeNo"));
	}
}
