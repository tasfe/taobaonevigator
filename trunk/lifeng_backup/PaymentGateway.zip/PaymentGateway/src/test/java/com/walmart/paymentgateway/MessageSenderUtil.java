package com.walmart.paymentgateway;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
/**
 * This component is responsible for posting message to a queue. To be used for testing only
 * @author Raju Thomas
 *
 */
@Component("messageSender")
public class MessageSenderUtil {

	@Autowired
	static JmsTemplate jmsTemplate;
	
	/**
	 * 
	 * @param message
	 * @param qName
	 */
	public  void sendMessage(final String message,String qName){
	
		
		LogSupport.debug("Start MessageSender sendMessage");
		LogSupport.debug(" Message to Sent "+message);
		
		jmsTemplate.send(qName, new MessageCreator(){ 
			public Message createMessage(Session session) throws JMSException{ 
				return session.createTextMessage(message);
			}
		
		}
			);
	
	LogSupport.debug("End MessageSender sendMessage");
	}
	
}