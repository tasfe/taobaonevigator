package com.walmart.paymentgateway;

import java.io.File;
import java.io.StringWriter;
import java.math.BigDecimal;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamResult;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.Customer;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PaymentRequest;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = { "classpath:/testApplicationContext.xml" }) 
public class SchemaValidationTest extends TestCase{

	@Autowired
	private Jaxb2Marshaller paymentDomainMarshaller;
	
	@Test
	public void payRequestTest(){
		
		PaymentRequest paymentRequest = createPaymentServiceRequest();
		StringWriter out = new StringWriter();
		//Schema schema;
		//SchemaFactory schemaFactory = SchemaFactory.newInstance( XMLConstants.W3C_XML_SCHEMA_NS_URI );
		//schema = schemaFactory.newSchema(new File("paymentRequest.xsd"));
		//paymentDomainMarshaller.setSchemaLanguage( XMLConstants.W3C_XML_SCHEMA_NS_URI);
		paymentDomainMarshaller.marshal(paymentRequest, new StreamResult(out));
		
		LogSupport.info(out.toString());
	
	}
	
	private PaymentRequest  createPaymentServiceRequest()
	{
		PaymentRequest paymentRequest = new PaymentRequest();

		PayUrlRequest payUrl =new PayUrlRequest();
		payUrl.setPayURLServiceCode("ALP-DIRECT");
		payUrl.setReturnUrl("https://");
		payUrl.setAmount(new BigDecimal("0.01"));
		payUrl.setCorrelationId("payURL1233");
		payUrl.setChannel("ONLINE.ESTORE");

		Customer customer = new Customer();
		customer.setCustomerId("prof1233");
		
		
		paymentRequest.setCustomer(customer);
		paymentRequest.setOrderId("o1234");
		paymentRequest.setDomain("WALMART.CN");
		paymentRequest.setOriginator("ESTORE");
		paymentRequest.getPayUrlRequest().add(payUrl);
		
		return paymentRequest;
		
	}
	
}
