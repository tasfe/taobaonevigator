package com.walmart.paymentgateway.InteTest;

import java.math.BigDecimal;
import java.util.Set;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.model.AccountEntity;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.OrderInfoEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.model.TransactionTypeLkEntity;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = false)
@Transactional
public class AccountCreationTest extends TestCase {
	
	
	@Autowired
	private DaoManager transactionalTools;
	
	/*private  service  
	PaymentRequestHelper helper = new PaymentRequestHelper();
	*/	/**
		 * <pre>
		 * 
		 * </pre>
		 * 
		 * @throws java.lang.Exception
		 */
		@Before
		public void setUp() throws Exception {
		}

		/**
		 * <pre>
		 * 
		 * </pre>
		 * 
		 * @throws java.lang.Exception
		 */
		@After
		public void tearDown() throws Exception {
		}
		
		@Test
		@Transactional
		public void testAccountCreation(){
			
			LogSupport.info("Start createPayURLRequestTransaction ");
			
			String customerId = "1111";
			String DomainName = "WALMART.CN";
			String pOrderId = "1010101";
			String originator = "ESTORE";
			
			String paySrvCode = "ALP-DIRECT";
			
			BigDecimal amount = new BigDecimal(1000.00);
			//String extCorrelationId = "sdja1kj21";
			String tenant = "ONLINE.ESTORE";
			
			AccountEntity accountEntity = null;
			OrderInfoEntity orderEntity = null;
			DomainLkEntity domainEntity = null;
			SrvProviderPayTypeCodeEntity srvPayCodeEntity =  null;
			ChannelLkEntity tenantLkEntity = null;
			TransactionTypeLkEntity transactionTypeLkEntity = null;
			TransactionEntity transactionEntity = null;
			RequestOriginLkEntity requestOriginLk =  null;
			
			accountEntity = getTransactionalTools().findAccount(customerId);
			domainEntity = getTransactionalTools().findDomain(DomainName);
			srvPayCodeEntity = getTransactionalTools().findSrvProviderInfo(paySrvCode);
			tenantLkEntity = getTransactionalTools().findChannel(tenant);
			transactionTypeLkEntity =  getTransactionalTools().findTransactionType("PAY");
			requestOriginLk = getTransactionalTools().findRequestOrigin(originator);
			orderEntity =  getTransactionalTools().findOrder("1010101");
			
			transactionEntity = new TransactionEntity();
			
			if (null == accountEntity) {
				accountEntity = new AccountEntity();
				accountEntity.setExtCustomerId(customerId);
				accountEntity.setDomainLk(domainEntity);
				getTransactionalTools().createAccount(accountEntity);
			}
			if (null == orderEntity) {
				orderEntity = new OrderInfoEntity();
				orderEntity.setExtOrderId(pOrderId);
				//getTransactionalTools().createOrder(orderEntity);
				Set<OrderInfoEntity> orderset = accountEntity.getOrderInfos();
				orderset.add(orderEntity);
				accountEntity.setOrderInfos(orderset);
				orderEntity.setAccount(accountEntity);
			}
			
			transactionEntity.setOrderInfo(orderEntity);
			transactionEntity.setTransactionTypeLk(transactionTypeLkEntity);
			transactionEntity.setAmount(amount);
			transactionEntity.setIntCorrelationId("111111111111");
			transactionEntity.setExtCorrelationId("123123123123");
			transactionEntity.setChannelLk(tenantLkEntity);
			transactionEntity.setSrvProviderPayTypeCode(srvPayCodeEntity);
			transactionEntity.setRequestOriginLk(requestOriginLk);
			//transactionEntity.setStatus("INPROCESS");
			getTransactionalTools().createOrUpateTransaction(transactionEntity,"PAY", "NEW");
			
			
			LogSupport.info("End createPayURLRequestTransaction ");

		}

		public void setTransactionalTools(DaoManager transactionalTools) {
			this.transactionalTools = transactionalTools;
		}

		public DaoManager getTransactionalTools() {
			return transactionalTools;
		}

		
		

		
		

}
