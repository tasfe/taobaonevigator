package com.walmart.paymentgateway.InteTest;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.walmart.paymentgateway.JAXBPaymentService;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.Customer;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class PaymentServiceRestTest extends TestCase {

	
	
	private String orderId = generateOrderId();
	private String transactionId = null;
	String paymentGatewayServiceURI = "http://localhost:9090/paymentgateway/payment/processpayment/";
	
	
	@Test
	public void paymentRequestRestInvoker(){
		
		
		Client client = Client.create();
		WebResource resource = client.resource(paymentGatewayServiceURI);
		PaymentRequest request= createPayURLRequest();
		String reqXML =  JAXBPaymentService.marshalPaymentRequest(request);
		LogSupport.debug("PAYMENT Request "+reqXML);
		assertNotNull(reqXML);
		ClientResponse response = resource.accept(MediaType.APPLICATION_XML).post(ClientResponse.class, request);
		String resXml = response.getEntity(String.class);
		try {
			
			LogSupport.debug("PAYMENT Response "+resXml);
			assertNotNull(resXml);
			PaymentResponse paymentResponse =  JAXBPaymentService.getPaymentResponseFromXml(resXml);
			assertNotNull(paymentResponse);
			assertEquals(orderId, paymentResponse.getOrderId());
			PayUrlResponse  payUrlResponse = (PayUrlResponse)paymentResponse.getPayUrlResponse().get(0);
			assertNotNull(payUrlResponse);
			transactionId = payUrlResponse.getTransactionId();
			assertNotNull(transactionId);
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			fail();
		} catch (JAXBException e) {
			e.printStackTrace();
			fail();
		}

	}
	private PaymentRequest createPayURLRequest(){
		
		PaymentRequest request = new PaymentRequest();
		Customer cust = new Customer();
		cust.setCustomerId("123");
		request.setCustomer(cust);
		request.setOrderId(orderId);
		request.setOriginator("ESTORE");
		request.setDomain("WALMART.CN");
		PayUrlRequest payUrl= new PayUrlRequest();
		BigDecimal decimal = new BigDecimal(0.01,new MathContext(1));
		payUrl.setAmount(decimal);
		payUrl.setChannel("ONLINE.ESTORE");
		payUrl.setPayURLServiceCode("ALP-DIRECT");
		payUrl.setReturnUrl("http://172.28.148.125:8280/estore/checkout/thankyou.jsp");
		payUrl.setCorrelationId("ext"+orderId);
		List<PayUrlRequest> payUrlRequest = request.getPayUrlRequest();
		payUrlRequest.add(payUrl);
		return request;
	}
	private String generateOrderId(){
		
		String pattern = "MMddyyyyHHmmss";
	    SimpleDateFormat format = new SimpleDateFormat(pattern);
	    String testId = format.format(new Date());
	    return testId;
	}

}
