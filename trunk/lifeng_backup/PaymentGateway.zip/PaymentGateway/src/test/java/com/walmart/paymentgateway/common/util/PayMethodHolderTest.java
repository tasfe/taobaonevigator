package com.walmart.paymentgateway.common.util;


import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.model.ProviderPayMethodInfo;
import com.walmart.paymentgateway.service.provider.alipay.AlipayConstant;
import com.walmart.paymentgateway.service.util.PaymentConstant;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
public class PayMethodHolderTest extends TestCase {

	
	@Autowired
	PayMethodHolder payMethodHolder;
	@Test
	public void getProviderPayMethodInfoWithInvalidValues(){
		
		ProviderPayMethodInfo providerPayMethodInfo = payMethodHolder.getProviderPayMethodInfo("INVALIDPAYCODE");
		assertNull(providerPayMethodInfo);
	}
	@Test
	public void getProviderPayMethodWithAlipayDirect(){
		
		ProviderPayMethodInfo providerPayMethodInfo = payMethodHolder.getProviderPayMethodInfo("ALP-DIRECT");
		assertNotNull(providerPayMethodInfo);
		assertEquals(PaymentConstant.ALIPAY, providerPayMethodInfo.getProviderCode());
		assertEquals(PaymentConstant.PAYURL, providerPayMethodInfo.getInfoType());
		assertEquals(AlipayConstant.DIRECTPAY, providerPayMethodInfo.getPaymentMethod());
		assertEquals(AlipayConstant.DIRECTPAY, providerPayMethodInfo.getPaymentCode());
	}
}
