package com.walmart.paymentgateway.service.provider.alipay;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.PaymentStatus;


import static org.mockito.Mockito.*;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class AlipayNotificationTest  extends TestCase{

	
	@Autowired
	AlipayNotification alipayPaymentNotification;
	@Test
	public void invokergetMap(){
		AlipayNotification mockAlipayNotification = mock(AlipayNotification.class);
		@SuppressWarnings("unchecked")
		Map<String, String> map = mock(Map.class);
		mockAlipayNotification.setParamMap(map);
		verify(mockAlipayNotification,times(1)).setParamMap(map);
		assertNotNull(mockAlipayNotification.getParamMap());
	}
	@Test
	public void invokergetValue(){
		AlipayNotification mockAlipayNotification = mock(AlipayNotification.class);
		@SuppressWarnings("unchecked")
		Map<String, String> map = mock(Map.class);
		map.put("key", "value");
		mockAlipayNotification.setParamMap(map);
		verify(mockAlipayNotification,times(1)).setParamMap(map);
	}
	@Test
	public void getValueTest(){
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("key", "value");
		alipayPaymentNotification.setParamMap(map);
		assertNotNull(alipayPaymentNotification.getParamMap());
		assertEquals("value", alipayPaymentNotification.getValue("key"));
	}
	@Test
	public void getValueTestUseEnum(){
		
		Map<String, String> map = new HashMap<String, String>();
		map.put(AlipayNotification.AlipayResponseParam.buyer_email.name(), "buyer@email.com");
		alipayPaymentNotification.setParamMap(map);
		assertNotNull(alipayPaymentNotification.getParamMap());
		LogSupport.info(alipayPaymentNotification.getValue("buyer_email"));
		LogSupport.info(AlipayNotification.AlipayResponseParam.buyer_email.name());
		assertEquals("buyer@email.com", alipayPaymentNotification.getValue("buyer_email"));
	}
	@Test
	public void convertUriToMapwithQueryStringTwo(){
		
		String testString = "<![CDATA[http://www.walmart.cn/?body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5]]>";
		PaymentStatus paymentStatus  = new PaymentStatus();
		alipayPaymentNotification.processPaymentNotification(testString, paymentStatus );
		assertNotNull(paymentStatus);
		assertEquals("2088002053153634", paymentStatus.getBuyerId());
		assertEquals("0.02", paymentStatus.getTransactedAmount().toPlainString());
		assertEquals("wangjinmin1982@126.com", paymentStatus.getBuyerEmail());
	}

}
