package com.walmart.paymentgateway.message.sender;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import junit.framework.TestCase;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.PaymentStatus;


@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")

public class PaymentStatusPostTest extends TestCase{

	@Autowired
	AbstractMessageSender  paymentStatusSender;
	@Autowired
	JmsTemplate jmsTemplate;
	
	PaymentStatus message = null;

	@Autowired 
	@Qualifier("queueForPaymentStatusPost")
	protected Destination destination;
	
	@Test
	public void testPaymentNotificationSenderInvoked(){
		message = createMessage();
		assertNotNull(message);
		AbstractMessageSender mockSender = mock(PaymentStatusSender.class);
		mockSender.sendMessage(message);
		verify(mockSender,times(1)).sendMessage(message);
	}
	@Test
	public void testCancelRequestSending(){
		message = createMessage();
		assertNotNull(message);
		paymentStatusSender.sendMessage(message);
		
	}
	private PaymentStatus createMessage(){
		
		PaymentStatus paymentNotification = new PaymentStatus();
		paymentNotification.setBuyerEmail("buyer@alipay.com");
		paymentNotification.setBuyerId("buyer123");
		paymentNotification.setOrderId("O12345");
		paymentNotification.setTransactedAmount(new BigDecimal("0.01"));
		paymentNotification.setTransactionId("4444-5555-abcd-8888");
		paymentNotification.setTransactionStatus("SUCCESS");
		paymentNotification.setTransactionStatusCode("COMPLETED");
		return paymentNotification;
	}
	@Test
	public void readMessage()
	{
		Message message = jmsTemplate.receive(destination);
	    TextMessage textMessage = null;
	    assertNotNull(message);
		if (message instanceof TextMessage)
		 {
		            textMessage = (TextMessage)message;
		            try
		            {
		                assertNotNull(textMessage.getText());
		                LogSupport.info("Payment Notification Message Read From Queue: "+textMessage.getText());
		            }catch (JMSException e)
		            {
		                fail(e.getMessage());
		            	e.printStackTrace();
		            }
		   }else{
			   
			   Assert.fail();
		   }
		
	
		}
}