package com.walmart.paymentgateway.message.sender;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;


import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundTransactionRequest;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class RefundRequesPostTest extends TestCase {

	
	@Autowired
	AbstractMessageSender  refundRequestSender;
	RefundRequest message ;

	@Test
	public void testPaymentNotificationSenderInvoked(){
		message = createMessage();
		assertNotNull(message);
		AbstractMessageSender mockSender = mock(RefundRequestSender.class);
		mockSender.sendMessage(message);
		verify(mockSender,times(1)).sendMessage(message);
	}
	@Test
	public void testRefundRequestSending(){
		message = createMessage();
		assertNotNull(message);
		refundRequestSender.sendMessage(message);
		
	}
	
	private RefundRequest createMessage(){
		
		RefundRequest refundRequest = new RefundRequest();
		refundRequest.setOrderId("O12345");
		refundRequest.setAmount(new BigDecimal("0.01"));
		refundRequest.setOriginator("PG");
		refundRequest.setReason("FORCE REFUND ON CANCEL");
		RefundTransactionRequest refundTransaction = new RefundTransactionRequest();
		refundTransaction.setTransactionId("4444-5555-abcd-8888");
		refundRequest.getRefundTransactionRequest().add(refundTransaction);
		return refundRequest;
	}

}
