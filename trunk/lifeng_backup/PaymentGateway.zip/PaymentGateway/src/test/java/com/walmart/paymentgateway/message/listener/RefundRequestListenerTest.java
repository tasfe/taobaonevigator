package com.walmart.paymentgateway.message.listener;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;

import javax.jms.Destination;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundTransactionRequest;

import junit.framework.TestCase;

/* This test class create an expected refund xml from webservice gateway and put the xml message
* as text message to Refund Notification Queue
* */
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class RefundRequestListenerTest extends TestCase{

	
	@Autowired 
	JmsTemplate jmsTemplate; 
	RefundRequest message = null;
	@Autowired
	@Qualifier("queueForRefundRequestReceive")
	Destination destination;

	@Test
	public void testRefundRequestListenerInvoked(){
		message = createMessage();
		assertNotNull(message);
		MessageListenerDelegate mockRefundRequestListener = mock(MessageListenerDelegate.class);
		mockRefundRequestListener.receive(message);
		verify(mockRefundRequestListener,times(1)).receive(message);
	}
	@Test
	public void testRefundRequestSending(){
		
		message = createMessage();
		assertNotNull(message);
		this.jmsTemplate.convertAndSend(destination, message);
	}
	
	private RefundRequest createMessage(){
		
		RefundRequest refundRequest  = new RefundRequest();
		refundRequest.setAmount(new BigDecimal("0.01"));
		refundRequest.setOrderId("O1234");
		refundRequest.setOriginator("OMS");
		RefundTransactionRequest transactionRequest = new RefundTransactionRequest();
		transactionRequest.setTransactionId("4444-5555-7777-8888");
		refundRequest.getRefundTransactionRequest().add(transactionRequest);
		return refundRequest;
	}
}
