package com.walmart.paymentgateway.message.listener;



import javax.jms.Destination;


import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import static org.mockito.Mockito.*;

/** 
 * This test class create an expected cancel request xml from estore/oms and put the xml message
 * as text message to queueForCancelRequestReceive Queue
 * 
 * */
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class CancelRequestListenerTest extends TestCase{

	
	@Autowired 
	JmsTemplate jmsTemplate; 
	CancelRequest message = null;
	@Autowired
	@Qualifier("queueForCancelRequestReceive")
	Destination destination;
	@Test
	public void testCancelRequestListenerInvoked(){
		message = createMessage();
		assertNotNull(message);
		MessageListenerDelegate mockCancelRequestListener = mock(MessageListenerDelegate.class);
		mockCancelRequestListener.receive(message);
		verify(mockCancelRequestListener,times(1)).receive(message);
	}
	@Test
	public void testCancelRequestSending(){
		message = createMessage();
		assertNotNull(message);
		this.jmsTemplate.convertAndSend(destination, message);
	}
	
	private CancelRequest createMessage(){
		
		CancelRequest message  = new CancelRequest();
		message.setOrderId("O12345");
		message.setOriginator("ESTORE");
		CancelTransactionRequest transaction = new CancelTransactionRequest();
		transaction.setTransactionId("4444-3333-2222-1111");
		transaction.setForceRefund(Boolean.FALSE);
		message.getCancelTransactionRequest().add(transaction);
		return message;
	}
	
}
