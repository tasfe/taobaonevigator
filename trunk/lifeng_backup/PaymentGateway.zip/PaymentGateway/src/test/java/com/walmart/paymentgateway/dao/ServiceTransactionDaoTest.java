package com.walmart.paymentgateway.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.PaymentRequestHelper;
import com.walmart.paymentgateway.common.util.TransactionLogger;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.service.domain.PaymentRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
public class ServiceTransactionDaoTest  {

	
	@Autowired
	ServiceTransactionDaoImpl serviceTransactionDao;
	@Autowired
	TransactionLogger transactionLogger;
	@Test
	public void findTransactionWithOrderDetails() {
		
		String pOrderId ="unittestorder";
		String returnURL ="http://unittestreturnurl";
		String amount ="0.01";
		BigDecimal transactionAmt= new BigDecimal("0.01");
		String pExtCorrelationId =  "testcorrecttionid";
		String pChannel =  "ONLINE.ESTORE";
		String pPaySrvCode =  "ALP-DIRECT";
		PaymentRequest request =PaymentRequestHelper.createAlipayPaymentRequest(pPaySrvCode, amount, pOrderId, returnURL,pExtCorrelationId);
		transactionLogger.logPaymentTransaction(request, pPaySrvCode, "testtransactionid", request.getPayUrlRequest().get(0), "PAY_URL_CREATED");
		TransactionEntity entity = serviceTransactionDao.findTransactionWithOrderDetails(pOrderId, transactionAmt, pExtCorrelationId,pChannel,pPaySrvCode);
		assertNotNull(entity);
		assertEquals(pOrderId, entity.getOrderInfo().getExtOrderId());
		assertEquals(amount, entity.getAmount().toString());
		assertEquals(pExtCorrelationId, entity.getExtCorrelationId());
		assertEquals(pChannel, entity.getChannelLk().getName());
		assertEquals(pPaySrvCode, entity.getSrvProviderPayTypeCode().getIntPayCode());
   }

}
