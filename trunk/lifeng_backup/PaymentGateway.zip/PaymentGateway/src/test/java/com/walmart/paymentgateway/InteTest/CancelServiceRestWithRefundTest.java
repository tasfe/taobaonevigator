package com.walmart.paymentgateway.InteTest;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.walmart.paymentgateway.JAXBPaymentService;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.Customer;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class CancelServiceRestWithRefundTest extends TestCase {

	
	
	private String orderId = "09212011163912";
	private String transactionId = "cd85b3a3-2592-4521-b68c-41e1524b9ee0";
	private String alipayId = "2011091652081863";
	String cancelGatewayServiceURI = "http://localhost:9090/paymentgateway/payment/processcancel/";
	
	
	@Test
	public void cancelRequestRestInvoker(){
		
		Client client = Client.create();
		WebResource resource = client.resource(cancelGatewayServiceURI);
		CancelRequest  request= createMessage();
		String reqXML =  JAXBPaymentService.marshalCancelRequest(request);
		LogSupport.debug("CANCEL Request "+reqXML);
		assertNotNull(reqXML);
		ClientResponse response = resource.accept(MediaType.APPLICATION_XML).post(ClientResponse.class, request);
		String resXml = response.getEntity(String.class);
		LogSupport.debug("CANCEL Response *************************"+resXml);
		try {
			
			CancelResponse cancelResponse =  JAXBPaymentService.getCancelResponseFromXml(resXml);
			assertNotNull(cancelResponse);
			assertEquals(orderId, cancelResponse.getOrderId());
			assertEquals("SUCCESS", cancelResponse.getResponseStatus());
			CancelTransactionResponse  cancelTransactionResponse = (CancelTransactionResponse)cancelResponse.getCancelTransactionResponse().get(0);
			assertNotNull(cancelTransactionResponse);
			transactionId = cancelTransactionResponse.getTransactionId();
			assertEquals(transactionId, cancelTransactionResponse.getTransactionId());
			assertEquals("SUCCESS", cancelTransactionResponse.getTransactionStatus());
			assertEquals("CANCEL", cancelTransactionResponse.getTransactionStatusCode());
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fail();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fail();
		}
		LogSupport.debug("CANCEL Response "+resXml);
		assertNotNull(resXml);

	}
	
	private CancelRequest createMessage(){
			
			CancelRequest message  = new CancelRequest();
			message.setOrderId(orderId);
			message.setOriginator("ESTORE");
			CancelTransactionRequest transaction = new CancelTransactionRequest();
			transaction.setTransactionId(transactionId);
			transaction.setForceRefund(Boolean.TRUE);
			message.getCancelTransactionRequest().add(transaction);
			return message;
	}

	

}
