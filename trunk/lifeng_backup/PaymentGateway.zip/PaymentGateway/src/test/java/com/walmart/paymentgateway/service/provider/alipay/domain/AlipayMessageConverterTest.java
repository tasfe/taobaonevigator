package com.walmart.paymentgateway.service.provider.alipay.domain;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.HttpService;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.provider.alipay.AlipayMessageConverter;
import com.walmart.paymentgateway.service.provider.alipay.domain.Alipay;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * This  class is responsible for testing marshalling ALIPAY response XML to JAX objects 
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class AlipayMessageConverterTest {

	@Autowired
	HttpService httpService;
	@Autowired	
	Jaxb2Marshaller alipayDomainMarshaller;
	@Autowired	
	AlipayMessageConverter alipayMessageConverter;
	@Test
	public void testAlipayMessageConverterInvoked(){
		
		AlipayMessageConverter alipayMessageConverterMock = mock(AlipayMessageConverter.class);
		String responseXML ="mock response";
		alipayMessageConverterMock.convertAlipayResponse(responseXML);
		verify(alipayMessageConverterMock,times(1)).convertAlipayResponse(responseXML);
		
	}
	@Test
	public void testAlipayAPICancelResponse(){
		
		
		String cancelURL = "https://www.alipay.com/cooperate/gateway.do?_input_charset=gbk&service=close_trade&out_order_no=d88adc68-4595-49e0-a9d8-ee9c09bb32db&partner=2088101568353491&sign=4bfdb6f147f296bf839e358c88ef15bd&sign_type=MD5";
		String response = httpService.executeGetMethod(cancelURL);
		assertNotNull(response);
		LogSupport.info("Cancel Interface ALIPAY response "+response);
		Alipay alipay = alipayMessageConverter.convertAlipayResponse(response);
		assertNotNull(alipay);
		assertEquals("F",alipay.getIsSuccess());
		assertEquals("TRADE_NOT_EXIST",alipay.getError());
		
	}
	
	@Test
	public void testAlipayAPIQueryResponsetradenotexist(){
		
		
		String cancelURL = "https://www.alipay.com/cooperate/gateway.do?_input_charset=gbk&service=single_trade_query&partner=2088101568353491&out_trade_no=125&sign=b3d292f267e8cb793f063e3a8cf3dee6&sign_type=MD5";
		String response = httpService.executeGetMethod(cancelURL);
		LogSupport.info("Query Interface ALIPAY TRADE_NOT_EXIST response "+response);
		Alipay alipay = alipayMessageConverter.convertAlipayResponse(response);
		assertNotNull(alipay);
		assertEquals("F",alipay.isSuccess);
		assertEquals("TRADE_NOT_EXIST",alipay.error);
		
	}
	@Test
	public void testAlipayAPIQueryResponsetradefinished(){
		
		
		String cancelURL = "https://www.alipay.com/cooperate/gateway.do?_input_charset=gbk&service=single_trade_query&partner=2088101568353491&out_trade_no=110&sign=ca276a0b1d1ce1648d4ec23f8214e405&sign_type=MD5";
		String response = httpService.executeGetMethod(cancelURL);
		LogSupport.info("Query Interface ALIPAY TRADE_FINISHED response "+response);
		Alipay alipay = alipayMessageConverter.convertAlipayResponse(response);
		assertNotNull(alipay);
		assertEquals("T",alipay.isSuccess);
		assertNotNull(alipay.request);
		assertNotNull(alipay.response);
		assertNotNull(alipay.response.trade);
		assertEquals("TRADE_FINISHED",alipay.response.trade.tradeStatus);
		
	}

}
