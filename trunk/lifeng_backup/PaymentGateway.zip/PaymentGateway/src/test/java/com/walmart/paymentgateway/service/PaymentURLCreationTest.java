package com.walmart.paymentgateway.service;

import java.math.BigDecimal;
import java.util.Map;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.service.domain.Customer;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;
import com.walmart.paymentgateway.common.util.UriToMapUtil;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional

public class PaymentURLCreationTest  extends  TestCase{

	
	@Autowired
	private PaymentRequestService paymentRequestService;
	@Autowired
	private UriToMapUtil  uriToMapUtil;
	
	@Test
	public void test() {
		
		PaymentRequest  request= createPaymentServiceRequest();
		PaymentResponse paymentResponse = paymentRequestService.handlePaymentRequest(request);
		String out_trade_no = paymentResponse.getPayUrlResponse().get(0).getTransactionId();
		
		Map<String, String> map;
		String input_charset="UTF-8";
		String urlResponse =paymentResponse.getPayUrlResponse().get(0).getPaymentURL(); 
		map = uriToMapUtil.convertUriToMap(urlResponse,input_charset);
		assertNotNull(map);

		assertEquals("https://www.walmart.cn?orderId=o1234", map.get("return_url"));
		
	}

	
		
	private PaymentRequest  createPaymentServiceRequest()
	{
		ObjectFactory reqfactory = new ObjectFactory();
		PaymentRequest paymentRequestType = reqfactory.createPaymentRequest();

		PayUrlRequest payUrlType = reqfactory.createPayUrlRequest();
		payUrlType.setPayURLServiceCode("ALP-DIRECT");
		payUrlType.setReturnUrl("https://www.walmart.cn");

		payUrlType.setAmount(new BigDecimal("0.01"));
		payUrlType.setCorrelationId("payURL1233");
		payUrlType.setChannel("ONLINE.ESTORE");

		Customer customerType = reqfactory.createCustomer();
		customerType.setCustomerId("prof1233");
		
		
		paymentRequestType.setCustomer(customerType);
		paymentRequestType.setOrderId("o1234");
		paymentRequestType.setDomain("WALMART.CN");
		paymentRequestType.setOriginator("ESTORE");
		paymentRequestType.getPayUrlRequest().add(payUrlType);
			
		return paymentRequestType;
		
	}

	
	
}
