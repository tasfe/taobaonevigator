package com.walmart.paymentgateway;


public class PaymentGatewayServiceTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {/*
		
		PaymentApplicationService service = new PaymentApplicationServiceImpl(); 
		PaymentRequestHelper helper = new PaymentRequestHelper();
		
		
				String reqXML = JAXBPaymentService.marshalPaymentRequest(helper.createPaymentServiceRequest());
				System.out.println("Request XML "+reqXML);
				PaymentResponse serviceResponse = service.handlePaymentRequest(helper.createPaymentServiceRequest());
				System.out.println("response  "+serviceResponse);
				String resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
				System.out.println("Response XML"+resXML);

				System.out.println("*****************************");
				
				reqXML = JAXBPaymentService.marshalPaymentRequest(helper.createAlipayBankRequest());
				System.out.println("Request XML "+reqXML);
				serviceResponse = service.handlePaymentRequest(helper.createAlipayBankRequest());
				System.out.println("response  "+serviceResponse);
				resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
				System.out.println("Response XML"+resXML);
				
				System.out.println("*****************************");

				reqXML = JAXBPaymentService.marshalPaymentRequest(helper.createCodRequest());
				System.out.println("Request XML "+reqXML);
				serviceResponse = service.handlePaymentRequest(helper.createCodRequest());
				System.out.println("response  "+serviceResponse);
				resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
				System.out.println("Response XML"+resXML);

				System.out.println("*****************************");

				reqXML = JAXBPaymentService.marshalPaymentRequest(helper.invalidPayCode());
				System.out.println("Request XML "+reqXML);
				serviceResponse = service.handlePaymentRequest(helper.invalidPayCode());
				System.out.println("response  "+serviceResponse);
				resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
				System.out.println("Response XML"+resXML);
				
				
	*/}
}
	


