package com.walmart.paymentgateway.message.listener;



import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.jms.Destination;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.service.domain.PaymentNotification;

/**
 * This test class create an expected notification xml from webservice gateway and put the xml message
 * as text message to Payment Notification Queue
 * @author Raju Thomas
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = false)
@Transactional
public class PaymentNotificationListenerTest extends TestCase{

	
	@Autowired 
	JmsTemplate jmsTemplate; 
	PaymentNotification message = null;
	@Autowired
	@Qualifier("queueForPaymentNotificationReceive")
	Destination destination;
	@Test
	public void testPaymentNotificationListenerInvoked(){
		message = createMessage();
		assertNotNull(message);
		MessageListenerDelegate mockPaymentNotificationListener = mock(MessageListenerDelegate.class);
		mockPaymentNotificationListener.receive(message);
		verify(mockPaymentNotificationListener,times(1)).receive(message);
	}
	@Test
	@Transactional
	public void testPaymentNotificationSending(){
		
		message = createMessage();
		assertNotNull(message);
		this.jmsTemplate.convertAndSend(destination, message);
	}
	
	private PaymentNotification createMessage(){
		
		//String notificationMsg = "<![CDATA[body=%C9%BD%C4%B7%BB%E1%D4%B1%B5%EA%C9%CC%C6%B7&buyer_email=wangjinmin1982%40126.com&buyer_id=2088002053153634&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7w41DsRNMB%252BkKm21YuO3Xg1T8kTxKpJUSKn51yGEz19iv9ZWPK&notify_time=2011-09-16+05%3A01%3A12&notify_type=trade_status_sync&out_trade_no=cd85b3a3-2592-4521-b68c-41e1524b9ee0&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=PANDA&total_fee=0.02&trade_no=2011091652081863&trade_status=TRADE_SUCCESS&sign=7844626de89cd309596e0dbfbf01e9f4&sign_type=MD5]]>";
		String notificationMsg = "http://vrthomas.corp.walmart.com:8080/Alipay/AlipayResponse?body=sams+club+merchantise&buyer_email=alipay_test%40alipay.com&buyer_id=2088102151633543&exterface=create_direct_pay_by_user&is_success=T&notify_id=RqPnCoPT3K9%252Fvwbh3I7xs9gugL7HLNNKl1byWwKHAnXtM9DN3WNGw1wRoXyq36s%252BvZZu&notify_time=2011-03-25+02%3A02%3A52&notify_type=trade_status_sync&out_trade_no=51fee019-6fba-4af4-b96e-1c52cddcd9b5&payment_type=1&seller_email=alipay-test07%40alipay.com&seller_id=2088101568353491&subject=sams+club&total_fee=1.00&trade_no=2011032546320854&trade_status=TRADE_SUCCESS&sign=d2e31071f004201f92dcbc111324901a&sign_type=MD5";
		PaymentNotification paymentNotification  = new PaymentNotification();
		paymentNotification.setProvider("ALIPAY");
		paymentNotification.setMessage(notificationMsg);
		return paymentNotification;
	}
	
	
}
