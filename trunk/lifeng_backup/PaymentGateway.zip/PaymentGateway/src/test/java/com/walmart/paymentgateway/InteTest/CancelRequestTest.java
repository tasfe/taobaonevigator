/**
 * 
 */
package com.walmart.paymentgateway.InteTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.JAXBPaymentService;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.CancelRequestService;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;

/**
 * @author sgopisetty
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = false)
@Transactional
public class CancelRequestTest {
	
	@Autowired
	private CancelRequestService cancelRequestService;

	@Test
	public void test() {
		
		CancelRequest  request= createMessage();
		String reqXML =  JAXBPaymentService.marshalCancelRequest(request);
		LogSupport.debug("CANCEL Request "+reqXML);
		System.out.println("Request XML "+reqXML);
		CancelResponse serviceResponse = cancelRequestService.handleCancelRequest(request);
		//CancelTransactionResponse cancelTransRes = serviceResponse.getCancelTransactionResponse().get(0);
		String resXML = JAXBPaymentService.marshalCancelResponse(serviceResponse);
		System.out.println("response  "+resXML);

	}
	private CancelRequest createMessage(){
		
		CancelRequest message  = new CancelRequest();
		message.setOrderId("o1234");
		message.setOriginator("ESTORE");
		CancelTransactionRequest transaction = new CancelTransactionRequest();
		transaction.setTransactionId("d88adc68-4595-49e0-a9d8-ee9c09bb32db");
		transaction.setForceRefund(Boolean.FALSE);
		message.getCancelTransactionRequest().add(transaction);
		return message;
}

}
