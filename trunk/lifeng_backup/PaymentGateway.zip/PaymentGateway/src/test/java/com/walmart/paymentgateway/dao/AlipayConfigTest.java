/**
 * 
 */
package com.walmart.paymentgateway.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;
import com.walmart.paymentgateway.service.provider.alipay.AlipayDaoManager;

import junit.framework.TestCase;

/**
 * @author sgopisetty
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
public class AlipayConfigTest extends TestCase {
	
	
	@Autowired
	private AlipayDaoManager alipayTransactionTools;
	@Test
	public void findAlipayConfigTest() {
		AlipayAccountConfigEntity config = null;
		config = alipayTransactionTools.findAlipayConfig("ONLINE.ESTORE");
		assertNotNull(config);
	}

}
