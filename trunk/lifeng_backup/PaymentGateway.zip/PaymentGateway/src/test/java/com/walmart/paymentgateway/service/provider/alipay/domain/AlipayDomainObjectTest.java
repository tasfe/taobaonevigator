package com.walmart.paymentgateway.service.provider.alipay.domain;

import static org.junit.Assert.*;

import java.io.StringWriter;

import javax.xml.transform.stream.StreamResult;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.provider.alipay.domain.Alipay;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class AlipayDomainObjectTest {
	
	@Autowired	
	Jaxb2Marshaller alipayDomainMarshaller ;
	
	@Test
	public void createAlipayCancelFailResponse(){
			
			Alipay alipay  = new Alipay();
			alipay.setError("TRADE_NOT_EXIST");
			alipay.setIsSuccess("F");
			StringWriter out = new StringWriter();
			alipayDomainMarshaller.marshal(alipay, new StreamResult(out));
			LogSupport.info(out.toString());
			assertNotNull(out.toString());
	}
	@Test
	public void createAlipayCancelFailTradeClosedResponse(){
		
		Alipay alipay  = new Alipay();
		alipay.setError("TRADE_CLOSED");
		alipay.setIsSuccess("F");
		StringWriter out = new StringWriter();
		alipayDomainMarshaller.marshal(alipay, new StreamResult(out));
		LogSupport.info(out.toString());
		assertNotNull(out.toString());
	}
	@Test
	public void createAlipayCancelFailTradeFinishedResponse(){
		
		Alipay alipay  = new Alipay();
		alipay.setError("TRADE_FINISHED");
		alipay.setIsSuccess("F");
		StringWriter out = new StringWriter();
		alipayDomainMarshaller.marshal(alipay, new StreamResult(out));
		LogSupport.info(out.toString());
		assertNotNull(out.toString());
	}
	@Test
	public void createAlipayCancelSuccessResponse(){
		
		Alipay alipay  = new Alipay();
		alipay.setIsSuccess("T");
		StringWriter out = new StringWriter();
		alipayDomainMarshaller.marshal(alipay, new StreamResult(out));
		LogSupport.info(out.toString());
		assertNotNull(out.toString());
	}
	@Test
	public void createAlipayQueryResponse(){
			
			Alipay alipay  = new Alipay();
			alipay.setIsSuccess("T");
			StringWriter out = new StringWriter();
			alipayDomainMarshaller.marshal(alipay, new StreamResult(out));
			LogSupport.info(out.toString());
			assertNotNull(out.toString());
	}

}
