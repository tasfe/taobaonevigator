package com.walmart.paymentgateway;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;


@Component("messageHandleService")

public class JAXBPaymentService {

    public static PaymentRequest getRequestFromXml(String xml) throws Exception{
		InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
		JAXBContext context = JAXBContext.newInstance("com.walmart.paymentgateway.service.domain");
		Unmarshaller u = context.createUnmarshaller();
		PaymentRequest request = (PaymentRequest)u.unmarshal(is);
		return request;
	}
    public static PaymentResponse getPaymentResponseFromXml(String xml) throws UnsupportedEncodingException, JAXBException {
		InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
		JAXBContext context = JAXBContext.newInstance("com.walmart.paymentgateway.service.domain");
		Unmarshaller u = context.createUnmarshaller();
		PaymentResponse response = (PaymentResponse)u.unmarshal(is);
		return response;
		
	}
    public static CancelResponse getCancelResponseFromXml(String xml) throws UnsupportedEncodingException, JAXBException {
		InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
		JAXBContext context = JAXBContext.newInstance("com.walmart.paymentgateway.service.domain");
		Unmarshaller u = context.createUnmarshaller();
		CancelResponse response = (CancelResponse)u.unmarshal(is);
		return response;
		
	}
  
	public static String marshalPaymentRequest(PaymentRequest request) {
		String result = null;

		try {

			JAXBContext jc = JAXBContext
					.newInstance("com.walmart.paymentgateway.service.domain");
			Marshaller m = jc.createMarshaller();
			StringWriter writer = new StringWriter();
			m.marshal(request, writer);
			result = writer.toString();
		} catch (JAXBException e) {
			throw new RuntimeException(
					"Can't marshal the XML file, error message: "
							+ e.getMessage());
		}
		return result;

	}
	public static String marshalCancelRequest(CancelRequest request) {
		String result = null;

		try {

			JAXBContext jc = JAXBContext
					.newInstance("com.walmart.paymentgateway.service.domain");
			Marshaller m = jc.createMarshaller();
			StringWriter writer = new StringWriter();
			m.marshal(request, writer);
			result = writer.toString();
		} catch (JAXBException e) {
			throw new RuntimeException(
					"Can't marshal the XML file, error message: "
							+ e.getMessage());
		}
		return result;

	}
	
	public static  String marshalCancelResponse(CancelResponse response) {   
        String result = null;   
           
        try {   
        	JAXBContext jc = JAXBContext.newInstance("com.walmart.paymentgateway.service.domain");
            Marshaller m = jc.createMarshaller();   
                           StringWriter writer = new StringWriter();                  
            m.marshal(response, writer);                  
            result = writer.toString();   
            } catch (JAXBException e) 
            {               
            	throw new RuntimeException("Can't marshal the XML file, error message: " + e.getMessage());   
            }  
            return result;

	}

    public static  String marshalPaymentResponse(PaymentResponse response) {   
        String result = null;   
           
        try {   
        	JAXBContext jc = JAXBContext.newInstance("com.walmart.paymentgateway.service.domain");
            Marshaller m = jc.createMarshaller();   
                           StringWriter writer = new StringWriter();                  
            m.marshal(response, writer);                  
            result = writer.toString();   
            } catch (JAXBException e) 
            {               
            	throw new RuntimeException("Can't marshal the XML file, error message: " + e.getMessage());   
            }  
            return result;

	} 
  
}
