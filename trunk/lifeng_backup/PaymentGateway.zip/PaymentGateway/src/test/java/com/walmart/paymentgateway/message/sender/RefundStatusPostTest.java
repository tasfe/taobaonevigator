package com.walmart.paymentgateway.message.sender;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import junit.framework.TestCase;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.RefundResponse;
import com.walmart.paymentgateway.service.domain.RefundTransactionResponse;


@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
public class RefundStatusPostTest extends TestCase{

	
	
	@Autowired
	AbstractMessageSender  refundStatusSender;
	@Autowired
	JmsTemplate jmsTemplate;
	
	@Autowired 
	@Qualifier("queueForRefundStatusPost")
	protected Destination destination;
	
	RefundResponse message ;

	@Test
	public void testPaymentNotificationSenderInvoked(){
		message = createMessage();
		assertNotNull(message);
		AbstractMessageSender mockSender = mock(RefundStatusSender.class);
		mockSender.sendMessage(message);
		verify(mockSender,times(1)).sendMessage(message);
	}
	@Test
	public void testCancelRequestSending(){
		message = createMessage();
		assertNotNull(message);
		refundStatusSender.sendMessage(message);
		
	}
	private RefundResponse createMessage(){
		
		RefundResponse refundResponse = new RefundResponse();
		refundResponse.setOrderId("O12345");
		refundResponse.setResponseStatus("SUCCESS");
		RefundTransactionResponse transaction = new RefundTransactionResponse();
		transaction.setAmountRefunded(new BigDecimal("0.01"));
		transaction.setTransactionId("4444-5555-abcd-8888");
		transaction.setTransactionStatus("SUCCESS");
		transaction.setTransactionStatusCode("COMPLETED");
		refundResponse.getRefundTransactionResponse().add(transaction);
		return refundResponse;
	}
	@Test
	public void readMessage()
	{

		Message message = jmsTemplate.receive(destination);
	    TextMessage textMessage = null;
	    assertNotNull(message);
		if (message instanceof TextMessage)
		 {
		            textMessage = (TextMessage)message;
		            try
		            {
		                assertNotNull(textMessage.getText());
		                LogSupport.info("Refund Response Message Read From Queue :"+textMessage.getText());
		            }catch (JMSException e)
		            {
		                fail(e.getMessage());
		            	e.printStackTrace();
		            }
		   }else{
			   
			   Assert.fail();
		   }
		
	
	}
}
