/**
 * 
 */
package com.walmart.paymentgateway.InteTest;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.JAXBPaymentService;
import com.walmart.paymentgateway.PaymentRequestHelper;
import com.walmart.paymentgateway.service.PaymentRequestService;
import com.walmart.paymentgateway.service.domain.PaymentResponse;

/**
 * @author enduser
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = false)
@Transactional
public class ServiceLayerTesting extends TestCase {
	
	
	@Autowired
	private PaymentRequestService paymentRequestService; 
	@Autowired
	private PaymentRequestHelper paymentRequestHelper;
	
	/*private  paymentRequestService  
	PaymentRequestHelper paymentRequestHelper = new PaymentRequestHelper();
*/	/**
	 * <pre>
	 * 
	 * </pre>
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * <pre>
	 * 
	 * </pre>
	 * 
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	@Transactional
	public void testServiceToDao(){
	
	String reqXML = JAXBPaymentService.marshalPaymentRequest(paymentRequestHelper.createPaymentServiceRequest());
	System.out.println("Request XML "+reqXML);
	PaymentResponse serviceResponse = paymentRequestService.handlePaymentRequest(paymentRequestHelper.createPaymentServiceRequest());
	System.out.println("response  "+serviceResponse);
	String resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
	System.out.println("Response XML"+resXML);

	System.out.println("*****************************");

	reqXML = JAXBPaymentService.marshalPaymentRequest(paymentRequestHelper.createAlipayBankRequest());
	System.out.println("Request XML "+reqXML);
	serviceResponse = paymentRequestService.handlePaymentRequest(paymentRequestHelper.createAlipayBankRequest());
	System.out.println("response  "+serviceResponse);
	resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
	System.out.println("Response XML"+resXML);

	System.out.println("*****************************");
	/*
	reqXML = JAXBPaymentService.marshalPaymentRequest(paymentRequestHelper.createCodRequest());
	System.out.println("Request XML "+reqXML);
	serviceResponse = paymentRequestService.handlePaymentRequest(paymentRequestHelper.createCodRequest());
	System.out.println("response  "+serviceResponse);
	resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
	System.out.println("Response XML"+resXML);

	System.out.println("*****************************");

	reqXML = JAXBPaymentService.marshalPaymentRequest(paymentRequestHelper.invalidPayCode());
	System.out.println("Request XML "+reqXML);
	serviceResponse = paymentRequestService.handlePaymentRequest(paymentRequestHelper.invalidPayCode());
	System.out.println("response  "+serviceResponse);
	resXML = JAXBPaymentService.marshalPaymentResponse(serviceResponse);
	System.out.println("Response XML"+resXML);
		*/
		

	}
		
}
