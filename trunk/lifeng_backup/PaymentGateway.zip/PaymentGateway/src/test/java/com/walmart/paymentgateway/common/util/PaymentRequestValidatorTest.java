package com.walmart.paymentgateway.common.util;

import junit.framework.TestCase;

public class PaymentRequestValidatorTest  extends TestCase  {/*

	PaymentRequestValidator  validator = new PaymentRequestValidator();

	public void testValidatePayRequest(){
		
		PaymentRequest request = null;
		assertEquals(ReasonCode.INVALID_REQUEST,validator.validateRequest(request));
		request = new PaymentRequest();
		assertEquals(ReasonCode.MISSING_ORDERID,validator.validateRequest(request));
	}
	public void testValidatePayUrlRequest(){
		
		PayUrlRequest request = null;
		assertEquals(ReasonCode.INVALID_TRANSACTION_REQUEST,validator.validatePayUrlRequest(request));
		
	}
	public void testValidateCodRequest(){
		
		CodRequest request  = null;
		assertEquals(ReasonCode.INVALID_TRANSACTION_REQUEST,validator.validateCodRequest(request));
	}
	public void testvalidateTransactionRequest(){
		
		TransactionRequest request = null;
		assertEquals(ReasonCode.MISSING_TRANSACTION_REQUEST,validator.validateTransactionRequest(request));
		request = new TransactionRequest();
		assertEquals(ReasonCode.MISSING_AMOUNT,validator.validateTransactionRequest(request));
		request.setAmount(new BigDecimal("0"));
		assertEquals(ReasonCode.INVALID_AMOUNT,validator.validateTransactionRequest(request));
		request.setAmount(new BigDecimal("0.00"));
		assertEquals(ReasonCode.INVALID_AMOUNT,validator.validateTransactionRequest(request));
		request.setAmount(new BigDecimal("-1"));
		assertEquals(ReasonCode.INVALID_AMOUNT,validator.validateTransactionRequest(request));
		request.setAmount(new BigDecimal("0.000001"));
		assertEquals(ReasonCode.MISSING_CORRELATIONID,validator.validateTransactionRequest(request));
		request.setCorrelationId("pg123");
		assertEquals(ReasonCode.MISSING_PAYSERVICE_CODE,validator.validateTransactionRequest(request));
		ServiceCode code  = new ServiceCode();
		request.setPaymentServiceCode(code);
		assertEquals(ReasonCode.MISSING_TENANT,validator.validateTransactionRequest(request));
		request.setTenant("TENANT");
		assertEquals(ReasonCode.INVALID_TRANSACTION_REQUEST,validator.validateTransactionRequest(request));
		PayUrlRequest payRequest = new PayUrlRequest();
		payRequest.setPayURLServiceCode("ALP-NBBANK");
		payRequest.setReturnUrl("https://www.walmart.cn/");
		ServiceCode cod = new ServiceCode();
		code.setPayUrlRequest(payRequest);
		request.setPaymentServiceCode(cod);
		
	}
*/}
