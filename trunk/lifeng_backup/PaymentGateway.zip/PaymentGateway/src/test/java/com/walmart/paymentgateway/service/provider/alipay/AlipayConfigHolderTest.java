package com.walmart.paymentgateway.service.provider.alipay;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/testApplicationContext.xml")
@TransactionConfiguration(transactionManager = "testjpaTxManager", defaultRollback = true)
@Transactional
public class AlipayConfigHolderTest extends TestCase{

	
	@Autowired
	AlipayConfigHolder alipayConfigHolder;
	@Test
	public void getAlipayConfigParamTestWithInvalidValues(){
		
		AlipayAccountConfigEntity alipayAccountConfigEntity = alipayConfigHolder.getAlipayConfigParam("TESTTENANT");
		assertNull(alipayAccountConfigEntity);
	}
	
	@Test
	public void getAlipayConfigParamTest(){
		
		AlipayAccountConfigEntity alipayAccountConfigEntity = alipayConfigHolder.getAlipayConfigParam("ONLINE.ESTORE");
		assertNotNull(alipayAccountConfigEntity);
		assertEquals("ONLINE.ESTORE", alipayAccountConfigEntity.getChannelLk().getName());
	}
	
}
