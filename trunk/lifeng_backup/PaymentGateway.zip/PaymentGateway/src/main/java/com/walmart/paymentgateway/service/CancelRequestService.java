package com.walmart.paymentgateway.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.builder.CancelResponseBuilder;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.TransactionConstant;
import com.walmart.paymentgateway.common.util.TransactionLogger;
import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.message.sender.RefundRequestSender;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.processor.PaymentProcessor;
import com.walmart.paymentgateway.processor.ServiceManager;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.provider.alipay.AlipayConstant;
import com.walmart.paymentgateway.service.util.ReasonCode;
import com.walmart.paymentgateway.validator.CancelRequestValidator;

@Component("cancelRequestService")
public class CancelRequestService implements ICancelRequestService {
	
	@Autowired
	private DaoManager transactionalTools;
	@Autowired @Qualifier("transactionLogger")
	private TransactionLogger transactionLogger;
	@Autowired
	private ServiceManager serviceManager;
	@Autowired
	private CancelResponseBuilder builder;
	@Autowired
	private CancelRequestValidator cancelRequestValidator;
	@Autowired
	private RefundRequestSender refundRequestSender;
	@Autowired
	private PaymentProcessor  processor;
	
	/***
	 * 
	 */
	@Override
	public CancelResponse handleCancelRequest(CancelRequest pCancelRequest ) {
		
		LogSupport.debug("Start handleCancelRequest () ");
		
		String intercorrelationId = null;
		boolean isvalid = true;
		String providerType = null;
		TransactionEntity transactionEntity = null;
		List<TransactionEntity> refundTransactionList = new ArrayList<TransactionEntity>();
		builder = new CancelResponseBuilder();
		CancelTransactionResponse cancelTransactionResponse = null;
		String status = null;
		String transactionStatus = null;
		String cancelStatus = null;
		String cancelStatusCode = null;
		boolean isForceRefund = false;
		String orderId =  null;
		com.walmart.paymentgateway.service.domain.Error resErr = null;
		
		status = cancelRequestValidator.validateCancelRequest(pCancelRequest);
		populateCancelResponse(builder, pCancelRequest);
		LogSupport.debug("validateCancelRequest status::" + status);

		List<CancelTransactionRequest> cancelRequestList = pCancelRequest.getCancelTransactionRequest();
		
		if(status.equalsIgnoreCase(ReasonCode.PASS)) {
			orderId = pCancelRequest.getOrderId();
			isvalid = cancelRequestValidator.checkOrderExist(orderId);
			LogSupport.debug("Is it Valid Order ::" + isvalid);
			if (!isvalid) {
				builder.buildHeaderErrorResponse(ReasonCode.ORDER_NOT_FOUND, ReasonCode.VALIDATION_FAILED, ReasonCode.ERROR);
				
				return returnCancelResponse(builder);
			}
		} else {
			builder.buildHeaderErrorResponse(status, ReasonCode.VALIDATION_FAILED, ReasonCode.ERROR);
			
			return returnCancelResponse(builder);
		}
		if(cancelRequestList != null && cancelRequestList.size() > 0) {
			LogSupport.debug("Cancel transaction request size ::" + cancelRequestList.size());
			for (CancelTransactionRequest cancelTransactionRequest : cancelRequestList) {
				intercorrelationId = cancelTransactionRequest.getTransactionId();
				transactionStatus = cancelRequestValidator.validateCancelTransactionRequest(cancelTransactionRequest);
				if(!transactionStatus.equalsIgnoreCase(ReasonCode.PASS)) {
					LogSupport.debug("Cancel transaction validation failed for::" + transactionStatus);
					builder.buildTransactionErrorResponse(intercorrelationId, transactionStatus, ReasonCode.VALIDATION_FAILED);
					builder.getCancelResponse().setResponseStatus(ReasonCode.ERROR);
					return returnCancelResponse(builder);
				}
				//validate intercorrelationId with against to orderNo.
				transactionEntity = transactionalTools.findTransactionForOrderId(orderId, intercorrelationId);
				if (null != transactionEntity) {
					LogSupport.debug("Transaction Id for the CancelRequest ::" + transactionEntity.getTransactionPk());
					LogSupport.debug("Intercorrelation Id for the CancelRequest ::" + transactionEntity.getIntCorrelationId());
					transactionStatus = transactionEntity.getTransactionStatus().getName();
					LogSupport.debug("Current Transaction Status for the CancelRequest ::" + transactionStatus);
					if (!transactionStatus.equalsIgnoreCase(ReasonCode.CANCEL)) {
						providerType = transactionalTools.findSrvProviderForTransaction(transactionEntity);
						LogSupport.debug("Provider for the CancelRequest ::" + providerType);
						if (null != providerType ) {
							//paymentProcessor = factory.getProcessorInstance(providerType);

							cancelTransactionResponse = builder.createCancelTransactionResponse();
							LogSupport.debug("Starting processing CancelRequest......");
							//process cancel Request
							processor.processCancelRequest(cancelTransactionRequest, cancelTransactionResponse );
							cancelStatus = cancelTransactionResponse.getTransactionStatus();
							cancelStatusCode = cancelTransactionResponse.getTransactionStatusCode();
							isForceRefund = cancelTransactionRequest.isForceRefund();
							LogSupport.debug("Status of CancelRequest set by processor::" + cancelStatus);
							LogSupport.debug("StatusCode of CancelRequest from provider::" + cancelStatusCode);
							LogSupport.debug("isForceRefund of CancelRequest ::" + isForceRefund);
							
							if (!StringUtils.isBlank(cancelStatus) && cancelStatus.equalsIgnoreCase(ReasonCode.NOT_COMPLETED)) {
								
								if (isTradeSucess(cancelStatusCode) && isForceRefund) {
									LogSupport.debug("Adding cancelTransaction request for Refund");
									refundTransactionList.add(transactionEntity);
									setTransactionCancelled(transactionEntity, cancelTransactionResponse, cancelStatusCode);
								} else if (isTradeSucess(cancelStatusCode) && !isForceRefund) {
									LogSupport.debug("Unable to issue refund since isForceRefund is false");
									cancelTransactionResponse.setTransactionStatus(ReasonCode.FAIL);
									cancelTransactionResponse.setTransactionStatusCode(ReasonCode.FAIL);
									//update Pg transaction status to cancel and in event tbl comments field need to be update with error/transactionstatuscode
									transactionLogger.logTransactionEvent(transactionEntity,ReasonCode.CANCELLED_FAILED, cancelStatusCode);
									//serviceResponseStatus = ReasonCode.FAIL;
								} else {
									LogSupport.debug("Trade not found or invalid Trade, hence cancel the transaction");
									setTransactionCancelled(transactionEntity, cancelTransactionResponse, cancelStatusCode);
								}
								
							} else if (cancelStatus.equalsIgnoreCase(ReasonCode.FAIL)) {
								cancelStatusCode = ReasonCode.ERR_CONNECTION_TIME_OUT;
								resErr = builder.createErroResponse(cancelStatusCode, null );
								cancelTransactionResponse.setTransactionStatus(ReasonCode.FAIL);
								cancelTransactionResponse.setTransactionStatusCode(ReasonCode.FAIL);
								cancelTransactionResponse.setError(resErr);
								LogSupport.debug("Error occured while proccessing requst with provider due to ::" + cancelStatusCode);
								transactionLogger.logTransactionEvent(transactionEntity,TransactionConstant.EVENT_ERROR, cancelStatusCode);
								
							} else if (cancelStatus.equalsIgnoreCase(ReasonCode.SUCCESS)) {
								LogSupport.debug("updating Transaction to cancel and creating event for status::" + cancelStatusCode);
								setTransactionCancelled(transactionEntity, cancelTransactionResponse, "Sucessfully cancelled by the provider");
							}
						
						
						} else {
							LogSupport.debug("Validation failed:: ReasonCode:: " + ReasonCode.UNSUPPORTED_PROVIDER);
							builder.buildTransactionErrorResponse(intercorrelationId, ReasonCode.UNSUPPORTED_PROVIDER, ReasonCode.VALIDATION_FAILED );
						}
						
					} else {
						LogSupport.debug("Validation failed:: ReasonCode:: " + ReasonCode.TRANSACTION_ALREADY_CANCEL);
						builder.buildTransactionErrorResponse(intercorrelationId, ReasonCode.TRANSACTION_ALREADY_CANCEL, ReasonCode.VALIDATION_FAILED );
					}
				
				} else {
					LogSupport.debug("Validation failed:: ReasonCode:: " + ReasonCode.TRANSACTION_NOT_FOUND);
					builder.buildTransactionErrorResponse(intercorrelationId, ReasonCode.TRANSACTION_NOT_FOUND, ReasonCode.VALIDATION_FAILED);
					
				}
				//add transactionResponse to response object
				LogSupport.debug("Adding cancelTransactionResponse to CancelResonse ");
				builder.addToCancelResponse(cancelTransactionResponse);
				//add to response
				
			}
			
			if (!refundTransactionList.isEmpty() && refundTransactionList.size() > 0) {
				LogSupport.debug("initiateingRefund Request from handleCancelRequest ()... ");
				LogSupport.debug("Refund Request size ::" + refundTransactionList.size());
				initiateRefund(refundTransactionList, AlipayConstant.TRADE_FINISHED);
			}
		} else {
			LogSupport.debug("Cancel transaction request is empty" );
			builder.buildHeaderErrorResponse(ReasonCode.MISSING_TRANSACTION_REQUEST, ReasonCode.VALIDATION_FAILED, ReasonCode.ERROR);
			return returnCancelResponse(builder);
		}
		
		setResponseStatusCode(builder);
		LogSupport.debug("Existing from handleCancelRequest () ");
		return returnCancelResponse(builder);
	}
	
	
	
	private void setTransactionCancelled(TransactionEntity pTransactionEntity, 
										CancelTransactionResponse pTransactionResponse, String pStatusCode) {
		LogSupport.debug("inside CancelRequestService.setTransactionCancelled");
		LogSupport.debug("setting Transaction status for pStatusCode::" + pStatusCode);
		pTransactionResponse.setTransactionStatus(ReasonCode.SUCCESS);
		pTransactionResponse.setTransactionStatusCode(ReasonCode.CANCEL);
		//update Pg transaction status to cancel and in event tbl comments field need to be update with error/transactionstatuscode
		transactionalTools.createOrUpateTransaction(pTransactionEntity, null, ReasonCode.CANCEL);
		transactionLogger.logTransactionEvent(pTransactionEntity,TransactionConstant.EVENT_CANCELLED, pStatusCode);
		LogSupport.debug("Existing from CancelRequestService.setTransactionCancelled");
	}
	/**
	 * 
	 * @param pStatus
	 * @return
	 */
	private boolean isTradeSucess(String pStatus) {
		LogSupport.debug("Inside CancelRequestService.isTradeSucess::" + pStatus);
		if( ((pStatus.equalsIgnoreCase(AlipayConstant.TRADE_FINISHED))||
				pStatus.equalsIgnoreCase(AlipayConstant.TRADE_SUCCESS)))
		{
			LogSupport.debug("return from CancelRequestService.isTradeSucess:: true");
			return true;
		}
		LogSupport.debug("return from CancelRequestService.isTradeSucess:: false");
		return false;
	}
	/***
	 * 
	 * @param pRefundTransactionRequest
	 * @param pReasonCode
	 */
	private void initiateRefund(List<TransactionEntity> pRefundTransactionRequest, String pReasonCode) {
		LogSupport.debug("inside CancelRequestService.initiateRefund....");
		RefundRequest refundRequest= serviceManager.createRefundRequest(pRefundTransactionRequest, pReasonCode, "PG");
		LogSupport.debug(".....sending Refund Request Message....");
		refundRequestSender.sendMessage(refundRequest);
		LogSupport.debug("return from CancelRequestService.initiateRefund....");
	}
	
	/***
	 * 
	 * @param builder
	 * @param responseCode
	 * @param status
	 */
	public void setResponseStatusCode(CancelResponseBuilder pBuilder){
		LogSupport.debug("inside CancelRequestService.setResponseStatusCode....");
		List<CancelTransactionResponse> cancelResponse = null;
		cancelResponse = pBuilder.getCancelResponse().getCancelTransactionResponse();
		String status = null;
		for (CancelTransactionResponse cancelTransactionResponse : cancelResponse) {
			status = cancelTransactionResponse.getTransactionStatus();
			if (!status.equalsIgnoreCase(ReasonCode.SUCCESS)) {
				break;
			}
		}
		LogSupport.debug("CancelRequestService.setResponseStatusCode....::" + status);
		pBuilder.getCancelResponse().setResponseStatus(status);
		LogSupport.debug("exist from CancelRequestService.setResponseStatusCode....");
	}
	private void populateCancelResponse(CancelResponseBuilder cancelResponseBuilder, CancelRequest cancelRequest){
		cancelResponseBuilder.getCancelResponse().setOrderId(cancelRequest.getOrderId());
	}
	private CancelResponse returnCancelResponse(CancelResponseBuilder cancelResponseBuilder) {
		return cancelResponseBuilder.getCancelResponse();
	}

}
