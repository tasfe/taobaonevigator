package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the TRANSACTION_EVENT database table.
 * 
 */
@Entity
@Table(name="TRANSACTION_EVENT")
public class TransactionEventEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="TRANSACTION_EVENT_PK_GENERATOR", sequenceName="TRANSACTION_EVENT_SEQ")
	@GeneratedValue(generator="TRANSACTION_EVENT_PK_GENERATOR")
	@Column(name="TRANSACTION_EVENT_PK")
	private Long transactionEventPk;

	@Column(name="COMMENTS")
	private String comment;

	//bi-directional many-to-one association to TpReqResDetailEntity
	@OneToMany(mappedBy="transactionEvent")
	private Set<TpReqResDetailEntity> tpReqResDetails;

	//bi-directional many-to-one association to TransactionEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_FK")
	private TransactionEntity transaction;

	//bi-directional many-to-one association to TransactionEventStatusEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_EVENT_STATUS_FK")
	private TransactionEventStatusEntity transactionEventStatus;

    public TransactionEventEntity() {
    }

	public Long getTransactionEventPk() {
		return this.transactionEventPk;
	}

	public void setTransactionEventPk(Long transactionEventPk) {
		this.transactionEventPk = transactionEventPk;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Set<TpReqResDetailEntity> getTpReqResDetails() {
		return this.tpReqResDetails;
	}

	public void setTpReqResDetails(Set<TpReqResDetailEntity> tpReqResDetailEntities) {
		this.tpReqResDetails = tpReqResDetailEntities;
	}
	
	public TransactionEntity getTransaction() {
		return this.transaction;
	}

	public void setTransaction(TransactionEntity transactionEntity) {
		this.transaction = transactionEntity;
	}
	
	public TransactionEventStatusEntity getTransactionEventStatus() {
		return this.transactionEventStatus;
	}

	public void setTransactionEventStatus(TransactionEventStatusEntity transactionEventStatusEntity) {
		this.transactionEventStatus = transactionEventStatusEntity;
	}
	
}