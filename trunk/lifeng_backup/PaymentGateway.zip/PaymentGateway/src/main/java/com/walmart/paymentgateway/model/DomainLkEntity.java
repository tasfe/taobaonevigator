package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the DOMAIN_LK database table.
 * 
 */
@Entity
@Table(name="DOMAIN_LK")
public class DomainLkEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="DOMAINPK_GENERATOR", sequenceName="DOMAIN_LK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DOMAINPK_GENERATOR")
	@Column(name="DOMAIN_PK")
	private Long domainPk;

	private String description;

	private String name;

	//bi-directional many-to-one association to AccountEntity
	@OneToMany(mappedBy="domainLk")
	private Set<AccountEntity> accounts;

    public DomainLkEntity() {
    }

	public Long getDomainPk() {
		return this.domainPk;
	}

	public void setDomainPk(Long domainPk) {
		this.domainPk = domainPk;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<AccountEntity> getAccounts() {
		return this.accounts;
	}

	public void setAccounts(Set<AccountEntity> accountEntities) {
		this.accounts = accountEntities;
	}
	
}