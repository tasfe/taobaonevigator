/**
 * 
 */
package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Map;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.BaseEntity;


public interface GenericDao {

	/**
	 * Make an entity instance managed and persistent.
	 * 
	 * @param entity entity object to be managed by the current persistence context
	 * @return managed entity
	 */
	public <T extends BaseEntity> T create(T entity) throws ServiceDataAccessException;
	

	/**
	 * Find by primary key. Search for an entity of the specified class and primary key. 
	 * If the entity instance is contained in the persistence context, it is returned from there. 
	 * 
	 * @param entityId	primary key of entity
	 * @param entityClass	entity class
	 * @return	the found entity instance or null if the entity does not exist 
	 */
	public <T extends BaseEntity> T find(Object entityId, Class<T> entityClass) throws ServiceDataAccessException;
	
	/**
	 * Merge the state of the given entity into the current persistence context.
	 * 
	 * @param entity detached entity object to be merged into the current persistence context
	 * @return the managed instance that the state was merged to
	 */
	public <T extends BaseEntity> T update(T entity) throws ServiceDataAccessException;
	
	/**
	 * Delete the entity instance.
	 * 
	 * @param entityId	primary key of entity
	 * @param entityClass	entity class
	 */
	public <T extends BaseEntity> boolean delete(Object entityId, Class<T> entityClass) throws ServiceDataAccessException;

	public <T extends BaseEntity> List<T> findByNamedQuery(Class<T> entityClass, String namedQuery)throws ServiceDataAccessException;
	public <T extends BaseEntity> List<T> findByNamedQuery(Class<T> entityClass, String namedQuery, Map<String, Object> parameters)throws ServiceDataAccessException;;
	

}
