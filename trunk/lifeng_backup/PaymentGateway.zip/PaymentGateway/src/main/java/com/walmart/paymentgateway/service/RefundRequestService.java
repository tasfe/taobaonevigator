package com.walmart.paymentgateway.service;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundResponse;
/**
 * This component is responsible identifying appropriate refund processor and
 * delegating the request
 * @author Raju Thomas
 *
 */

@Component("refundRequestService")
public class RefundRequestService implements IRefundRequestService {

	@Override
	public RefundResponse handleRefundRequest(RefundRequest refundRequest) {
		LogSupport.debug("Start RefundRequestService handleRefundRequest()");
		LogSupport.debug("End RefundRequestService handleRefundRequest()");
		return null;
	}

}
