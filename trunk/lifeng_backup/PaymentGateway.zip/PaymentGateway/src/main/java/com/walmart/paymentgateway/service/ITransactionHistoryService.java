package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.OrderTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.OrderTransactionQueryResponse;

/**
 * Interface for Transaction History Service handling.
 * @author Raju Thomas
 *
 */
public interface ITransactionHistoryService {

	public OrderTransactionQueryResponse handleTransactionHistoryRequest(OrderTransactionQueryRequest orderTransactionQueryRequest);

}
