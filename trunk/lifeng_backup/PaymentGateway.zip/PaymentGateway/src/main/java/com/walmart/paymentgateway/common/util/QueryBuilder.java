package com.walmart.paymentgateway.common.util;

import java.util.Iterator;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

/***
 * 
 * @author sgopisetty
 *
 */
@Service
public class QueryBuilder {

	/**
	 * 
	 */
	private StringBuffer ql;

	/**
	 * 
	 */
	private boolean hasParameters;

	/**
	 * 
	 */
	public QueryBuilder() {
		super();
		reset();
	}

	/**
	 * 
	 * @return
	 */
	public boolean hasParameters() {
		return hasParameters;
	}

	/**
	 * 
	 * @param fields
	 * @return
	 */
	public QueryBuilder select(String[] fields) {
		if (fields != null && fields.length >= 1) {
			ql.append(" select ");
			for (int i = 0; i < fields.length; i++) {
				ql.append(fields[i]);
				if (i < fields.length - 1) {
					ql.append(", ");
				}
			}
		}
		return this;
	}

	/**
	 * 
	 * @param field
	 * @return
	 */
	public QueryBuilder select(String field) {
		if (field != null && field.trim().length() >= 1) {
			ql.append(" select ");
			ql.append(field);
			ql.append(" ");
		}
		return this;
	}

	/**
	 * 
	 * @param tables
	 * @return
	 */
	public QueryBuilder from(String[] tables) {
		if (tables != null && tables.length >= 1) {
			ql.append(" from ");
			for (int i = 0; i > tables.length; i++) {
				ql.append(tables[i]);
				if (i < tables.length - 1) {
					ql.append(", ");
				}
			}
		}
		return this;
	}

	/**
	 * 
	 * @param table
	 * @return
	 */
	public QueryBuilder from(String table) {
		if (table != null && table.trim().length() >= 1) {
			ql.append(" from ");
			ql.append(table);
			ql.append(" ");
		}
		return this;
	}

	/**
	 * 
	 * @param where
	 * @return
	 */
	public QueryBuilder where(String where) {
		if (where != null && where.trim().length() >= 1) {
			ql.append(" where ");
			ql.append(where);
			ql.append(" ");
		}
		return this;
	}

	/**
	 * 
	 * @param attributes
	 * @param values
	 * @return
	 */
	public QueryBuilder whereFieldsEqualVals(String[] attributes, Object[] values) {
		if (attributes == null || values == null
				|| attributes.length != values.length) {
			return where("1=1");
		}
		hasParameters = true;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < attributes.length; i++) {
			sb.append(attributes[i]);
			sb.append("=?");
			if (i < attributes.length - 1) {
				sb.append(" and ");
			}
		}
		return where(sb.toString());
	}

	/**
	 * 
	 * @param condition
	 * @return
	 */
	public QueryBuilder and(String condition) {
		if (condition != null && condition.trim().length() >= 1) {
			ql.append(" and ");
			ql.append(condition);
			ql.append(" ");
		}
		return this;
	}
	
	/**
	 * 
	 * @param condition1
	 * @param condition2
	 * @return
	 */
	public static String and(String condition1, String condition2) {
		return condition1 + " and " + condition2;
	}
	
	/**
	 * 
	 * @param content
	 * @return
	 */
	public static String quote(String content) {
		return "(" + content + ")";
	}
	
	/**
	 * 
	 * @param content
	 * @return
	 */
	public static String charValue(String content) {
		return "'" + content + "'";
	}

	/**
	 * 
	 * @param condition
	 * @return
	 */
	public QueryBuilder or(String condition) {
		if (condition != null && condition.trim().length() >= 1) {
			ql.append(" or ");
			ql.append(condition);
			ql.append(" ");
		}
		return this;
	}
	
	/**
	 * 
	 * @param condition1
	 * @param condition2
	 * @return
	 */
	public static String or(String condition1, String condition2) {
		return condition1 + " or " + condition2;
	}

	/**
	 * 
	 * @param groupbys
	 * @return
	 */
	public QueryBuilder groupby(String[] groupbys) {
		if (groupbys != null && groupbys.length >= 1) {
			ql.append(" group by ");
			for (int i = 0; i < groupbys.length; i++) {
				ql.append(" ");
				ql.append(groupbys[i]);
				ql.append(" ");
				if (i < groupbys.length - 1) {
					ql.append(", ");
				}
			}
		}
		return this;
	}
	
	/**
	 * 
	 * @param orderby
	 * @return
	 */
	public QueryBuilder orderby(String orderby) {
		if (orderby != null && orderby.trim().length() >= 1) {
			ql.append(" order by ");
			ql.append(orderby);
			ql.append(" ");
		}
		return this;
	}

	/**
	 * 
	 * @param orderbys
	 * @param directions
	 * @return
	 */
	public QueryBuilder orderby(String[] orderbys, String[] directions) {

		if (orderbys == null) {
			return this;
		}

		if (directions != null && orderbys.length != directions.length) {
			return this;
		}

		if (isValidOrderbys(directions)) {
			ql.append(" order by ");
			for (int i = 0; i < orderbys.length; i++) {
				ql.append(" ");
				ql.append(orderbys[i]);
				ql.append(" ");
				if (directions != null) {
					ql.append(directions[i]);
				}
				ql.append(" ");
				if (i < orderbys.length - 1) {
					ql.append(", ");
				}
			}
		}

		return this;
	}

	/**
	 * 
	 * @param orderbys
	 * @param directions
	 * @return
	 */
	public QueryBuilder orderby(String[] orderbys, Boolean[] directions) {
		return orderby(orderbys, convertOrderbyKey(directions));
	}

	/**
	 * 
	 * @param directions
	 * @return
	 */
	private String[] convertOrderbyKey(Boolean[] directions) {
		if (directions != null && directions.length >= 1) {
			String[] converted = new String[directions.length];
			for (int i = 0; i < directions.length; i++) {
				if (directions[i] == true) {
					converted[i] = "asc";
				} else {
					converted[i] = "desc";
				}
			}
			return converted;
		}
		return null;
	}

	/**
	 * 
	 * @param directions
	 * @return
	 */
	private boolean isValidOrderbys(String[] directions) {
		if (directions != null && directions.length >= 1) {
			for (int i = 0; i < directions.length; i++) {
				if (!"asc".equalsIgnoreCase(directions[i])
						&& !"desc".equalsIgnoreCase(directions[i])) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public String getCommand() {
		return ql.toString();
	}

	/**
	 * Description:This method is used to set queryParams.
	 * 
	 * @param <query>
	 *            Query
	 * @param <queryParams>
	 *            Object
	 * @return <<return query>>
	 */
	@SuppressWarnings("unchecked")
	public void setQueryParams(Query query, Object queryParams) {
		if (hasParameters && queryParams != null) {
			if (queryParams instanceof Object[]) {
				Object[] params = (Object[]) queryParams;
				if (params.length > 0) {
					for (int i = 0; i < params.length; i++) {
						query.setParameter(i + 1, params[i]);
					}
				}
			} else if (queryParams instanceof Map) {
				Map params = (Map) queryParams;
				Iterator<String> it = params.keySet().iterator();
				while (it.hasNext()) {
					String key = it.next();
					query.setParameter(key, params.get(key));
				}
			}
		}
	}
	
	/**
	 * 
	 */
	public void reset(){
		ql = new StringBuffer();
		hasParameters = false;
	}
}