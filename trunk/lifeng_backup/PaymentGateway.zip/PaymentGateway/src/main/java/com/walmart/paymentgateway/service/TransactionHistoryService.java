package com.walmart.paymentgateway.service;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.OrderTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.OrderTransactionQueryResponse;

@Component("transactionHistoryService")
public class TransactionHistoryService implements ITransactionHistoryService {


	@Override
	public OrderTransactionQueryResponse handleTransactionHistoryRequest(
			OrderTransactionQueryRequest orderTransactionQueryRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}
