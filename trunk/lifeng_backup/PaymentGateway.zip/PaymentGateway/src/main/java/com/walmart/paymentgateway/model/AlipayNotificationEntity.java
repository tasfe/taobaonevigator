package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_NOTIFICATION database table.
 * 
 */
@Entity
@Table(name="ALIPAY_NOTIFICATION")
public class AlipayNotificationEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAYNOTIFICATIONPK_GENERATOR", sequenceName="ALIPAY_NOTIFICATION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAYNOTIFICATIONPK_GENERATOR")
	@Column(name="ALIPAY_NOTIFICATION_PK")
	private Long alipayNotificationPk;

	@Column(name="NOTIFY_ID")
	private String notifyId;

	@Column(name="NOTIFY_TIME")
	private Timestamp notifyTime;

	@Column(name="NOTIFY_TYPE")
	private String notifyType;

	@Column(name="NOTIFY_VALIDATION_STATUS")
	private String notifyValidationStatus;

	@Column(name="SIGN")
	private String sign;

	@Column(name="SIGN_TYPE")
	private String signType;

	@Column(name="SIGN_VALIDATION_STATUS")
	private String signValidationStatus;

	//bi-directional many-to-one association to AlipayPaymentNotificationEntity
	@OneToMany(mappedBy="alipayNotification")
	private Set<AlipayPaymentNotificationEntity> alipayPaymentNotifications;

	//bi-directional many-to-one association to AlipayRefundNotificationEntity
	@OneToMany(mappedBy="alipayNotification")
	private Set<AlipayRefundNotificationEntity> alipayRefundNotifications;

    public AlipayNotificationEntity() {
    }

	public Long getAlipayNotificationPk() {
		return this.alipayNotificationPk;
	}

	public void setAlipayNotificationPk(Long alipayNotificationPk) {
		this.alipayNotificationPk = alipayNotificationPk;
	}

	public String getNotifyId() {
		return this.notifyId;
	}

	public void setNotifyId(String notifyId) {
		this.notifyId = notifyId;
	}

	public Timestamp getNotifyTime() {
		return this.notifyTime;
	}

	public void setNotifyTime(Timestamp notifyTime) {
		this.notifyTime = notifyTime;
	}

	public String getNotifyType() {
		return this.notifyType;
	}

	public void setNotifyType(String notifyType) {
		this.notifyType = notifyType;
	}

	public String getNotifyValidationStatus() {
		return this.notifyValidationStatus;
	}

	public void setNotifyValidationStatus(String notifyValidationStatus) {
		this.notifyValidationStatus = notifyValidationStatus;
	}

	public String getSign() {
		return this.sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getSignType() {
		return this.signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSignValidationStatus() {
		return this.signValidationStatus;
	}

	public void setSignValidationStatus(String signValidationStatus) {
		this.signValidationStatus = signValidationStatus;
	}

	public Set<AlipayPaymentNotificationEntity> getAlipayPaymentNotifications() {
		return this.alipayPaymentNotifications;
	}

	public void setAlipayPaymentNotifications(Set<AlipayPaymentNotificationEntity> alipayPaymentNotifications) {
		this.alipayPaymentNotifications = alipayPaymentNotifications;
	}
	
	public Set<AlipayRefundNotificationEntity> getAlipayRefundNotifications() {
		return this.alipayRefundNotifications;
	}

	public void setAlipayRefundNotifications(Set<AlipayRefundNotificationEntity> alipayRefundNotifications) {
		this.alipayRefundNotifications = alipayRefundNotifications;
	}
	
}