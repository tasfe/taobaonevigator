package com.walmart.paymentgateway.service.provider.alipay;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.dao.AlipayServiceDao;
import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;

/**
 * 
 * This class holds AlipayConfigurationEntity 
 *
 */
@Component("alipayConfigHolder")
public class AlipayConfigHolder {

	@Autowired
	private AlipayServiceDao alipayServiceDao;
	private Map<String,AlipayAccountConfigEntity> alipayConfigMap = null;
	public AlipayConfigHolder(AlipayServiceDao alipayServiceDao){
		
		LogSupport.debug("Start Initiating  AlipayConfigHolder ");
		alipayConfigMap = new HashMap<String, AlipayAccountConfigEntity>();
		this.alipayServiceDao = alipayServiceDao;
		loadAlipayConfigMap();
		LogSupport.debug("End Initiating  AlipayConfigHolder ");
	}
	public AlipayAccountConfigEntity getAlipayConfigParam(String channel){
		
		LogSupport.debug("Start AlipayConfigHolder getAlipayConfigParam()");
		LogSupport.debug("Channel "+channel);
		LogSupport.debug("End AlipayConfigHolder getAlipayConfigParam() ");
		return alipayConfigMap.get(channel);
	}
	private void loadAlipayConfigMap(){
		
		LogSupport.debug("Start AlipayConfigHolder loadAlipayConfigMap() ");
		List<AlipayAccountConfigEntity> accountConfigEntityList = alipayServiceDao.findAllAccountConfig();
		if(accountConfigEntityList == null || accountConfigEntityList.size() == 0){
			
			throw new ServiceDataAccessException("ALIPAY Configuration could not be loaded. Please verify if master data is populated in ALIPAY_ACCOUNT_CONFIG and CHANNEL_LK tables");
		}
		LogSupport.debug("accountConfigEntityList Size "+accountConfigEntityList.size());
		for (AlipayAccountConfigEntity accountConfigEntity : accountConfigEntityList) {
			LogSupport.debug("Initiating map with key (accountConfigEntity.getChannelLk().getName) "+accountConfigEntity.getChannelLk().getName());
			alipayConfigMap.put(accountConfigEntity.getChannelLk().getName(),accountConfigEntity);
		}
		LogSupport.debug("End AlipayConfigHolder loadAlipayConfigMap() ");
	}
}
