package com.walmart.paymentgateway.service;


import com.walmart.paymentgateway.service.domain.PaymentNotification;
import com.walmart.paymentgateway.service.domain.PaymentStatus;

public interface IPaymentNotificationService {

	
	public PaymentStatus handleNotificationService(PaymentNotification notification);

}
