package com.walmart.paymentgateway.service.util;

public class PaymentConstant {

	public static final String ALIPAY = "ALIPAY";
	public static final String WALMART = "WALMART";
	public static final String PAYURL= "PAYURL";
	public static final String COD= "COD";
	public static final String REQUEST_TYPE_PAY= "PAY";
}
