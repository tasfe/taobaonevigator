package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_REFUND_BATCH_DETAIL database table.
 * 
 */
@Entity
@Table(name="ALIPAY_REFUND_BATCH_DETAIL")
public class AlipayRefundBatchDetailEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAY_REFUND_BATCH_DETAIL_PK_GENERATOR", sequenceName = "ALIPAY_REFUND_BATCH_DETAIL_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_REFUND_BATCH_DETAIL_PK_GENERATOR")
	@Column(name="ALIPAY_REFUND_BATCH_DETAIL_PK")
	private Long alipayRefundBatchDetailPk;

	@Column(name="TRANSACTION_FK")
	private BigDecimal transactionFk;

	//bi-directional many-to-one association to AlipayRefundBatchEntity
    @ManyToOne
	@JoinColumn(name="ALIPAY_REFUND_BATCH_FK")
	private AlipayRefundBatchEntity alipayRefundBatch;

    public AlipayRefundBatchDetailEntity() {
    }

	public Long getAlipayRefundBatchDetailPk() {
		return this.alipayRefundBatchDetailPk;
	}

	public void setAlipayRefundBatchDetailPk(Long alipayRefundBatchDetailPk) {
		this.alipayRefundBatchDetailPk = alipayRefundBatchDetailPk;
	}


	public BigDecimal getTransactionFk() {
		return this.transactionFk;
	}

	public void setTransactionFk(BigDecimal transactionFk) {
		this.transactionFk = transactionFk;
	}

	public AlipayRefundBatchEntity getAlipayRefundBatch() {
		return this.alipayRefundBatch;
	}

	public void setAlipayRefundBatch(AlipayRefundBatchEntity alipayRefundBatchEntity) {
		this.alipayRefundBatch = alipayRefundBatchEntity;
	}
	
}