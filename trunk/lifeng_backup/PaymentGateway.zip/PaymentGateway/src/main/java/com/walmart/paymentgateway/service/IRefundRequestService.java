package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundResponse;

/**
 * Interface for Request Request Service handling.
 * @author Raju Thomas
 *
 */
public interface IRefundRequestService {

	public RefundResponse handleRefundRequest(RefundRequest refundRequest);
}
