package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;

/**
 * Interface for Query Request Service handling.
 *
 */
public interface IQueryRequestService {

	public SingleTransactionQueryResponse handleQueryRequest(SingleTransactionQueryRequest singleQueryRequest);

}
