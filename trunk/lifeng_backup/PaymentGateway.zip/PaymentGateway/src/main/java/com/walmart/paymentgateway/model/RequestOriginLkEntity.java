package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the REQUEST_ORIGIN_LK database table.
 * 
 */
@Entity
@Table(name="REQUEST_ORIGIN_LK")
public class RequestOriginLkEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="REQUEST_ORIGIN_PK_GENERATOR", sequenceName="REQUEST_ORIGIN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REQUEST_ORIGIN_PK_GENERATOR")
	@Column(name="REQUEST_ORIGIN_PK")
	private Long requestOriginPk;

	private String description;

	private String name;

	//bi-directional many-to-one association to TransactionEntity
	@OneToMany(mappedBy="requestOriginLk")
	private Set<TransactionEntity> transactions;

    public RequestOriginLkEntity() {
    }

	public Long getRequestOriginPk() {
		return this.requestOriginPk;
	}

	public void setRequestOriginPk(Long requestOriginPk) {
		this.requestOriginPk = requestOriginPk;
	}


	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Set<TransactionEntity> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<TransactionEntity> transactionEntities) {
		this.transactions = transactionEntities;
	}
	
}