package com.walmart.paymentgateway.message.listener;

import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.PaymentNotification;
import com.walmart.paymentgateway.service.domain.RefundNotification;
import com.walmart.paymentgateway.service.domain.RefundRequest;

public interface MessageListener {
	void receive(final PaymentNotification  paymentNotification);
	void receive(final RefundNotification refundNotification);
	void receive(final RefundRequest refundRequest);
	void receive(final CancelRequest cancelRequest);
}
