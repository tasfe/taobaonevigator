package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the TRANSACTION_TYPE_LK database table.
 * 
 */
@Entity
@Table(name="TRANSACTION_TYPE_LK")
public class TransactionTypeLkEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="TRANSACTION_TYPE_LK_PK_GENERATOR", sequenceName="TRANSACTION_TYPE_LK_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACTION_TYPE_LK_PK_GENERATOR")
	@Column(name="TRANSACTION_TYPE_PK")
	private Long transactionTypePk;

	private String description;

	private String name;

	//bi-directional many-to-one association to TransactionEntity
	@OneToMany(mappedBy="transactionTypeLk")
	private Set<TransactionEntity> transactions;

    public TransactionTypeLkEntity() {
    }

	public Long getTransactionTypePk() {
		return this.transactionTypePk;
	}

	public void setTransactionTypePk(Long transactionTypePk) {
		this.transactionTypePk = transactionTypePk;
	}


	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<TransactionEntity> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<TransactionEntity> transactionEntities) {
		this.transactions = transactionEntities;
	}
	
}