package com.walmart.paymentgateway.processor;

import java.util.UUID;
import org.springframework.stereotype.Component;


@Component
public abstract class AbstractPaymentProcessor implements PaymentProcessor {
	/**
	 * 
	 * @return
	 */
	protected String createIntercorrelationId() {
		return UUID.randomUUID().toString();
	}

}