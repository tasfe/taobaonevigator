package com.walmart.paymentgateway.service;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.domain.RefundNotification;
import com.walmart.paymentgateway.service.domain.RefundResponse;

/**
 * This component is responsible identifying appropriate refund notification processor and
 * delegating the request
 * @author Raju Thomas
 *
 */
@Component("refundNotificationService")
public class RefundNotificationService implements IRefundNotificationService {

	@Override
	public RefundResponse handleRefundNotification(RefundNotification notification) {
		LogSupport.debug("Start RefundNotificationService handleRefundNotification()");
		LogSupport.debug("End RefundNotificationService handleRefundNotification()");
		return null;
	}

}
