package com.walmart.paymentgateway.common.util;

public interface TransactionConstant {
	
	//Transactional Status
	static String STATUS_NEW = "NEW";
	static String STATUS_DECLINE = "DECLINE";
	static String STATUS_ERROR = "ERROR";
	static String STATUS_CANCEL = "CANCEL";
	static String STATUS_COMPLETE = "COMPLETE";
	//Transaction types
	static String TYPE_PAY = "PAY";
	static String TYPE_REF = "REF";
	static String TYPE_CANL = "CANL";
	static String TYPE_QUERY = "QUERY";
	static String TYPE_HIST = "HIST";
	//Transaction Event status
	static String EVENT_PAY_URL_CREATED = "PAY_URL_CREATED";
	static String EVENT_COD_ACCEPTED = "COD_ACCEPTED";
	static String EVENT_SETTLED = "SETTLED";
	static String EVENT_DECLINED = "DECLINED";
	static String EVENT_ERROR = "ERROR";
	static String EVENT_FAIL = "FAIL";
	static String EVENT_CANCEL_PENDING = "CANCEL_PENDING";
	static String EVENT_SENT_FOR_CANCEL = "SENT_FOR_CANCEL";
	static String EVENT_CANCELLED = "CANCELLED";
	static String EVENT_CANCELLED_FAILED = "CANCELLED_FAILED";
	static String EVENT_REFUND_PENDING = "REFUND_PENDING";
	static String EVENT_SENT_FOR_REFUND = "SENT_FOR_REFUND";
	static String EVENT_REFUNDED = "REFUNDED";
	static String EVENT_REFUND_FAILED = "REFUND_FAILED";
	static String EVENT_PAYMENT_NOTIFICATION_RECEIVED = "PAYMENT_NOTIFICATION_RECEIVED";
	static String EVENT_UNKNOWN = "UNKNOWN";

}
