package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;

public interface IPaymentRequestService{

	public PaymentResponse handlePaymentRequest(PaymentRequest paymentRequest);
}
