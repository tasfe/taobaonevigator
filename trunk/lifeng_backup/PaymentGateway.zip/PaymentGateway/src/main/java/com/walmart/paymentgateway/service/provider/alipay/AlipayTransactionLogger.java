package com.walmart.paymentgateway.service.provider.alipay;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.TransactionLogger;
import com.walmart.paymentgateway.dao.AlipayServiceDao;
import com.walmart.paymentgateway.model.AlipayNotificationEntity;
import com.walmart.paymentgateway.model.AlipayPaymentNotificationEntity;

@Component("alipayServiceTransLoger")
public class AlipayTransactionLogger extends TransactionLogger {
	
	@Autowired
	private AlipayServiceDao alipayServiceDao;
	
	/***
	 * 
	 * @param pParameter
	 * @throws Exception
	 */
	public void logPayNotification(Map<String, String> pParameter) {
		LogSupport.debug("Start logPayNotification () ");
		
		AlipayPaymentNotificationEntity payNotificationItem = new AlipayPaymentNotificationEntity();
		AlipayNotificationEntity alipayNotificationEntity = logNotification(pParameter);
		String buyerEmail = pParameter.get("buyer_email");
		//Timestamp gmtCreationTime;
		//Timestamp gmtPaymentTime;
		//String isTotalFeeAdjusted = pParameter.get("notify_id");
		String outTradeNo = pParameter.get("out_trade_no");
		String paymentType = pParameter.get("payment_type");
		//BigDecimal quantity = ConvertUtil.toBigDecimal(pParameter.get("notify_id"));
		String sellerEmail = pParameter.get("seller_email");
		String sellerId = pParameter.get("seller_id");
		BigDecimal totalFee = AlipayUtil.toBigDecimal(pParameter.get("total_fee"));
		String tradeNo = pParameter.get("trade_no");
		String tradeStatus = pParameter.get("trade_status");
		//BigDecimal unitPrice = ConvertUtil.toBigDecimal(pParameter.get("notify_id"));
		if (null != alipayNotificationEntity) {
			payNotificationItem.setBuyerEmail(buyerEmail);
			payNotificationItem.setOutTradeNo(outTradeNo);
			payNotificationItem.setPaymentType(paymentType);
			payNotificationItem.setSellerEmail(sellerEmail);
			payNotificationItem.setSellerId(sellerId);
			payNotificationItem.setTotalFee(totalFee);
			payNotificationItem.setTradeNo(tradeNo);
			payNotificationItem.setTradeStatus(tradeStatus);
			payNotificationItem.setAlipayNotification(alipayNotificationEntity);
			
			alipayServiceDao.createPayNotification(payNotificationItem);
		}
		
		
		LogSupport.debug("Existing from logPayNotification() ");
		
	}
	
	/***
	 * 
	 * @param pParameter
	 * @return
	 * @throws ParseException 
	 */
	private AlipayNotificationEntity logNotification(Map<String, String> pParameter)  {
		LogSupport.debug("Start logNotification () ");
		
		AlipayNotificationEntity notificationItem = new AlipayNotificationEntity();
		String notifiyId = pParameter.get("notify_id");
		Timestamp notifyTime = AlipayUtil.toTimestamp(pParameter.get("notify_time"));
		String notifyType = pParameter.get("notify_type");
		//String notifyValidationStatus = pParameter.get("");
		String sign = pParameter.get("sign");
		String signType = pParameter.get("sign_type");
		//String signValidationStatus = pParameter.get("");
		
		
		notificationItem.setNotifyId(notifiyId);
		notificationItem.setNotifyTime(notifyTime);
		notificationItem.setNotifyType(notifyType);
		//notificationItem.setNotifyValidationStatus(pParameter.get(""));
		notificationItem.setSign(sign);
		notificationItem.setSignType(signType);
		//notificationItem.setSignValidationStatus(pParameter.get(""));
		LogSupport.debug("Exit from logNotification () ");
		return alipayServiceDao.createNotification(notificationItem);
	}
	


}
