package com.walmart.paymentgateway.builder;


import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentResponse;
import com.walmart.paymentgateway.service.util.ReasonCode;

@Component("paymentResponseBuilder")
public class PaymentResponseBuilder  {
	
	PaymentResponse paymentResponse = null;	

	public PaymentResponse getPaymentResponse() {
		return paymentResponse;
	}

	public void setPaymentResponse(PaymentResponse pPaymentResponse) {

		this.paymentResponse = pPaymentResponse;
	}
	public void addToPaymentResponse(PayUrlResponse pPayUrlResponse) {

		paymentResponse.getPayUrlResponse().add(pPayUrlResponse);
	}
	
	public void buildTransactionErrorResponse(String pCorrelationId, String pReasonCode, String pDescription) {
		PayUrlResponse pPayUrlResponse = null;
		Error error = null;
		pPayUrlResponse = getResponseObjectFactory().createPayUrlResponse();
		if (!StringUtils.isEmpty(pCorrelationId)) {
			pPayUrlResponse.setCorrelationId(pCorrelationId);
		}
		error = createErrorResponse(pReasonCode, pDescription);
		pPayUrlResponse.setTransactionStatus(ReasonCode.ERROR);
		//pPayUrlResponse.setTransactionStatusCode(ReasonCode.FAIL);
		pPayUrlResponse.setError(error);
		addToPaymentResponse(pPayUrlResponse);
	}
	
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 */
	public void buildErrorResponse(String pCode, String pDescription) {
		Error error = null;
		error = createErrorResponse(pCode, pDescription);
		getPaymentResponse().setError(error);
	}
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 * @return
	 */
	private Error createErrorResponse(String pCode, String pDescription) {
		Error error =  getResponseObjectFactory().createError();
		error.setCode(pCode);
		error.setDescription(pDescription);
		return error;
	}
	/**
	 * 
	 * @return
	 */
	public PayUrlResponse createPayUrlResponse() {
		return getResponseObjectFactory().createPayUrlResponse();
	}
	public PaymentResponse createPaymentResponse() {
		return getResponseObjectFactory().createPaymentResponse();
	}
	/***
	 * 
	 * @return
	 */
	private ObjectFactory getResponseObjectFactory(){
		
		return new ObjectFactory();
	}
}
