package com.walmart.paymentgateway.service.provider.alipay;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.HttpService;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.processor.AbstractPaymentProcessor;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;
import com.walmart.paymentgateway.service.provider.alipay.domain.Alipay;
import com.walmart.paymentgateway.service.util.ReasonCode;

/***
 * 
 *  This is ALIPAY specific implementation of payment processor
 *
 */
@Component("alipayProcessor")
public class AlipayProcessor extends AbstractPaymentProcessor {
	
	
	@Autowired 
	private AlipayServiceManager alipayServiceManager;
	
	@Autowired
	private AlipayNotification alipayPaymentNotification;
	
	@Autowired
	private AlipayMessageConverter messageConverter;
	
	@Autowired
	private HttpService httpService;
	
	
	
	@Override
	public void processPaymentRequest(PaymentRequest pPaymentRequest, PayUrlRequest pPayUrlRequest, PayUrlResponse pPayResponse ) {
		LogSupport.debug( "Starting AlipayProcessor.processPaymentRequest()");
		LogSupport.debug( " Order Number" + pPaymentRequest.getOrderId());
		String internalCorrelationId = null;
		String paymentURL = null;
		try{
			pPayResponse.setCorrelationId(pPayUrlRequest.getCorrelationId());
			internalCorrelationId = createIntercorrelationId();
			LogSupport.debug( "InterCorrelation Id for pOrderId::" + pPaymentRequest.getOrderId()+"::"+internalCorrelationId);
			paymentURL = alipayServiceManager.createPaymentURL(pPaymentRequest.getOrderId(), pPayUrlRequest, internalCorrelationId);
			LogSupport.debug( "Alipay Payment constructed URL" + paymentURL);
			pPayResponse.setTransactionId(internalCorrelationId);
			pPayResponse.setPaymentURL(paymentURL);
			pPayResponse.setTransactionStatus(ReasonCode.SUCCESS);
			pPayResponse.setTransactionStatusCode(ReasonCode.NEW);
			
		}catch (Exception e) {
			
			LogSupport.error("Exception occured while creating url in processPaymentRequest "+e.getMessage(), e);
			createPayURLErrorResponse(pPayResponse);
		}
		LogSupport.debug( "Existing from AlipayProcessor.processPaymentRequest() ");
	
	}

	
	@Override
	public void processCancelRequest(CancelTransactionRequest pCancelTransactionRequest, 
			CancelTransactionResponse pCancelTransactionResponse) {
		
		LogSupport.debug( "Starting AlipayProcessor.processCancelRequest()");
		
		//step 1: create cancel URL
		String cancelURL = null;
		String intercorrelationId = pCancelTransactionRequest.getTransactionId();
		LogSupport.debug( "processing cancel request for intercorrelationId::" + intercorrelationId);
		String error = null;
		try {
			pCancelTransactionResponse.setTransactionId(intercorrelationId);	
			cancelURL = alipayServiceManager.createCancelURL(intercorrelationId);
			LogSupport.debug( "Cancel URL is created for Alipay::" + cancelURL);
			LogSupport.debug( "Calling Alipay.................");
			String alipayres =httpService.executeGetMethod(cancelURL);
			LogSupport.debug( "Received response from Alipay.................");
			LogSupport.debug("Alipay response::"  + alipayres);
			Alipay alipayresponse = messageConverter.convertAlipayResponse(alipayres);
			error = alipayresponse.getError();
			LogSupport.debug("Alipay response IsSucess::" + alipayresponse.getIsSuccess());
			LogSupport.debug("Alipay response error message::" + error);
			
			if(!alipayresponse.getIsSuccess().equalsIgnoreCase(AlipayConstant.CONST_F)){
				LogSupport.debug("setting transaction Status as Success");
				LogSupport.debug("setting transaction Status Code as Cancel");
				pCancelTransactionResponse.setTransactionStatus(ReasonCode.SUCCESS);
				pCancelTransactionResponse.setTransactionStatusCode(ReasonCode.CANCEL);
			}
			if ((!StringUtils.isEmpty(error))  ){
				LogSupport.debug("Alipay response error message::" + error);
				LogSupport.debug("setting transaction Status as Not completed due to Error");
				pCancelTransactionResponse.setTransactionStatus(ReasonCode.NOT_COMPLETED);
				pCancelTransactionResponse.setTransactionStatusCode(error);				
			}
			
		//	cancelTransactionResponse = alipayServiceHelper.createCancelResponse(isSuccess, error, intercorrelationId);
		} catch (Exception e) {
			LogSupport.error("Exception occured while processing request with provider::" +  e);
			pCancelTransactionResponse.setTransactionStatus(ReasonCode.FAIL);
			pCancelTransactionResponse.setTransactionStatusCode(e.getMessage());				
		}
	}

	@Override
	public void processSingleQueryRequest(SingleTransactionQueryRequest singleQueryRequest,SingleTransactionQueryResponse singleQueryResponse) {
	}

	@Override
	public void processPaymentNotification(
			String paymentNotificationMessage, PaymentStatus pPaymentStatus) {
		alipayPaymentNotification.processPaymentNotification(paymentNotificationMessage,pPaymentStatus); 
	}
	private PayUrlResponse createPayURLErrorResponse(PayUrlResponse pPayResponse) {
		
		Error error = new Error();
		error.setCode(ReasonCode.UNKNOW_ERROR);
		error.setDescription(ReasonCode.UNKNOW_ERROR_MSG);
		pPayResponse.setError(error);
		pPayResponse.setTransactionStatus(ReasonCode.ERROR);
		return pPayResponse;

}


}
