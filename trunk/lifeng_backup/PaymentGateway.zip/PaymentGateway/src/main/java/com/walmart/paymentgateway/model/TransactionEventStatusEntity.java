package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the TRANSACTION_EVENT_STATUS database table.
 * 
 */
@Entity
@Table(name="TRANSACTION_EVENT_STATUS")
public class TransactionEventStatusEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="TRANSACTION_EVENT_STATUS_PK_GENERATOR", sequenceName="TRANSACTION_EVENT_STATUS_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACTION_EVENT_STATUS_PK_GENERATOR")
	@Column(name="TRANSACTION_EVENT_STATUS_PK")
	private Long transactionEventStatusPk;

	private String description;

	private String name;

	//bi-directional many-to-one association to TransactionEventEntity
	@OneToMany(mappedBy="transactionEventStatus")
	private Set<TransactionEventEntity> transactionEvents;

    public TransactionEventStatusEntity() {
    }

	public Long getTransactionEventStatusPk() {
		return this.transactionEventStatusPk;
	}

	public void setTransactionEventStatusPk(Long transactionEventStatusPk) {
		this.transactionEventStatusPk = transactionEventStatusPk;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<TransactionEventEntity> getTransactionEvents() {
		return this.transactionEvents;
	}

	public void setTransactionEvents(Set<TransactionEventEntity> transactionEventEntities) {
		this.transactionEvents = transactionEventEntities;
	}
	
}