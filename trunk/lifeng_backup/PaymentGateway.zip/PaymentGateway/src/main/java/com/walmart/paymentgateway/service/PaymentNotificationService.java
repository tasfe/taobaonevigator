package com.walmart.paymentgateway.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.builder.PaymentStatusBuilder;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.processor.PaymentProcessor;
import com.walmart.paymentgateway.service.domain.PaymentNotification;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.util.ReasonCode;

/***
 * 
 * @author sgopisetty
 *
 */
@Component("paymentNotificationService")
public class PaymentNotificationService implements IPaymentNotificationService {

	@Autowired
	private PaymentStatusBuilder builder;
	@Autowired
	private PaymentProcessor processor;
	/***
	 * 
	 */
	@Override
	public PaymentStatus handleNotificationService(PaymentNotification paymentNotification) {
		LogSupport.debug("Inside PaymentNotificationService.handleNotificationService.... ");
		//Step 1. Get Provider Interface
		String message = paymentNotification.getMessage();
		String provider = paymentNotification.getProvider();
		PaymentStatus paymentStatus =  null;
		String status = null;
		if (!StringUtils.isBlank(provider)) {
			//paymentProcessor = factory.getProcessorInstance(provider);
			paymentStatus = builder.getPaymentStatus();
			processor.processPaymentNotification(message, paymentStatus);
			status = paymentStatus.getTransactionStatus();
			LogSupport.debug("Status after provider process the message::" + status);
			if (((StringUtils.isBlank(status)) || (!status.equalsIgnoreCase(ReasonCode.SUCCESS)))) {
				paymentStatus = null;
			}
		} else {
			LogSupport.debug("UnSupported provider to process the message::" + provider);
			builder.buildErrorResponse(ReasonCode.UNSUPPORTED_PROVIDER, ReasonCode.VALIDATION_FAILED );
		}
		LogSupport.debug("Return from PaymentNotificationService.handleNotificationService.." + paymentStatus);
		return paymentStatus;
	}

}
