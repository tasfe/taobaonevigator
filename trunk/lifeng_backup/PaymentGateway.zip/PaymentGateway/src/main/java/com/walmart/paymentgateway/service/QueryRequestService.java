package com.walmart.paymentgateway.service;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;

@Component("queryRequestService")
public class QueryRequestService implements IQueryRequestService {

	@Override
	public SingleTransactionQueryResponse handleQueryRequest(
			SingleTransactionQueryRequest singleQueryRequest) {
		// TODO Auto-generated method stub
		return null;
	}


}
