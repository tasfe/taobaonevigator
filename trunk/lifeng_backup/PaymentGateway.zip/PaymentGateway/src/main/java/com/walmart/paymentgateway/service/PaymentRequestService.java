package com.walmart.paymentgateway.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.builder.PaymentResponseBuilder;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.TransactionLogger;
import com.walmart.paymentgateway.processor.PaymentProcessor;
import com.walmart.paymentgateway.processor.ServiceManager;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;
import com.walmart.paymentgateway.service.util.PaymentConstant;
import com.walmart.paymentgateway.service.util.ReasonCode;
import com.walmart.paymentgateway.validator.PaymentRequestValidator;

@Component("paymentRequestService")
public class PaymentRequestService implements IPaymentRequestService {
	

	
	@Autowired
	private PaymentRequestValidator paymentRequestValidator;
	
	@Autowired
	private TransactionLogger transactionLogger;
	
	@Autowired
	private ServiceManager serviceManager;

	@Autowired
	private PaymentResponseBuilder   builder;
	
	@Autowired
	private PaymentProcessor  processor;
	
	//@Autowired
	//private PaymentProcessorFactory factory;
	
	/***
	 * 
	 */
	@Override
	public PaymentResponse handlePaymentRequest(PaymentRequest request) {

		LogSupport.debug("Start PaymentApplicationServiceImpl handlePaymentRequest");

		//String payCode  = null;

		String status = "BEGIN";

		List<PayUrlRequest>  transactionRequestList = null;
		//PayUrlRequest  payUrlRequest = null;
		//CodRequest  codRequest = null;
		String srvCode = null;
		String providerName =  null;
		//builder = new PaymentResponseBuilder();
		PayUrlResponse transactionResponse = null;
		String providerType = null;
		String correlationId = null;
		String transactionStatus = null;
		
		LogSupport.debug( "Status before validatePayRequest " + status );
		status = paymentRequestValidator.validateRequest(request);
		LogSupport.debug( "Status after validatePayRequest " + status );
		LogSupport.debug( "Start processing PaymentRequest for orderId " + request.getOrderId() );
		builder.setPaymentResponse(builder.createPaymentResponse());
		builder.getPaymentResponse().setOrderId(request.getOrderId());
		if(!status.equalsIgnoreCase(ReasonCode.PASS)){
			builder.buildErrorResponse(status, ReasonCode.VALIDATION_FAILED);
			builder.getPaymentResponse().setResponseStatus(ReasonCode.ERROR);
			return returnPaymentResponse(builder);
		}
		transactionRequestList = request.getPayUrlRequest();
		if (null != transactionRequestList && !transactionRequestList.isEmpty()) {
			LogSupport.debug( "paymentRequestList " + transactionRequestList.size() );
			for (PayUrlRequest transactionRequest : transactionRequestList) {
				LogSupport.debug( "Status before validateTransactionRequest " + status );
				srvCode = transactionRequest.getPayURLServiceCode();
				providerType = PaymentConstant.PAYURL;
				status = paymentRequestValidator.validateTransactionRequest(transactionRequest, srvCode);
				correlationId = transactionRequest.getCorrelationId();
				LogSupport.debug( "Status after validateTransactionRequest " + status );
				if(!status.equalsIgnoreCase(ReasonCode.PASS)){
					builder.buildTransactionErrorResponse(correlationId, status, ReasonCode.VALIDATION_FAILED);
					builder.getPaymentResponse().setResponseStatus(ReasonCode.ERROR);
					return returnPaymentResponse(builder);
				}	
				providerName = serviceManager.getServiceProvider(srvCode, providerType);
				if (((null != providerName))) {
					//processor = PaymentProcessorFactory.getProcessorInstance(providerName);
					transactionResponse = builder.createPayUrlResponse() ;
					processor.processPaymentRequest(request,transactionRequest, transactionResponse);
					transactionStatus = transactionResponse.getTransactionStatus();
					if (transactionStatus.equalsIgnoreCase(ReasonCode.SUCCESS)) {
						//log transaction
						transactionLogger.logPaymentTransaction(request, srvCode,transactionResponse.getTransactionId(), transactionRequest,
								"PAY_URL_CREATED");	
					}
					builder.getPaymentResponse().getPayUrlResponse().add(transactionResponse);
					
				} else {
					builder.buildTransactionErrorResponse(correlationId, ReasonCode.UNSUPPORTED_PROVIDER, ReasonCode.VALIDATION_FAILED );
					builder.getPaymentResponse().setResponseStatus(ReasonCode.ERROR);
				}
			}
			setResponseStatusCode(builder);
		} else {

			builder.buildErrorResponse(ReasonCode.MISSING_TRANSACTION_REQUEST, ReasonCode.VALIDATION_FAILED);
			builder.getPaymentResponse().setResponseStatus(ReasonCode.ERROR);
			return returnPaymentResponse(builder);

		}


		LogSupport.debug("End PaymentApplicationServiceImpl handlePaymentRequest");
		return returnPaymentResponse(builder);

	}
	
	/***
	 * 
	 * @param builder
	 * @param responseCode
	 * @param status
	 */
	private void setResponseStatusCode(PaymentResponseBuilder pBuilder){
		List<PayUrlResponse> payUrlResponse = null;
		payUrlResponse = pBuilder.getPaymentResponse().getPayUrlResponse();
		String status = null;
		for (PayUrlResponse transactionResponse : payUrlResponse) {
			status = transactionResponse.getTransactionStatus();
			if (!status.equalsIgnoreCase(ReasonCode.SUCCESS)) {
				break;
			}
		}
		pBuilder.getPaymentResponse().setResponseStatus(status);
	}
	private PaymentResponse returnPaymentResponse(PaymentResponseBuilder   builder){
		return builder.getPaymentResponse();
	}
}
