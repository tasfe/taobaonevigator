/**
 * 
 */
package com.walmart.paymentgateway.builder;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundTransactionRequest;

/**
 * @author sgopisetty
 *
 */
@Component
public class RefundRequestBuilder {


	
	private RefundRequest refundRequest = null;
	
	
	public RefundRequest getRefundRequest() {
		return refundRequest;
	}

	public void setRefundRequest(RefundRequest RefundRequest) {
		this.refundRequest = RefundRequest;
	}
	
	public RefundRequestBuilder(){ 		
		initRefundRequest(); 
	}
	
	public void addToRefundRequest(RefundTransactionRequest RefundTransactionRequest) {
		refundRequest.getRefundTransactionRequest().add(RefundTransactionRequest);
	}
	
	
	public RefundTransactionRequest createNewRefundTransactionRequest() {
		return getResponseObjectFactory().createRefundTransactionRequest();
	}

	/***
	 * 
	 */
	private void initRefundRequest(){
		refundRequest = getResponseObjectFactory().createRefundRequest();
	}
	/***
	 * 
	 * @return
	 */
	private ObjectFactory getResponseObjectFactory(){
		
		return new ObjectFactory();
	}




}
