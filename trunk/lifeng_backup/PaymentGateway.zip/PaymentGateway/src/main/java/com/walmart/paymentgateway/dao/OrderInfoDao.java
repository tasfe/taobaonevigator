/**
 * 
 */
package com.walmart.paymentgateway.dao;

import java.util.List;

import com.walmart.paymentgateway.model.OrderInfoEntity;

/**
 * @author sgopisetty
 *
 */
public interface OrderInfoDao extends GenericDao {
	
	public OrderInfoEntity createOrderInfo(OrderInfoEntity pOrderInfoEntity);
	public OrderInfoEntity findOrderInfo(String pOrderId);
	public OrderInfoEntity findOrderInfoById(Long pId);
	public List<OrderInfoEntity> getAllOrder();

}
