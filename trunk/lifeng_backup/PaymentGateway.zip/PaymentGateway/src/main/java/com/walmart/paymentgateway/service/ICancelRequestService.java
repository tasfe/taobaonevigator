package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;

public interface ICancelRequestService  {


	public CancelResponse handleCancelRequest(CancelRequest pCancelRequest);
	
}
