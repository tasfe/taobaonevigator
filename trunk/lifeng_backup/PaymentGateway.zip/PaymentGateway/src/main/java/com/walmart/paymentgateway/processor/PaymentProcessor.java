package com.walmart.paymentgateway.processor;

import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;

public interface PaymentProcessor {

	/**
	 * 
	 * @param pRequest
	 * @param pPayUrlRequest
	 * @param pPayResponse
	 */
	 void processPaymentRequest(PaymentRequest pRequest, PayUrlRequest pPayUrlRequest, PayUrlResponse pPayResponse );
	
	/**
	 * 
	 * @param pCancelTransactionRequest
	 * @param pCancelTransactionResponse
	 */
	void processCancelRequest(CancelTransactionRequest pCancelTransactionRequest, 
													CancelTransactionResponse pCancelTransactionResponse);
	/**
	 * 
	 * @param singleQueryRequest
	 * @param singleQueryResponse
	 */
	 
	
	void processSingleQueryRequest(SingleTransactionQueryRequest singleQueryRequest,SingleTransactionQueryResponse singleQueryResponse);
	
	/**
	 * 
	 * @param paymentNotificationMessage
	 * @param pPaymentStatus
	 */
	void processPaymentNotification(String paymentNotificationMessage, PaymentStatus pPaymentStatus);

	
}
