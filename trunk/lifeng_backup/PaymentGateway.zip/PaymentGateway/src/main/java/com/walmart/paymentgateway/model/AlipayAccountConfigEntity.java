package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_ACCOUNT_CONFIG database table.
 * 
 */
@Entity
@Table(name="ALIPAY_ACCOUNT_CONFIG")
public class AlipayAccountConfigEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_CHANNEL_NAME = "BY_CHANNEL_NAME";
	public final static String BY_ID = "BY_ID";
	public final static String BY_FETCH_ALL = "BY_FETCH_ALL";


	@Id
	@SequenceGenerator(name="ALIPAYCONFIGPK_GENERATOR", sequenceName="ALIPAY_ACCOUNT_CONFIG_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAYCONFIGPK_GENERATOR")
	@Column(name="ALIPAY_CONFIG_PK")
	private Long alipayConfigPk;

	@Column(name="BODY")
	private String body;

	@Column(name="CHAR_SET")
	private String charSet;

	@Column(name="GATEWAY_URL")
	private String gatewayUrl;

	@Column(name="INPUT_CHAR_SET")
	private String inputCharSet;

	@Column(name="KEY")
	private String key;

	@Column(name="MAX_REC_PER_REFUND_BATCH")
	private BigDecimal maxRecPerRefundBatch;

	@Column(name="NOTIFY_URL")
	private String notifyUrl;

	@Column(name="PATNER_ID")
	private String patnerId;

	@Column(name="PAYMENT_TYPE")
	private String paymentType;

	@Column(name="REFUND_NOTIFY_URL")
	private String refundNotifyUrl;

	@Column(name="SELLER_EMAIL_ID")
	private String sellerEmailId;

	@Column(name="SHOW_URL")
	private String showUrl;

	@Column(name="SIGN_TYPE")
	private String signType;

	private String subject;

	//bi-directional many-to-one association to TenantLkEntity
	@ManyToOne
	@JoinColumn(name="CHANNEL_FK")
	private ChannelLkEntity channelLk;

    public AlipayAccountConfigEntity() {
    }

	public Long getAlipayConfigPk() {
		return this.alipayConfigPk;
	}

	public void setAlipayConfigPk(Long alipayConfigPk) {
		this.alipayConfigPk = alipayConfigPk;
	}

	public String getBody() {
		return this.body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getCharSet() {
		return this.charSet;
	}

	public void setCharSet(String charSet) {
		this.charSet = charSet;
	}

	
	public String getGatewayUrl() {
		return this.gatewayUrl;
	}

	public void setGatewayUrl(String gatewayUrl) {
		this.gatewayUrl = gatewayUrl;
	}

	public String getInputCharSet() {
		return this.inputCharSet;
	}

	public void setInputCharSet(String inputCharSet) {
		this.inputCharSet = inputCharSet;
	}

	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public BigDecimal getMaxRecPerRefundBatch() {
		return this.maxRecPerRefundBatch;
	}

	public void setMaxRecPerRefundBatch(BigDecimal maxRecPerRefundBatch) {
		this.maxRecPerRefundBatch = maxRecPerRefundBatch;
	}

	public String getNotifyUrl() {
		return this.notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getPatnerId() {
		return this.patnerId;
	}

	public void setPatnerId(String patnerId) {
		this.patnerId = patnerId;
	}

	public String getPaymentType() {
		return this.paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getRefundNotifyUrl() {
		return this.refundNotifyUrl;
	}

	public void setRefundNotifyUrl(String refundNotifyUrl) {
		this.refundNotifyUrl = refundNotifyUrl;
	}

	public String getSellerEmailId() {
		return this.sellerEmailId;
	}

	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}

	public String getShowUrl() {
		return this.showUrl;
	}

	public void setShowUrl(String showUrl) {
		this.showUrl = showUrl;
	}

	public String getSignType() {
		return this.signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public ChannelLkEntity getChannelLk() {
		return this.channelLk;
	}

	public void setChannelLk(ChannelLkEntity channelLkEntity) {
		this.channelLk = channelLkEntity;
	}
	
}