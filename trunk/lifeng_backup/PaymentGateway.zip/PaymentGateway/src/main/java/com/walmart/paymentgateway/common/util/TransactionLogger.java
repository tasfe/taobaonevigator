package com.walmart.paymentgateway.common.util;

import java.math.BigDecimal;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.model.AccountEntity;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.OrderInfoEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.model.TransactionEventEntity;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.util.PaymentConstant;

@Component("transactionLogger")
public class TransactionLogger {
	
	@Autowired
	private DaoManager transactionalTools;
	
	/***
	 * 
	 */
	private boolean isTransactionExist = false;
	
	
	
	/***
	 * 
	 * @param request
	 * @param pSrvPaycode
	 * @param pTransactionRequest
	 * @param pTransactionRefId
	 * @param pTransactionResponseStatus
	 */
	public void logPaymentTransaction(PaymentRequest request,
								  String pSrvPaycode,
								  String pTransactionRefId,
								  PayUrlRequest pServiceRequest,
								  String pTransactionResponseStatus) {

		TransactionEntity transactionEntity =  null;
		transactionEntity = logNewPaymentTransaction(request, pServiceRequest,pSrvPaycode, 
				pTransactionRefId, PaymentConstant.REQUEST_TYPE_PAY);

		if (null != transactionEntity) {
			logTransactionEvent(transactionEntity, pTransactionResponseStatus,"PAY_URL_CREATED");
		}

	}
	
	/***
	 * 
	 * @param request
	 * @param pSrvPaycode
	 * @param pTransactionRequest
	 * @param transactionRefId
	 * @param pServiceReqType
	 * @return
	 */
	private TransactionEntity logNewPaymentTransaction (PaymentRequest request,
														PayUrlRequest pServiceRequest,
														String pSrvPaycode,
														String transactionRefId,
														String pServiceReqType){

		LogSupport.info("Start createPayURLRequestTransaction ");

		AccountEntity accountEntity = null;
		OrderInfoEntity orderEntity = null;
		DomainLkEntity domainEntity = null;
		SrvProviderPayTypeCodeEntity srvPayCodeItem =  null;
		ChannelLkEntity tenantLkEntity = null;
		TransactionEntity transactionEntity = null;
		RequestOriginLkEntity requestOriginLk =  null;
		

		String customerId = request.getCustomer().getCustomerId();
		String DomainName = request.getDomain();
		String pOrderId = request.getOrderId();
		String originator = request.getOriginator();

		//String paySrvCode = payURLRequest.getPayURLServiceCode();

		BigDecimal amount = pServiceRequest.getAmount();
		String extCorrelationId = pServiceRequest.getCorrelationId();
		String tenant = pServiceRequest.getChannel();

		accountEntity = transactionalTools.findAccount(customerId);
		domainEntity = transactionalTools.findDomain(DomainName);
		srvPayCodeItem = transactionalTools.findSrvProviderInfo(pSrvPaycode);
		tenantLkEntity = transactionalTools.findChannel(tenant);
		//get Request Type

		requestOriginLk = transactionalTools.findRequestOrigin(originator);
		orderEntity =  transactionalTools.findOrder(pOrderId);

		if (null == accountEntity) {
			accountEntity = new AccountEntity();
			accountEntity.setExtCustomerId(customerId);
			accountEntity.setDomainLk(domainEntity);
			getTransactionalTools().createAccount(accountEntity);
		}
		if (null == orderEntity) {
			orderEntity = new OrderInfoEntity();
			orderEntity.setExtOrderId(pOrderId);
			//getTransactionalTools().createOrder(OrderInfoEntity);
			Set<OrderInfoEntity> orderset = accountEntity.getOrderInfos();
			orderset.add(orderEntity);
			accountEntity.setOrderInfos(orderset);
			orderEntity.setAccount(accountEntity);
			getTransactionalTools().createOrder(orderEntity);
		}
		transactionEntity = new TransactionEntity();
		transactionEntity.setOrderInfo(orderEntity);
		transactionEntity.setAmount(amount);
		transactionEntity.setIntCorrelationId(transactionRefId);
		transactionEntity.setExtCorrelationId(extCorrelationId);
		transactionEntity.setChannelLk(tenantLkEntity);
		transactionEntity.setSrvProviderPayTypeCode(srvPayCodeItem);
		transactionEntity.setRequestOriginLk(requestOriginLk);
		transactionalTools.createOrUpateTransaction(transactionEntity,pServiceReqType, "NEW");


		//logTransactionEvent(transactionStatus, transactionRefId);


		LogSupport.info("End createPayURLRequestTransaction ");
		return transactionEntity;

	}
	
	/***
	 * 
	 * @param pTransactionEntity
	 * @param pServiceReqType
	 * @param pStatus
	 * @return
	 */
	public TransactionEntity logNewTransaction(TransactionEntity pTransactionEntity, 
								   String pServiceReqType, String pStatus) {
		
		TransactionEntity transactionEntity = null;;
		transactionEntity = new TransactionEntity();
		transactionEntity.setOrderInfo(pTransactionEntity.getOrderInfo());
		transactionEntity.setAmount(pTransactionEntity.getAmount());
		transactionEntity.setIntCorrelationId(pTransactionEntity.getIntCorrelationId());
		transactionEntity.setExtCorrelationId(pTransactionEntity.getExtCorrelationId());
		transactionEntity.setChannelLk(pTransactionEntity.getChannelLk());
		transactionEntity.setSrvProviderPayTypeCode(pTransactionEntity.getSrvProviderPayTypeCode());
		transactionEntity.setRequestOriginLk(pTransactionEntity.getRequestOriginLk());
		transactionEntity = transactionalTools.createOrUpateTransaction(transactionEntity,pServiceReqType, pStatus);
		
		return transactionEntity;
	}
	
	/***
	 * 
	 * @param transactionStatus
	 * @param pTransactionEntity
	 */
	public void logTransactionEvent (TransactionEntity pTransactionEntity, String transactionStatus, String pComments ){
		
		LogSupport.debug("inside TransactionLogger.logTransactionEvent ");
		LogSupport.debug("TansactionEntity Id::" + pTransactionEntity.getTransactionPk());
		LogSupport.debug("transactionStatus::" + transactionStatus);
		LogSupport.debug("Comments::" + pComments);
		TransactionEventEntity newTransactionEventEntity = new TransactionEventEntity();
		if (!StringUtils.isEmpty(pComments) && isTransactionExist) {
			pComments = "Duplicate Transaction";
		}
		newTransactionEventEntity.setComment(pComments);
		newTransactionEventEntity.setTransaction(pTransactionEntity);
		
		transactionalTools.createTransactionEvent(newTransactionEventEntity, transactionStatus);
		
		LogSupport.debug("End createTransactionEvent ");

	}

	public void setTransactionalTools(DaoManager transactionalTools) {
		this.transactionalTools = transactionalTools;
	}

	public DaoManager getTransactionalTools() {
		return transactionalTools;
	}
}
