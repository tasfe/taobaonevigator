package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the SRV_PROVIDER database table.
 * 
 */
@Entity
@Table(name="SRV_PROVIDER")
public class SrvProviderEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";
	public final static String BY_FETCH_ALL = "BY_FETCH_ALL";

	@Id
	@SequenceGenerator(name="SRV_PROVIDER_PK_GENERATOR", sequenceName="SRV_PROVIDER_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SRV_PROVIDER_PK_GENERATOR")
	@Column(name="SRV_PROVIDER_PK")
	private Long srvProviderPk;

	private String description;

	private String name;

	@Column(name="TYPE")
	private String type;

	//bi-directional many-to-one association to SrvProviderPayTypeEntity
	@OneToMany(mappedBy="srvProvider",fetch=FetchType.EAGER)
	
	private Set<SrvProviderPayTypeEntity> srvProviderPayTypes;

    public SrvProviderEntity() {
    }

	public Long getSrvProviderPk() {
		return this.srvProviderPk;
	}

	public void setSrvProviderPk(Long srvProviderPk) {
		this.srvProviderPk = srvProviderPk;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSoftDelete() {
		return this.softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set<SrvProviderPayTypeEntity> getSrvProviderPayTypes() {
		return this.srvProviderPayTypes;
	}

	public void setSrvProviderPayTypes(Set<SrvProviderPayTypeEntity> srvProviderPayTypeEntities) {
		this.srvProviderPayTypes = srvProviderPayTypeEntities;
	}
	
}