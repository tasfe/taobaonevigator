package com.walmart.paymentgateway.dao;

import java.util.List;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;
import com.walmart.paymentgateway.model.AlipayNotificationEntity;
import com.walmart.paymentgateway.model.AlipayPaymentNotificationEntity;

/**
 * DAO interface for creating,accessing and updating ALIPAY tables data
 *
 */
public interface AlipayServiceDao extends GenericDao {
	
	
	/***
	 * 
	 * @param pChannelId
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public List<AlipayAccountConfigEntity> findAllAccountConfig() throws ServiceDataAccessException;
	
	/***
	 * 
	 * @param pAlipayNotificationEntity
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public AlipayNotificationEntity createNotification(AlipayNotificationEntity pAlipayNotificationEntity) throws ServiceDataAccessException;
	/***
	 * 
	 * @param pPaymentNotificationEntity
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public AlipayPaymentNotificationEntity createPayNotification(AlipayPaymentNotificationEntity pPaymentNotificationEntity) throws ServiceDataAccessException;
	
	/***
	 * 
	 * @param pAlipayTradeNumber
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public AlipayPaymentNotificationEntity findPayNotification(String pAlipayTradeNumber) throws ServiceDataAccessException;
}
