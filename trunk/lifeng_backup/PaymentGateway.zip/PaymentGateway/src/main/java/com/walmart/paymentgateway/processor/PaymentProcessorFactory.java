package com.walmart.paymentgateway.processor;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.provider.alipay.AlipayProcessor;
import com.walmart.paymentgateway.service.provider.wmcode.WMPaymentProcessor;
import com.walmart.paymentgateway.service.util.PaymentConstant;

@Component
public class PaymentProcessorFactory {

	private static PaymentProcessor  processor ;
	
	private PaymentProcessorFactory() {
		
	}
	
	public static  PaymentProcessor getProcessorInstance(String providerCode){
		if (providerCode.equalsIgnoreCase(PaymentConstant.ALIPAY)){
			processor = new AlipayProcessor();
		} else if (providerCode.equalsIgnoreCase(PaymentConstant.WALMART)) {
			processor = new WMPaymentProcessor();
		} 
		return processor;
	}
	
	
}
