package com.walmart.paymentgateway.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sun.jersey.core.spi.factory.ResponseBuilderImpl;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.ICancelRequestService;
import com.walmart.paymentgateway.service.IPaymentRequestService;
import com.walmart.paymentgateway.service.IQueryRequestService;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentResponse;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;
/**
 * PaymentGateway Exposed Rest Services
 * 
 *
 */
@Service
@Path("/payment/")
public class PaymentGatewayRestWebService {
	
	
	@Autowired
	private IPaymentRequestService paymentRequestService;
	
	@Autowired
	private ICancelRequestService cancelRequestService;
	
	@Autowired
	private IQueryRequestService queryRequestService;
	
	/***
	 * 
	 * @param request
	 * @return
	 */
	@POST
	@Path("/processpayment/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Response payment(PaymentRequest paymentRequest) {

		LogSupport.debug("start service call payment "+paymentRequest);
		PaymentResponse paymentResponse  = paymentRequestService.handlePaymentRequest(paymentRequest);
		ResponseBuilder builder = new ResponseBuilderImpl();
		builder.type(MediaType.APPLICATION_XML);
		builder.entity(paymentResponse);
		LogSupport.debug("end service call payment "+paymentResponse);
		return builder.build();
	}
	/***
	 * 
	 * @param pCancelRequest
	 * @return
	 */
	@POST
	@Path("/processcancel/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Response cancel(CancelRequest cancelRequest) {

		LogSupport.debug("start service call cancel "+cancelRequest);
		CancelResponse cancelResponse  = cancelRequestService.handleCancelRequest(cancelRequest);
		ResponseBuilder builder = new ResponseBuilderImpl();
		builder.type(MediaType.APPLICATION_XML);
		builder.entity(cancelResponse);
		LogSupport.debug("end service call payment "+cancelResponse);
		return builder.build();
	}
	
	/****
	 * 
	 * @param pSingleQueryRequest
	 * @return
	 */
	@POST
	@Path("/processquery/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Response query(SingleTransactionQueryRequest singleTransactionQueryRequest) {

		LogSupport.debug("start service call payment "+singleTransactionQueryRequest);
		SingleTransactionQueryResponse singleTransactionQueryResponse = queryRequestService.handleQueryRequest(singleTransactionQueryRequest);
		ResponseBuilder builder = new ResponseBuilderImpl();
		builder.type(MediaType.APPLICATION_XML);
		builder.entity(singleTransactionQueryResponse);
		LogSupport.debug("end service call payment "+singleTransactionQueryResponse);
		return builder.build();
	}
	
	

}
