package com.walmart.paymentgateway.message.sender;


public interface MessageSender {
	public void sendQueue(Object targetObject);
}
