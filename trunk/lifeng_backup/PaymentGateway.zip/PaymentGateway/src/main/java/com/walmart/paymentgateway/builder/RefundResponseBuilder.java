/**
 * 
 */
package com.walmart.paymentgateway.builder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.RefundResponse;
import com.walmart.paymentgateway.service.domain.RefundTransactionResponse;
import com.walmart.paymentgateway.service.util.ReasonCode;

/**
 * @author sgopisetty
 *
 */
@Component
public class RefundResponseBuilder {

	
	RefundResponse refundResponse = null;
	RefundTransactionResponse refundTransactionResponse = null;
	
	
	/**
	 * @return the refundTransactionResponse
	 */
	public RefundTransactionResponse getRefundTransactionResponse() {
		return refundTransactionResponse;
	}

	/**
	 * @param refundTransactionResponse the refundTransactionResponse to set
	 */
	public void setRefundTransactionResponse(
			RefundTransactionResponse refundTransactionResponse) {
		this.refundTransactionResponse = refundTransactionResponse;
	}

	public RefundResponse getRefundResponse() {
		return refundResponse;
	}

	public void setRefundResponse(RefundResponse RefundResponse) {
		this.refundResponse = RefundResponse;
	}
	
	public RefundResponseBuilder(){ 		
		initRefundResponse(); 
	}
	
	public void addToRefundResponse(RefundTransactionResponse refundTransactionResponse) {
		refundResponse.getRefundTransactionResponse().add(refundTransactionResponse);
	}
	
	public void buildTransactionErrorResponse(String pInterCorrelationId, String pReasonCode, String pDescription) {
		Error resErr = null;
		if (!StringUtils.isEmpty(pInterCorrelationId)) {
			refundTransactionResponse.setTransactionId(pInterCorrelationId);
		}
		resErr = createErroResponse(pReasonCode, pDescription);
		refundTransactionResponse.setError(resErr);
		addToRefundResponse(refundTransactionResponse);
	}
	
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 */
	public void buildErrorResponse(String pCode, String pDescription) {
		Error resErr = null;
		resErr = createErroResponse(ReasonCode.ERROR, pDescription);
		getRefundResponse().setError(resErr);
	}
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 * @return
	 */
	public Error createErroResponse(String pCode, String pDescription) {
		Error resErr =  getResponseObjectFactory().createError();
		resErr.setCode(pCode);
		resErr.setDescription(pDescription);
		return resErr;
	}

	/***
	 * 
	 */
	private void initRefundResponse(){
		refundResponse = getResponseObjectFactory().createRefundResponse();
		refundTransactionResponse = getResponseObjectFactory().createRefundTransactionResponse();
	}
	/***
	 * 
	 * @return
	 */
	private ObjectFactory getResponseObjectFactory(){
		
		return new ObjectFactory();
	}


}
