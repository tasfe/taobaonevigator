package com.walmart.paymentgateway.message.sender;

import javax.jms.Destination;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
/**
 * This class is responsible for posting refund status to Queue after receiving refund response from
 * service providers  
 **/
@Component("refundStatusSender")
public class RefundStatusSender extends AbstractMessageSender {

	@Autowired 
	@Qualifier("queueForRefundStatusPost")
	protected Destination destination;

	@Override
	public void sendMessage(Object targetObject) {
		this.jmsTemplate.convertAndSend(destination, targetObject);
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

}
