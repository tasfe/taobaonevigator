package com.walmart.paymentgateway.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.model.OrderInfoEntity;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.util.ReasonCode;

@Component("cancelRequestValidator")
public class CancelRequestValidator implements Validator {
	
	@Autowired
	private DaoManager transactionalTools;
	
	ObjectFactory resFactory = new ObjectFactory();

	private static final String ALPHA_NUMERICS_REGEX = "^[a-zA-Z0-9 ]*$";

	/**
	 * This method validates cancel request parameters.
	 * @param request
	 * @return String
	 */
	public String validateCancelRequest(CancelRequest pRequest){
		LogSupport.debug("Start CancelRequestValidator validateCancelRequest");
		if(pRequest == null){			
			return ReasonCode.INVALID_REQUEST;
		} else {
			if(StringUtils.isEmpty(pRequest.getOrderId())){
				return ReasonCode.MISSING_ORDERID;
			}
			if(StringUtils.isEmpty(pRequest.getOriginator())){
				return ReasonCode.MISSING_ORIGINATOR;
			}
			if(CollectionUtils.isEmpty(pRequest.getCancelTransactionRequest())){
				return ReasonCode.MISSING_CANCEL_TRANSACTION_REQUEST;
			}
		}
		return ReasonCode.PASS;
	}
	
	public String validateCancelTransactionRequest(CancelTransactionRequest request){
		
		if(request == null){			
			return ReasonCode.MISSING_CANCEL_TRANSACTION_REQUEST;
		} else {			
			if(request.isForceRefund() == null)
				return ReasonCode.FORCE_REFUND_IS_NULL;
			if(request.getTransactionId() == null)
				return ReasonCode.MISSING_TRANSACTION_ID;				
			}
		return ReasonCode.PASS;
		
	}
	
	public Error validateCancelRequestAndCreateError(CancelRequest pRequest) {
		LogSupport.debug("Start CancelRequestValidator validateCancelRequest");
		
		Error error = resFactory.createError();
		
		if(pRequest == null) {		
			error.setCode(ReasonCode.INVALID_TRANSACTION);
			error.setDescription(ReasonCode.INVALID_TRANSACTION);			
			return error;
		} else {
			if(StringUtils.isEmpty(pRequest.getOrderId())){
				error.setCode(ReasonCode.MISSING_ORDERID);
				error.setDescription(ReasonCode.MISSING_ORDERID);			
				return error;
			}
			if(StringUtils.isEmpty(pRequest.getOriginator())){
				error.setCode(ReasonCode.MISSING_ORIGINATOR);
				error.setDescription(ReasonCode.MISSING_ORIGINATOR);			
				return error;
			}
		}
		// please confirm on success scenario what it should return
		
		return null;
	}
	
	@Override
	public boolean supports(Class<?> paramClass) {
		return paramClass.equals(CancelRequest.class);
	}

	@Override
	public void validate(Object paramObject, Errors paramErrors) {
		
		CancelRequest cancelRequest = (CancelRequest) paramObject;		
		if(cancelRequest.equals(null)) {
			paramErrors.rejectValue("cancelRequest", ReasonCode.INVALID_REQUEST);
		} else {
			if(StringUtils.isEmpty(cancelRequest.getOrderId())) {
				paramErrors.rejectValue("orderId", ReasonCode.MISSING_ORDERID);
			}
			if(StringUtils.isEmpty(cancelRequest.getOriginator())) {
				paramErrors.rejectValue("Originator", ReasonCode.MISSING_ORIGINATOR);
			}
		}				
	}	
	
	public boolean checkOrderExist (String pOrderNumber) {
		//validate for should contains only alpha numeric ..
		LogSupport.debug("Start CancelRequestValidator validateOrder" + pOrderNumber);
		boolean isValid = false;
		if(!StringUtils.isEmpty(pOrderNumber)&& isAlphaNum(pOrderNumber)) {
			OrderInfoEntity order = transactionalTools.findOrder(pOrderNumber);
			if (null != order) {
				isValid = true;
			}
		}
		/*if (isValid) {
			error = resFactory.createError();
			error.setCode(ReasonCode.ORDER_NOT_FOUND);
			error.setDescription(ReasonCode.VALIDATION_FAILED);
		}*/


		LogSupport.debug("returing from CancelRequestValidator validateOrder with isValid :: " + isValid);
		return isValid;
	}
	
	 
    public boolean isAlphaNum(String propertyValue) {

        Pattern l_oPattern = null;
        Matcher l_oMatcher = null;
        // checks property value contains AlphaNumerics or not.
        l_oPattern = Pattern.compile(ALPHA_NUMERICS_REGEX);
        l_oMatcher = l_oPattern.matcher(propertyValue);
        if (l_oMatcher.matches()) {
            return true;
        }

        return false;
    }

}
