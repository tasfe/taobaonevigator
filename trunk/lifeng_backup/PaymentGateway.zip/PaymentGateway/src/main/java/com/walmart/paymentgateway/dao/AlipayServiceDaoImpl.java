package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Map;


import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.QueryParameter;
import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;
import com.walmart.paymentgateway.model.AlipayNotificationEntity;
import com.walmart.paymentgateway.model.AlipayPaymentNotificationEntity;


/**
 *  Implementation class for AlipayServiceDAO interface 
 *
 */
@Repository("alipayServiceDao")
public class AlipayServiceDaoImpl extends GenericDaoImpl implements
AlipayServiceDao {


	@Override
	public AlipayNotificationEntity createNotification(AlipayNotificationEntity pAlipayNotificationEntity) {

		if(null==pAlipayNotificationEntity.getAlipayNotificationPk()){
			LogSupport.debug("persisting the AlipayPaymentNotificationEntity...");
			return this.create(pAlipayNotificationEntity);
		}else{
			LogSupport.debug("merging the AlipayPaymentNotificationEntity...");
			em.merge(pAlipayNotificationEntity);
		}
		return null;

	}

	/***
	 * 
	 */
	@Override
	public AlipayPaymentNotificationEntity createPayNotification(AlipayPaymentNotificationEntity pPaymentNotificationEntity) {

		if(null==pPaymentNotificationEntity.getAlipayPaymentNotificationPk()){
			LogSupport.debug("persisting the AlipayPaymentNotificationEntity...");
			return this.create(pPaymentNotificationEntity);
		}else{
			LogSupport.debug("merging the AlipayPaymentNotificationEntity...");
			em.merge(pPaymentNotificationEntity);
		}
		return null;

	}

	@Override
	public AlipayPaymentNotificationEntity findPayNotification(
			String pAlipayTradeNumber) throws ServiceDataAccessException {

		final Map<String, Object> parameters = QueryParameter.with("tradeNo", pAlipayTradeNumber).and("softDelete", "N").parameters();
		List<AlipayPaymentNotificationEntity> payNotification= this.findByNamedQuery(AlipayPaymentNotificationEntity.class, 
				AlipayPaymentNotificationEntity.BY_TRADE_NO, 
				parameters);
		if (payNotification == null || payNotification.size() == 0) {	
			LogSupport.debug("no AlipayPaymentNotificationEntity found when pAlipayTradeNumber:: " + pAlipayTradeNumber);
		} else {
			LogSupport.debug("AlipayPaymentNotificationEntity found when pAlipayTradeNumber:: " + pAlipayTradeNumber);	
		}
		if(payNotification.size()>0){
			return payNotification.iterator().next();
		}
		return null;

	}

	/***
	 * 
	 */
	@Override
	public List<AlipayAccountConfigEntity> findAllAccountConfig()
			throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("softDelete", "N").parameters();
		return this.findByNamedQuery(AlipayAccountConfigEntity.class, AlipayAccountConfigEntity.BY_FETCH_ALL, parameters);
	}


}
