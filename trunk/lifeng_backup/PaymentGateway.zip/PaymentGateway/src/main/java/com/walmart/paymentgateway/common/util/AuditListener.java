/**
 * 
 */
package com.walmart.paymentgateway.common.util;

import java.sql.Timestamp;

import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import com.walmart.paymentgateway.model.BaseEntity;

/**
 * @author sgopisetty
 *
 */
public class AuditListener {
	@PrePersist
	public void prePersist(BaseEntity pBaseEntity) {
		pBaseEntity.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		pBaseEntity.setCreatedBy("SYSTEM"); //When inserting all records are active
		pBaseEntity.setSoftDelete("N"); //When inserting all records are active 
		pBaseEntity.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		pBaseEntity.setLastModifiedBy("SYSTEM");
	}

	@PreUpdate
	public void preUpdate(BaseEntity pBaseEntity) {
		pBaseEntity.setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		pBaseEntity.setLastModifiedBy("SYSTEM");
		
	}

	@PreRemove
	public void preRemove(BaseEntity pBaseEntity ) throws Exception {
		// TODO: Need to define better exception type here.
		throw new Exception("Hard Deletes of database records is not allowed.");
	}
	
	/**
	 * check if the entity has been soft deleted
	 * @return soft delete status
	 */
	public boolean isDeleted(BaseEntity pBaseEntity){
		return "Y".equalsIgnoreCase(pBaseEntity.getSoftDelete());
	}

}
