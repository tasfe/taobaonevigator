package com.walmart.paymentgateway.dao;

import java.util.List;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.TransactionEventStatusEntity;
import com.walmart.paymentgateway.model.TransactionStatusEntity;
import com.walmart.paymentgateway.model.TransactionTypeLkEntity;


/***
 * @author sgopisetty
 *
 */
public interface StaticLookUpDao {
	/***
	 * 
	 * @param paymethodcode
	 * @return
	 */
	public SrvProviderPayTypeCodeEntity findServicePayMethodCode(String paymethodcode)throws ServiceDataAccessException;
	/***
	 * 
	 * @param pDomainName
	 * @return
	 */
	public DomainLkEntity findDomainInfoByName(String pDomainName) throws ServiceDataAccessException;
	/***
	 * 
	 * @param pId
	 * @return
	 */
	public DomainLkEntity findDomainInfoById(Long pId) throws ServiceDataAccessException;
	/***
	 * 
	 * @param pTenantName
	 * @return
	 */
	public ChannelLkEntity findChannelInfoByName(String pTenantName)throws ServiceDataAccessException;
	/***
	 * 
	 * @param pId
	 * @return
	 */
	public ChannelLkEntity findChannelInfoById(Long pId)throws ServiceDataAccessException;
	/***
	 * 
	 * @param pOriginName
	 * @return
	 */
	public RequestOriginLkEntity findRequestOriginInfoByName(String pOriginName) throws ServiceDataAccessException;
	/**
	 * 
	 * @param pId
	 * @return
	 */
	public RequestOriginLkEntity findRequestOriginInfoById(Long pId) throws ServiceDataAccessException;
	/***
	 * 
	 * @param pTypeName
	 * @return
	 */
	public TransactionTypeLkEntity findTransactionTypeByName(String pTypeName) throws ServiceDataAccessException;
	
	/***
	 * 
	 * @param pStatusName
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public TransactionStatusEntity findTransactionStatus(String pStatusName) throws ServiceDataAccessException;
	
	/***
	 * 
	 * @param pId
	 * @return
	 */
	public TransactionTypeLkEntity findTransactionTypeById(Long pId) throws ServiceDataAccessException;
	/**
	 * 
	 * @param pId
	 * @return
	 */
	public TransactionEventStatusEntity findTransactionEventStatusById(Long pId) throws ServiceDataAccessException;
	/***
	 * 
	 * @param pStatusName
	 * @return
	 */
	public TransactionEventStatusEntity findTransactionEventStatusByName(String pStatusName) throws ServiceDataAccessException;
	
	/***
	 * 
	 * @return
	 * @throws ServiceDataAccessException
	 */
	public List<SrvProviderEntity> findAllServiceProvider()throws ServiceDataAccessException;


}
