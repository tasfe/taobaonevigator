package com.walmart.paymentgateway.exceptions;

public class ServiceRunTimeException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ServiceRunTimeException() {
		super();
	}

	public ServiceRunTimeException(String msg) {
		super(msg);
	}

	public ServiceRunTimeException(Throwable cause) {
		super(cause);
	}

	public ServiceRunTimeException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
