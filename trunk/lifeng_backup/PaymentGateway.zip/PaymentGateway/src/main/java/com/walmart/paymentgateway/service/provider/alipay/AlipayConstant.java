/**
 * 
 */
package com.walmart.paymentgateway.service.provider.alipay;

/**
 * @author sgopisetty
 *
 */
public interface AlipayConstant {

	
	/**
	 * Hold the equal symbol
	 */
	public static final String EQUAL_SYMBL = "=";
	/**
	 * Holds the ampersand symbol
	 */
	public static final String AMPERSAND_SYMBL = "&";

	/**
	 * Holds the empty value
	 */
	public static final String EMPTY = "";

	/**
	 * Holds the combination of string 'sign' and symbol '='
	 */
	public static final String SIGN_EQUAL = "sign=";

	/**
	 * Holds the combination of synbol '&' , string 'sign' and symbol '='
	 */
	public static final String SIGNTYPE_SYMBOLS = "&sign_type=";
	
	public static final String CONST_F = "F";
	public static String UTF8 = "UTF-8";
	public static String ALIPAY_PAYMENT_SERVICE_INTERFACE = "create_direct_pay_by_user";
	public static String ALIPAY_CANCEL_SERVICE_INTERFACE = "close_trade";
	static public final String BANKPAY = "bankPay";
	static public final String DIRECTPAY= "directPay";
	
	///Alipay Transaction Error codes.
	static String WAIT_BUYER_PAY = "WAIT_BUYER_PAY"; //The buyer is expected to make the payment
	static String TRADE_FINISHED = "TRADE_FINISHED"; //The payment has been made, transaction closes
	static String TRADE_SUCCESS = "TRADE_SUCCESS"; //The payment has been made, transaction closes
	static String TRADE_CLOSED = "TRADE_CLOSED"; //Transaction closed without payment.
		//Alipay List of error codes
	static String ILLEGAL_SIGN = "ILLEGAL_SIGN";// wrong signature
	static String ILLEGAL_ARGUMENT = "ILLEGAL_ARGUMENT"; //Wrong Argument
	static String TRADE_NOT_EXIST = "TRADE_NOT_EXIST"; // Trade not exist
	static String ILLEGAL_PARTNER = "ILLEGAL_PARTNER"; //Partner not exist
	static String HAS_NO_PRIVILEGE = "HAS_NO_PRIVILEGE"; // No Service privilege
		

}
