package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ORDER_INFO database table.
 * 
 */
@Entity
@Table(name="ORDER_INFO")
public class OrderInfoEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_ORDER_ID = "BY_ORDER_ID";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ORDER_INFO_PK_GENERATOR", sequenceName="ORDER_INFO_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ORDER_INFO_PK_GENERATOR")
	@Column(name="ORDER_INFO_PK")
	private Long orderInfoPk;

	@Column(name="EXT_ORDER_ID")
	private String extOrderId;

	//bi-directional many-to-one association to AccountEntity
    @ManyToOne
	@JoinColumn(name="ACCOUNT_FK")
	private AccountEntity account;

	//bi-directional many-to-one association to TransactionEntity
	@OneToMany(mappedBy="orderInfo")
	private Set<TransactionEntity> transactions;

    public OrderInfoEntity() {
    }

	public Long getOrderInfoPk() {
		return this.orderInfoPk;
	}

	public void setOrderInfoPk(Long orderInfoPk) {
		this.orderInfoPk = orderInfoPk;
	}

	public String getExtOrderId() {
		return this.extOrderId;
	}

	public void setExtOrderId(String extOrderId) {
		this.extOrderId = extOrderId;
	}


	public AccountEntity getAccount() {
		return this.account;
	}

	public void setAccount(AccountEntity accountEntity) {
		this.account = accountEntity;
	}
	
	public Set<TransactionEntity> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<TransactionEntity> transactionEntities) {
		this.transactions = transactionEntities;
	}
	
}