package com.walmart.paymentgateway.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.dao.StaticLookUpDao;
import com.walmart.paymentgateway.model.ProviderPayMethodInfo;
import com.walmart.paymentgateway.model.SrvProviderEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeEntity;

/**
 * This class holds minimum data from  SrvProviderEntity,SrvProviderPayTypeEntity SrvProviderPayTypeCodeEntity entities
 *	creates ProviderPayMethodInfo objects from these entities.
 */
@Component("payMethodHolder")
public class PayMethodHolder {

	
	@Autowired 
    private StaticLookUpDao staticLookUpDao;
	private Map<String,ProviderPayMethodInfo> payMethodMap = null;
	
	public PayMethodHolder(StaticLookUpDao staticLookUpDao){
		
		LogSupport.debug("Start Initiating  PayMethodHolder ");
		this.staticLookUpDao = staticLookUpDao;
		payMethodMap = new HashMap<String, ProviderPayMethodInfo>();
		loadProviderPayCodeMap();
		LogSupport.debug("End Initiating  PayMethodHolder ");
	}
	public ProviderPayMethodInfo   getProviderPayMethodInfo(String intPayCode){
		
		//loadProviderPayCodeMap();
		return payMethodMap.get(intPayCode);
	}
	private void loadProviderPayCodeMap() {
		
		LogSupport.debug("Start  loadProviderPayCodeMap() ");
		ProviderPayMethodInfo providerPayMethodInfo = null;
		List<SrvProviderEntity> providerList = staticLookUpDao.findAllServiceProvider();
		Set<SrvProviderPayTypeEntity> payTypeEntitySet = null;
		Set<SrvProviderPayTypeCodeEntity> payCodeEntitySet = null;
		LogSupport.debug("providerList size "+providerList.size());
		
		String providerCode = null;
		String payMethod = null;
		String extPayCode = null;
		String intPayCode = null;
		String infoType = null;
		
		for (SrvProviderEntity providerEntity : providerList) {
			providerCode = null;
			infoType =  null;
			providerCode =providerEntity.getName();
			infoType =providerEntity.getType();
			LogSupport.debug(" Provider Name " +providerCode);
			LogSupport.debug(" Provider Info Type " +infoType);
			payTypeEntitySet = providerEntity.getSrvProviderPayTypes();
			for (SrvProviderPayTypeEntity payTypeEntity : payTypeEntitySet) {
				payMethod = null;
				payMethod = payTypeEntity.getName();
				LogSupport.debug("Payment Mode " + payMethod);
				payCodeEntitySet = payTypeEntity.getSrvProviderPayTypeCodes();
				for (SrvProviderPayTypeCodeEntity payCodeEntity : payCodeEntitySet) {
					extPayCode = null;
					intPayCode = null;
					extPayCode = payCodeEntity.getExtPayCode();
					intPayCode = payCodeEntity.getIntPayCode();
					LogSupport.debug("Payment Code Service Provider " + extPayCode);
					LogSupport.debug("Payment Code Payment System Mapped " + intPayCode);
					providerPayMethodInfo = new ProviderPayMethodInfo(providerCode,payMethod,extPayCode,infoType);
					payMethodMap.put(intPayCode,providerPayMethodInfo);
				}
			}
		}
		LogSupport.debug("End  loadProviderPayCodeMap() ");
	
	}
}
