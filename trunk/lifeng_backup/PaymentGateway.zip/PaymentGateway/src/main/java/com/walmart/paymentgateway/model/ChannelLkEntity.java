package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the TENANT_LK database table.
 * 
 */
@Entity
@Table(name="CHANNEL_LK")
public class ChannelLkEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="CHANNELPK_GENERATOR", sequenceName="CHANNEL_LK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CHANNELPK_GENERATOR")
	@Column(name="CHANNEL_PK")
	private Long channelPk;

	private String description;

	private String name;

	//bi-directional many-to-one association to AlipayAccountConfigEntity
	@OneToMany(mappedBy="channelLk")
	private Set<AlipayAccountConfigEntity> alipayAccountConfigs;

	//bi-directional many-to-one association to TransactionEntity
	@OneToMany(mappedBy="channelLk")
	private Set<TransactionEntity> transactions;

    public ChannelLkEntity() {
    }

	public Long getchannelPk() {
		return this.channelPk;
	}

	public void setchannelPk(Long channelPk) {
		this.channelPk = channelPk;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<AlipayAccountConfigEntity> getAlipayAccountConfigs() {
		return this.alipayAccountConfigs;
	}

	public void setAlipayAccountConfigs(Set<AlipayAccountConfigEntity> alipayAccountConfigEntities) {
		this.alipayAccountConfigs = alipayAccountConfigEntities;
	}
	
	public Set<TransactionEntity> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<TransactionEntity> transactionEntities) {
		this.transactions = transactionEntities;
	}
	
}