package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.QueryParameter;
import com.walmart.paymentgateway.model.OrderInfoEntity;

/***
 * 
 * @author sgopisetty
 *
 */
@Repository
public class OrderInfoDaoImpl extends GenericDaoImpl implements OrderInfoDao {

	/***
	 * 
	 */
	@Override
	public OrderInfoEntity createOrderInfo(OrderInfoEntity pOrderInfoEntity) {
		if(null==pOrderInfoEntity.getOrderInfoPk()){
		    LogSupport.debug("persisting the OrderInfoEntity...");
            return this.create(pOrderInfoEntity);
		}else{
		    LogSupport.debug("merging the OrderInfoEntity...");
            em.merge(pOrderInfoEntity);
		}
		return null;
    }

	/***
	 * 
	 */
	@Override
	public OrderInfoEntity findOrderInfo(String pOrderId) {
		final Map<String, Object> parameters = QueryParameter.with("extOrderId", pOrderId).and("softDelete", "N").parameters();
		List<OrderInfoEntity> order = this.findByNamedQuery(OrderInfoEntity.class, OrderInfoEntity.BY_ORDER_ID, parameters);

		if (order == null || order.size() == 0) {
			LogSupport.debug("no OrderEntity found when Order id = " + pOrderId);
		} else {
			LogSupport.debug("OrderEntity found when Order id = " + pOrderId);	
		}
		
		if (order != null && order.iterator().hasNext()) {
			return order.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public OrderInfoEntity findOrderInfoById(Long pId) {
		final Map<String, Object> parameters = QueryParameter.with("orderPk", pId).and("softDelete", "N").parameters();
		List<OrderInfoEntity> order = this.findByNamedQuery(OrderInfoEntity.class, OrderInfoEntity.BY_ORDER_ID, parameters);

		if (order == null || order.size() == 0) {
			LogSupport.debug("no OrderEntity found when ID = " + pId);
		} else {
			LogSupport.debug("OrderEntity found when ID = " + pId);	
		}
		
		if (order != null && order.iterator().hasNext()) {
			return order.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public List<OrderInfoEntity> getAllOrder() {
		// TODO Auto-generated method stub
		return null;
	}


}
