package com.walmart.paymentgateway.builder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.CancelResponse;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.util.ReasonCode;

/**
 * 
 * @author sgopisetty
 *
 */
@Component("cancelResponseBuilder")
public class CancelResponseBuilder  {
	
	CancelResponse cancelResponse = null;	
	CancelTransactionResponse cancelTransactionResponse = null;
	
	/**
	 * @return the cancelTransactionResponse
	 */
	public CancelTransactionResponse getCancelTransactionResponse() {
		return cancelTransactionResponse;
	}

	/**
	 * @param cancelTransactionResponse the cancelTransactionResponse to set
	 */
	public void setCancelTransactionResponse(
			CancelTransactionResponse cancelTransactionResponse) {
		this.cancelTransactionResponse = cancelTransactionResponse;
	}

	public CancelResponse getCancelResponse() {
		return cancelResponse;
	}

	public void setCancelResponse(CancelResponse cancelResponse) {
		this.cancelResponse = cancelResponse;
	}
	
	public CancelResponseBuilder(){ 		
		initCancelResponse(); 
	}
	
	public void addToCancelResponse(CancelTransactionResponse cancelTransactionResponse) {
		cancelResponse.getCancelTransactionResponse().add(cancelTransactionResponse);
	}
	
	public void buildTransactionErrorResponse(String pInterCorrelationId, String pReasonCode, String pDescription) {
		CancelTransactionResponse pCancelTransReponse = null;
		Error resErr = null;
		pCancelTransReponse = getResponseObjectFactory().createCancelTransactionResponse();
		if (!StringUtils.isEmpty(pInterCorrelationId)) {
			pCancelTransReponse.setTransactionId(pInterCorrelationId);
		}
		resErr = createErroResponse(pReasonCode, pDescription);
		pCancelTransReponse.setTransactionStatus(ReasonCode.ERROR);
		pCancelTransReponse.setTransactionStatusCode(ReasonCode.FAIL);
		pCancelTransReponse.setError(resErr);
		addToCancelResponse(pCancelTransReponse);
	}
	
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 */
	public void buildHeaderErrorResponse(String pCode, String pDescription, String pResponseStatus) {
		Error resErr = null;
		resErr = createErroResponse(pCode, pDescription);
		getCancelResponse().setError(resErr);
		getCancelResponse().setResponseStatus(pResponseStatus);
	}
	
/*	private void setResponseStatus(String pTransactionStatus) {
		if (pTransactionStatus.equalsIgnoreCase(arg0)) {
			
		}
	}
*/	
	
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 * @return
	 */
	public Error createErroResponse(String pCode, String pDescription) {
		Error resErr =  getResponseObjectFactory().createError();
		resErr.setCode(pCode);
		resErr.setDescription(pDescription);
		return resErr;
	}

	private void initCancelResponse(){
		
		cancelResponse = getResponseObjectFactory().createCancelResponse();

	}
	
	/**
	 * 
	 * @return
	 */
	public CancelTransactionResponse createCancelTransactionResponse() {
		cancelTransactionResponse = getResponseObjectFactory().createCancelTransactionResponse();
		return cancelTransactionResponse;
	}
	/***
	 * 
	 * @return
	 */
	private ObjectFactory getResponseObjectFactory(){
		
		return new ObjectFactory();
	}
}
