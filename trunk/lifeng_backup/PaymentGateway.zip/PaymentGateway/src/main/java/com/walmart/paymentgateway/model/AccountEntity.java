package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ACCOUNT database table.
 * 
 */
@Entity
@Table(name="ACCOUNT")
public class AccountEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ACCOUNTPK_GENERATOR", sequenceName="ACCOUNT_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ACCOUNTPK_GENERATOR")
	@Column(name="ACCOUNT_PK")
	private Long accountPk;

	@Column(name="EXT_CUSTOMER_ID")
	private String extCustomerId;

	//bi-directional many-to-one association to DomainLk
    @ManyToOne
	@JoinColumn(name="DOMAIN_FK")
	private DomainLkEntity domainLk;

	//bi-directional many-to-one association to OrderInfoEntity
	@OneToMany(mappedBy="account",   cascade = CascadeType.ALL)
	private Set<OrderInfoEntity> orderInfos = new HashSet<OrderInfoEntity>();;

    public AccountEntity() {
    }

	public Long getAccountPk() {
		return this.accountPk;
	}

	public void setAccountPk(Long accountPk) {
		this.accountPk = accountPk;
	}

	public String getExtCustomerId() {
		return this.extCustomerId;
	}

	public void setExtCustomerId(String extCustomerId) {
		this.extCustomerId = extCustomerId;
	}

	public DomainLkEntity getDomainLk() {
		return this.domainLk;
	}

	public void setDomainLk(DomainLkEntity domainLk) {
		this.domainLk = domainLk;
	}
	
	public Set<OrderInfoEntity> getOrderInfos() {
		return this.orderInfos;
	}

	public void setOrderInfos(Set<OrderInfoEntity> orderInfoEntities) {
		this.orderInfos = orderInfoEntities;
	}
	
}