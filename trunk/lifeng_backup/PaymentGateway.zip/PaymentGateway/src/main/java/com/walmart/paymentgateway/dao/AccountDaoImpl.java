package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.QueryParameter;
import com.walmart.paymentgateway.dao.AccountDao;
import com.walmart.paymentgateway.dao.GenericDaoImpl;
import com.walmart.paymentgateway.model.AccountEntity;

/**
 * 
 * @author sgopisetty
 *
 */
@Repository
public class AccountDaoImpl extends GenericDaoImpl implements AccountDao {

	/**
	 * 
	 */
	@Override
	public AccountEntity createAccount(AccountEntity pAccountEntity) {
		if (null == pAccountEntity.getAccountPk() ){
			this.create(pAccountEntity);
		} else {
			em.merge(pAccountEntity);
		}
		return pAccountEntity;

	}

	/**
	 * 
	 */
	@Override
	public AccountEntity findAccountByName(String pCustomerId) {
		final Map<String, Object> parameters = QueryParameter.with("extCustomerId", pCustomerId).and("softDelete", "N").parameters();
		List<AccountEntity> accountEntity = this.findByNamedQuery(AccountEntity.class, AccountEntity.BY_NAME, parameters);

		if (accountEntity == null || accountEntity.size() == 0) {
			LogSupport.debug("no AccountEntity found when customerId = " + pCustomerId);
		} else {
			LogSupport.debug("AccountEntity found when customerId = " + pCustomerId);	
		}
		
		if (accountEntity != null && accountEntity.iterator().hasNext()) {
			return accountEntity.iterator().next();
		} else {
			return null;
		}
		
	}

	/**
	 * 
	 */
	@Override
	public AccountEntity findAccountById(Long pId) {
		final Map<String, Object> parameters = QueryParameter.with("accountPk", pId).and("softDelete", "N").parameters();
		List<AccountEntity> accountEntity = this.findByNamedQuery(AccountEntity.class, AccountEntity.BY_NAME, parameters);

		if (accountEntity == null || accountEntity.size() == 0) {
			LogSupport.debug("no AccountEntity found when ID = " + pId);
		} else {
			LogSupport.debug("AccountEntity found when ID = " + pId);	
		}
		
		if (accountEntity != null && accountEntity.iterator().hasNext()) {
			return accountEntity.iterator().next();
		} else {
			return null;
		}
		
	}

	

}
