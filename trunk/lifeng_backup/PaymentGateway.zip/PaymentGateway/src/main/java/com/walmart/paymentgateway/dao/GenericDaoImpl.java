/**
 * 
 */
package com.walmart.paymentgateway.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.BaseEntity;

/**
 * Common interface for all DAO objects. All DAO's should extend the
 * <code>GenericDao<code> and manage CRUD operations using methods defined in this DAO.
 */
@Repository
public abstract class GenericDaoImpl implements GenericDao {

	/**
	 * 
	 */
	@PersistenceContext(unitName="paymentPersistenceUnit")
    protected EntityManager em;
    
	@Override
    public <T extends BaseEntity> T create(T entity) throws ServiceDataAccessException{
    	
        try {
			if ( entity != null) {
			    em.persist(entity);
			    em.flush();
			    em.refresh(entity);
			}
			return entity;
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceDataAccessException("Exception occurs when inserting data to Database "+e.getMessage(),e);
		}
    }


    @Override
    public <T extends BaseEntity> T find(Object entityPk,Class<T>  entityClass) throws ServiceDataAccessException{
		try {
			T t = this.em.find(entityClass, entityPk);
			if (t.isDeleted()) {
				return null;
			}
			return t;
		} catch (Exception e) {
			throw new ServiceDataAccessException("Exception occurs when fetching data from Database "+e.getMessage(),e);
		}
    }
  

    @Override
    public <T extends BaseEntity> T update(T t) throws ServiceDataAccessException{
    	T newEntity = null;
        try {
			if ( t != null ) {
			    newEntity = this.em.merge(t);
			    if (newEntity.isDeleted()) {
					return null;
				}
			}
			return newEntity;
		} catch (Exception e) {
			throw new ServiceDataAccessException("Exception occurs when updating data in Database "+e.getMessage(),e);
		}
    }


    @Override
    public <T extends BaseEntity> boolean delete(Object entityId, Class<T> entityClass) throws ServiceDataAccessException{
		try {
			T entity = this.em.getReference(entityClass, entityId);
			entity.setSoftDelete("Y");
			T result = this.update(entity);
			return (result == null);
		} catch (Exception e) {
			throw new ServiceDataAccessException("Exception occurs when deleting data from Database "+e.getMessage(),e);
		}
    }


    
	@Override
	public <T extends BaseEntity> List<T> findByNamedQuery(
			Class<T> entityClass, String namedQuery) throws ServiceDataAccessException{
		return findByNamedQuery(entityClass, namedQuery, null);

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends BaseEntity> List<T> findByNamedQuery(Class<T> entityClass,
			String namedQuery, Map<String, Object> parameters) throws ServiceDataAccessException{
		
		try {
			final Query query = this.em.createNamedQuery(entityClass.getSimpleName() + "." + namedQuery);
			if ( parameters != null ) {
				for (Entry<String, Object> param : parameters.entrySet()) {
					query.setParameter(param.getKey(), param.getValue());
				}
			}
			final List<T> resultList = query.getResultList();
			if ( resultList == null ) 
				return new LinkedList<T>();
			return resultList;
		} catch (Exception e) {
			throw new ServiceDataAccessException("Exception occurs when fetching data from Database through finding sql by name query "+e.getMessage(),e);
		}
	}

}
