/**
 * 
 */
package com.walmart.paymentgateway.builder;

import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.ObjectFactory;
import com.walmart.paymentgateway.service.domain.PaymentStatus;

/**
 * @author sgopisetty
 *
 */
@Component("paymentStatusBuilder")
public class PaymentStatusBuilder {

	
	PaymentStatus paymentStatus = null;	
	


	public PaymentStatus getPaymentStatus() {
		initPaymentStatus();
		return paymentStatus;
	}


	
	public PaymentStatusBuilder(){ 		
	}
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 */
	public void buildErrorResponse(String pCode, String pDescription) {
		Error resErr = null;
		resErr = createErrorResponse(pCode, pDescription);
		getPaymentStatus().setError(resErr);
	}
	/***
	 * 
	 * @param pCode
	 * @param pDescription
	 * @return
	 */
	private Error createErrorResponse(String pCode, String pDescription) {
		Error resErr =  getResponseObjectFactory().createError();
		resErr.setCode(pCode);
		resErr.setDescription(pDescription);
		return resErr;
	}

	private void initPaymentStatus(){
		
		paymentStatus = getResponseObjectFactory().createPaymentStatus();

	}
	
	/***
	 * 
	 * @return
	 */
	private ObjectFactory getResponseObjectFactory(){
		
		return new ObjectFactory();
	}


}
