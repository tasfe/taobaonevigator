/**
 * 
 */
package com.walmart.paymentgateway.service.provider.alipay;

import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.dao.AlipayServiceDao;
import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;

/**
 * @author sgopisetty
 *
 */
@Component("alipayTransactionTools")
public class AlipayDaoManager extends DaoManager {

	@Autowired
	private AlipayServiceDao alipayServiceDao;

	/**
	 * 
	 * @param pAlipayTradeNo
	 * @return
	 */
	public boolean isTradeExist(String pAlipayTradeNo) {

		if (!StringUtils.isBlank(pAlipayTradeNo)) {
			if (null != alipayServiceDao.findPayNotification(pAlipayTradeNo)) {
				return true;
			}
		}
		return false;
	}
	
	
	
	/***
	 * 
	 * @param pChannelId
	 * @return
	 */
	public AlipayAccountConfigEntity findAlipayConfig(String pChannelName) {
		String channelName = null;
		Collection<AlipayAccountConfigEntity> configList = alipayServiceDao.findAllAccountConfig();
		for (AlipayAccountConfigEntity alipayAccountConfigEntity2 : configList) {
			channelName = alipayAccountConfigEntity2.getChannelLk().getName();
			if (channelName.equalsIgnoreCase(pChannelName)) {
				return alipayAccountConfigEntity2;
			}
		}
		
		return null;
	}


}
