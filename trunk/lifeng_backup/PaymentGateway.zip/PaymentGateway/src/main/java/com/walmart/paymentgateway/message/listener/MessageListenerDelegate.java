package com.walmart.paymentgateway.message.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.message.sender.PaymentStatusSender;
import com.walmart.paymentgateway.service.ICancelRequestService;
import com.walmart.paymentgateway.service.IPaymentNotificationService;
import com.walmart.paymentgateway.service.IRefundNotificationService;
import com.walmart.paymentgateway.service.IRefundRequestService;
import com.walmart.paymentgateway.service.domain.CancelRequest;
import com.walmart.paymentgateway.service.domain.PaymentNotification;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.domain.RefundNotification;
import com.walmart.paymentgateway.service.domain.RefundRequest;
/**
 * 
 * Message Listener Adaptor
 *
 */
@Component("messageListenerDelegate")
public class MessageListenerDelegate implements MessageListener {

	@Autowired
	private IPaymentNotificationService paymentNotificationService;

	@Autowired
	PaymentStatusSender paymentStatusSender;
	
	/*
	 * This method is responsible for receiving payment notification from service providers 
	 * posted to notification receive queue.
	 * The component will then delegate the notification message to service component for processing
	 */
	@Override
	public void receive(PaymentNotification  paymentNotification) {
		LogSupport.info("Start NotificationListener receive");
		LogSupport.info("Message :"+paymentNotification.toString());
		PaymentStatus paymentStatus = paymentNotificationService.handleNotificationService(paymentNotification);
		postPaymentStatus(paymentStatus);
		LogSupport.info("End NotificationListener receive");
	
	}
	
	@Autowired
	IRefundNotificationService refundNotificationService;
	@Override
	public void receive(RefundNotification refundNotification){
	
		LogSupport.debug("Start RefundNotificationListener receive");
		LogSupport.debug("Message :"+refundNotification.toString());
		refundNotificationService.handleRefundNotification(refundNotification);
		LogSupport.debug("End RefundNotificationListener receive");

	}

	private void postPaymentStatus(PaymentStatus paymentStatus){
		
		LogSupport.info("Start MessageListenerDelegate postPaymentStatus()");
		LogSupport.info("paymentStatus :"+paymentStatus);
		if(paymentStatus != null){
			paymentStatusSender.sendMessage(paymentStatus);
		}
		else{
			
			LogSupport.info(" Nothing to Post ");
		}
			
		LogSupport.info("End MessageListenerDelegate postPaymentStatus()");
	}


	@Autowired
	private IRefundRequestService refundRequestService;
	
	@Override
	public void receive(RefundRequest refundRequest){
		
		LogSupport.debug("Start RefundRequestListener receive");
		LogSupport.debug("Message :"+refundRequest.toString());
		refundRequestService.handleRefundRequest(refundRequest);
		LogSupport.debug("End RefundRequestListener receive");

	}

	@Autowired
	private ICancelRequestService cancelRequestService;
	@Override
	public void receive(CancelRequest cancelRequest){
		
		LogSupport.debug("Start CancelRequestListener receive");
		LogSupport.debug("Message :"+cancelRequest.toString());
		cancelRequestService.handleCancelRequest(cancelRequest);
		LogSupport.debug("End CancelRequestListener receive");
	}

}
