package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the "TRANSACTION" database table.
 * 
 */
@Entity
@Table(name="TRANSACTION")
public class TransactionEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";
	public final static String BY_INT_CORRELATION_ID = "BY_INT_CORRELATION_ID";
	public final static String BY_EXT_CORRELATION_ID = "BY_EXT_CORRELATION_ID";
	public final static String BY_ORDER_ID = "BY_ORDER_ID";
	public final static String BY_PAYREQUEST = "BY_PAYREQUEST";

	@Id
	@SequenceGenerator(name="TRANSACTIONPK_GENERATOR", sequenceName="TRANSACTION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACTIONPK_GENERATOR")
	@Column(name="TRANSACTION_PK")
	private Long transactionPk;

	private BigDecimal amount;

	@Column(name="EXT_CORRELATION_ID")
	private String extCorrelationId;

	@Column(name="INT_CORRELATION_ID")
	private String intCorrelationId;

	//bi-directional many-to-one association to AlipayRefundItemEntity
	@OneToMany(mappedBy="transaction")
	private Set<AlipayRefundItemEntity> alipayRefundItems;

	//bi-directional many-to-one association to OrderInfoEntity
    @ManyToOne
	@JoinColumn(name="ORDER_FK")
	private OrderInfoEntity orderInfo;

	//bi-directional many-to-one association to RequestOriginLkEntity
    @ManyToOne
	@JoinColumn(name="REQUEST_ORIGIN_FK")
	private RequestOriginLkEntity requestOriginLk;

	//bi-directional many-to-one association to SrvProviderPayTypeCodeEntity
    @ManyToOne
	@JoinColumn(name="SRV_PAY_METHOD_CODE_FK")
	private SrvProviderPayTypeCodeEntity srvProviderPayTypeCode;

	//bi-directional many-to-one association to TenantLkEntity
    @ManyToOne
	@JoinColumn(name="CHANNEL_FK")
	private ChannelLkEntity channelLk;

	//bi-directional many-to-one association to TransactionStatusEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_STATUS_FK")
	private TransactionStatusEntity transactionStatus;

	//bi-directional many-to-one association to TransactionTypeLkEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_TYPE_FK")
	private TransactionTypeLkEntity transactionTypeLk;

	//bi-directional many-to-one association to TransactionEventEntity
	@OneToMany(mappedBy="transaction")
	private Set<TransactionEventEntity> transactionEvents;

    public TransactionEntity() {
    }

	public Long getTransactionPk() {
		return this.transactionPk;
	}

	public void setTransactionPk(Long transactionPk) {
		this.transactionPk = transactionPk;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getExtCorrelationId() {
		return this.extCorrelationId;
	}

	public void setExtCorrelationId(String extCorrelationId) {
		this.extCorrelationId = extCorrelationId;
	}

	public String getIntCorrelationId() {
		return this.intCorrelationId;
	}

	public void setIntCorrelationId(String intCorrelationId) {
		this.intCorrelationId = intCorrelationId;
	}


	public Set<AlipayRefundItemEntity> getAlipayRefundItems() {
		return this.alipayRefundItems;
	}

	public void setAlipayRefundItems(Set<AlipayRefundItemEntity> alipayRefundItemEntities) {
		this.alipayRefundItems = alipayRefundItemEntities;
	}
	
	public OrderInfoEntity getOrderInfo() {
		return this.orderInfo;
	}

	public void setOrderInfo(OrderInfoEntity orderInfoEntity) {
		this.orderInfo = orderInfoEntity;
	}
	
	public RequestOriginLkEntity getRequestOriginLk() {
		return this.requestOriginLk;
	}

	public void setRequestOriginLk(RequestOriginLkEntity requestOriginLkEntity) {
		this.requestOriginLk = requestOriginLkEntity;
	}
	
	public SrvProviderPayTypeCodeEntity getSrvProviderPayTypeCode() {
		return this.srvProviderPayTypeCode;
	}

	public void setSrvProviderPayTypeCode(SrvProviderPayTypeCodeEntity srvProviderPayTypeCodeEntity) {
		this.srvProviderPayTypeCode = srvProviderPayTypeCodeEntity;
	}
	
	public ChannelLkEntity getChannelLk() {
		return this.channelLk;
	}

	public void setChannelLk(ChannelLkEntity tenantLkEntity) {
		this.channelLk = tenantLkEntity;
	}
	
	public TransactionStatusEntity getTransactionStatus() {
		return this.transactionStatus;
	}

	public void setTransactionStatus(TransactionStatusEntity transactionStatusEntity) {
		this.transactionStatus = transactionStatusEntity;
	}
	
	public TransactionTypeLkEntity getTransactionTypeLk() {
		return this.transactionTypeLk;
	}

	public void setTransactionTypeLk(TransactionTypeLkEntity transactionTypeLkEntity) {
		this.transactionTypeLk = transactionTypeLkEntity;
	}
	
	public Set<TransactionEventEntity> getTransactionEvents() {
		return this.transactionEvents;
	}

	public void setTransactionEvents(Set<TransactionEventEntity> transactionEventEntities) {
		this.transactionEvents = transactionEventEntities;
	}
	
}