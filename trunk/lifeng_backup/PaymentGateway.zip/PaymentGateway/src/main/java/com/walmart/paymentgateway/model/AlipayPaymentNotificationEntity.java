package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_PAYMENT_NOTIFICATION database table.
 * 
 */
@Entity
@Table(name="ALIPAY_PAYMENT_NOTIFICATION")
public class AlipayPaymentNotificationEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";
	public final static String BY_TRADE_NO = "BY_TRADE_NO";

	@Id
	@SequenceGenerator(name="ALIPAY_PAYMENT_NOTIFICATION_PK", sequenceName = "ALIPAY_PAY_NOTIFICATION_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_PAYMENT_NOTIFICATION_PK")
	@Column(name="ALIPAY_PAYMENT_NOTIFICATION_PK")
	private Long alipayPaymentNotificationPk;

	@Column(name="BUYER_EMAIL")
	private String buyerEmail;

	@Column(name="GMT_CREATION_TIME")
	private Timestamp gmtCreationTime;

	@Column(name="GMT_PAYMENT_TIME")
	private Timestamp gmtPaymentTime;

	@Column(name="IS_TOTAL_FEE_ADJUSTED")
	private String isTotalFeeAdjusted;

	@Column(name="OUT_TRADE_NO")
	private String outTradeNo;

	@Column(name="PAYMENT_TYPE")
	private String paymentType;

	private BigDecimal quantity;

	@Column(name="SELLER_EMAIL")
	private String sellerEmail;

	@Column(name="SELLER_ID")
	private String sellerId;

	@Column(name="TOTAL_FEE")
	private BigDecimal totalFee;

	@Column(name="TRADE_NO")
	private String tradeNo;

	@Column(name="TRADE_STATUS")
	private String tradeStatus;

	@Column(name="UNIT_PRICE")
	private BigDecimal unitPrice;

	//bi-directional many-to-one association to AlipayNotificationEntity
    @ManyToOne
	@JoinColumn(name="ALIPAY_NOTIFICATION_FK")
	private AlipayNotificationEntity alipayNotification;

    public AlipayPaymentNotificationEntity() {
    }

	public Long getAlipayPaymentNotificationPk() {
		return this.alipayPaymentNotificationPk;
	}

	public void setAlipayPaymentNotificationPk(Long alipayPaymentNotificationPk) {
		this.alipayPaymentNotificationPk = alipayPaymentNotificationPk;
	}

	public String getBuyerEmail() {
		return this.buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public Timestamp getGmtCreationTime() {
		return this.gmtCreationTime;
	}

	public void setGmtCreationTime(Timestamp gmtCreationTime) {
		this.gmtCreationTime = gmtCreationTime;
	}

	public Object getGmtPaymentTime() {
		return this.gmtPaymentTime;
	}

	public void setGmtPaymentTime(Timestamp gmtPaymentTime) {
		this.gmtPaymentTime = gmtPaymentTime;
	}

	public String getIsTotalFeeAdjusted() {
		return this.isTotalFeeAdjusted;
	}

	public void setIsTotalFeeAdjusted(String isTotalFeeAdjusted) {
		this.isTotalFeeAdjusted = isTotalFeeAdjusted;
	}


	public String getOutTradeNo() {
		return this.outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getPaymentType() {
		return this.paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public BigDecimal getQuantity() {
		return this.quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public String getSellerEmail() {
		return this.sellerEmail;
	}

	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}

	public String getSellerId() {
		return this.sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public BigDecimal getTotalFee() {
		return this.totalFee;
	}

	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}

	public String getTradeNo() {
		return this.tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getTradeStatus() {
		return this.tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public BigDecimal getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public AlipayNotificationEntity getAlipayNotification() {
		return this.alipayNotification;
	}

	public void setAlipayNotification(AlipayNotificationEntity alipayNotificationEntity) {
		this.alipayNotification = alipayNotificationEntity;
	}
	
}