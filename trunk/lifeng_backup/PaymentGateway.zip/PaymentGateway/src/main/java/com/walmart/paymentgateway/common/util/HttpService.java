package com.walmart.paymentgateway.common.util;

import java.io.IOException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.springframework.stereotype.Component;

@Component("httpService")
public class HttpService {
	
	HttpClient httpclient = new DefaultHttpClient();
	public String executeGetMethod(String pUri){
		
		HttpGet httpget = null;
		String responseBody = null;
		try {
			LogSupport.debug("Start HttpService executeGetMethod() ");
			LogSupport.debug("Get URL "+pUri);
			httpclient = new DefaultHttpClient();
			httpget = new HttpGet(pUri);
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			responseBody = httpclient.execute(httpget, responseHandler);
			LogSupport.debug("Response "+responseBody);
			LogSupport.debug("End HttpService executeGetMethod() ");
			return responseBody;
		}
		catch(IOException e){
			e.printStackTrace();
			LogSupport.error(" Error Executing Get Method "+e.getMessage());
			
		}
		finally {
			httpclient.getConnectionManager().shutdown();
		}
		return responseBody;

	}
}
