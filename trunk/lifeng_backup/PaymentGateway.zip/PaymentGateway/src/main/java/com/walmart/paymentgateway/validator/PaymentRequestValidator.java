package com.walmart.paymentgateway.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.dao.DaoManager;
import com.walmart.paymentgateway.model.SrvProviderEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.util.ReasonCode;

@Component("paymentRequestValidator")
public class PaymentRequestValidator {

	@Autowired
	@Qualifier("transactionalTools")
	private DaoManager transactionalTools;
	
	/***
	 * 
	 * @param request
	 * @return
	 */
	public String validateRequest(PaymentRequest request){
		
		if(request == null){
			
			return ReasonCode.INVALID_REQUEST;
		}else {
			if(!StringUtils.hasText(request.getOrderId())){
				return ReasonCode.MISSING_ORDERID;
			}
			if(request.getCustomer() == null){
				return ReasonCode.MISSING_CUSTOMER;
			}
			if(!StringUtils.hasText(request.getCustomer().getCustomerId()) ){
				return ReasonCode.MISSING_CUSTOMER;
			}
			if(!StringUtils.hasText(request.getOriginator()) ){
				return ReasonCode.MISSING_ORIGINATOR;
			} else {
				if (!isValidRequestOrigin(request.getOriginator()))
					return ReasonCode.UNSUPPORTED_REQUEST_ORIGIN;
			}
			if(!StringUtils.hasText(request.getDomain()) ){
				return ReasonCode.MISSING_DOMAIN;
			} else {
				if (!isValidDomain(request.getDomain()))
					return ReasonCode.UNSUPPORTED_DOMAIN;
			}
			if(CollectionUtils.isEmpty(request.getPayUrlRequest())){
				return ReasonCode.MISSING_TRANSACTION_REQUEST;
			}
		}
		return ReasonCode.PASS;
		
	}
	/**
	 * 
	 * @param request
	 * @return
	 */
	public String validatePayUrlRequest(PayUrlRequest request){
		
		if(request == null){
			
			return ReasonCode.INVALID_TRANSACTION_REQUEST;
		}else {
			
			if(!StringUtils.hasText(request.getPayURLServiceCode()))
				return ReasonCode.MISSING_PAYMENTMETHOD_CODE;
			if(!StringUtils.hasText (request.getReturnUrl()))
				return ReasonCode.MISSING_RETURNURL;
		}
		return ReasonCode.PASS;
		
	}
	/***
	 * 
	 * @param pPayUrlRequest
	 * @param pSrvCode
	 * @return
	 */
	public String validateTransactionRequest(PayUrlRequest pPayUrlRequest, String pSrvCode){
		
		if(pPayUrlRequest == null){
			return ReasonCode.MISSING_TRANSACTION_REQUEST;
		}else {
			if(pPayUrlRequest.getAmount() == null)
				return ReasonCode.MISSING_AMOUNT;
			if(pPayUrlRequest.getAmount().doubleValue()<=0)
				return ReasonCode.INVALID_AMOUNT;
			if(!StringUtils.hasText(pPayUrlRequest.getCorrelationId()))
				return ReasonCode.MISSING_CORRELATIONID;
			if(pSrvCode == null)
				return ReasonCode.MISSING_PAYSERVICE_CODE;
			if(!StringUtils.hasText(pPayUrlRequest.getChannel() ) ) {
				return ReasonCode.MISSING_CHANNEL;
			} else {
				if (!isValidChannel(pPayUrlRequest.getChannel()))
					return ReasonCode.UNSUPPORTED_CHANNEL;
			}
				
			
				
		}
		return ReasonCode.PASS;
		
	}
	
	/***
	 * 
	 * @param pChannel
	 * @return
	 */
	public boolean isValidChannel(String pChannel) {
		if (StringUtils.hasText(pChannel)) {
			if (null ==transactionalTools.findChannel(pChannel)){
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 
	 * @param pDomain
	 * @return
	 */
	public boolean isValidDomain(String pDomain) {
		if (StringUtils.hasText(pDomain)) {
			if (null ==transactionalTools.findDomain(pDomain)){
				return false;
			}
		}
		return true;
	}
	
	/***
	 * 
	 * @param pRequestOrigin
	 * @return
	 */
	public boolean isValidRequestOrigin(String pRequestOrigin) {
		if (StringUtils.hasText(pRequestOrigin)) {
			if (null ==transactionalTools.findRequestOrigin(pRequestOrigin)){
				return false;
			}
		}
		return true;
	}
	/***
	 * 
	 * @param payCode
	 * @param type
	 * @return
	 */
	public SrvProviderPayTypeCodeEntity validatePaymentCode(String payCode,String type){
		
		LogSupport.info( " Begin validatePaymentCode() ");
		LogSupport.info( "PayCode " + payCode );
		LogSupport.info( "Type " + type );
		//ServiceProviderHelper providerHelper = new ServiceProviderHelper();
		//ServiceProviderInfo  providerInfo =  providerHelper.getServiceServiceProviderInfo(payCode);
		SrvProviderPayTypeCodeEntity srvpaycodeitem = transactionalTools.findSrvProviderInfo(payCode);
		SrvProviderEntity providerItem = null;
		if (null != srvpaycodeitem) {
			providerItem = srvpaycodeitem.getSrvProviderPayType().getSrvProvider();
		}
		
		LogSupport.info( "ProviderInfo " + providerItem );
		if(providerItem == null || providerItem.getType().equalsIgnoreCase(type)){
			return srvpaycodeitem;
		}
		LogSupport.info( " End validatePaymentCode() ");
		return null;
	}
	
	/***
	 * 
	 * @param payCode
	 * @param type
	 * @return
	 */
	public String  getServiceProviderInfo(String payCode,String type){

		LogSupport.info( " Begin validatePaymentCode() ");
		LogSupport.info( "PayCode " + payCode );
		LogSupport.info( "Type " + type );
		//ServiceProviderHelper providerHelper = new ServiceProviderHelper();
		//ServiceProviderInfo  providerInfo =  providerHelper.getServiceServiceProviderInfo(payCode);
		SrvProviderPayTypeCodeEntity srvpaycodeitem = transactionalTools.findSrvProviderInfo(payCode);
		SrvProviderEntity providerItem = null;
		if (null != srvpaycodeitem) {
			providerItem = srvpaycodeitem.getSrvProviderPayType().getSrvProvider();
		}

		LogSupport.info( "ProviderInfo " + providerItem );
		if(providerItem != null && providerItem.getType().equalsIgnoreCase(type)){
			return providerItem.getName();
		}
		LogSupport.info( " End validatePaymentCode() ");
		return null;
	}
}
