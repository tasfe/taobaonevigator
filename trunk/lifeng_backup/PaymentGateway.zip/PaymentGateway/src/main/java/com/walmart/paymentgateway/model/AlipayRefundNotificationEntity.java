package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_REFUND_NOTIFICATION database table.
 * 
 */
@Entity
@Table(name="ALIPAY_REFUND_NOTIFICATION")
public class AlipayRefundNotificationEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAY_REFUND_NOTIFICATION_PK_GENERATOR", sequenceName = "ALIPAY_REFUND_ITEM_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_REFUND_NOTIFICATION_PK_GENERATOR")
	@Column(name="ALIPAY_REFUND_NOTIFICATION_PK")
	private Long alipayRefundNotificationPk;

	@Column(name="REFUND_STATUS")
	private String refundStatus;

	@Column(name="REFUNDED_AMOUNT")
	private BigDecimal refundedAmount;

	@Column(name="TRADE_NO")
	private BigDecimal tradeNo;

	//bi-directional many-to-one association to AlipayNotificationEntity
    @ManyToOne
	@JoinColumn(name="ALIPAY_NOTIFY_FK")
	private AlipayNotificationEntity alipayNotification;

	//bi-directional many-to-one association to AlipayRefundBatchNotifyEntity
    @ManyToOne
	@JoinColumn(name="ALIPAY_REFUND_BATCH_NOTIFY_FK")
	private AlipayRefundBatchNotifyEntity alipayRefundBatchNotify;

    public AlipayRefundNotificationEntity() {
    }

	public long getAlipayRefundNotificationPk() {
		return this.alipayRefundNotificationPk;
	}

	public void setAlipayRefundNotificationPk(long alipayRefundNotificationPk) {
		this.alipayRefundNotificationPk = alipayRefundNotificationPk;
	}

	public String getRefundStatus() {
		return this.refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public BigDecimal getRefundedAmount() {
		return this.refundedAmount;
	}

	public void setRefundedAmount(BigDecimal refundedAmount) {
		this.refundedAmount = refundedAmount;
	}

	public BigDecimal getTradeNo() {
		return this.tradeNo;
	}

	public void setTradeNo(BigDecimal tradeNo) {
		this.tradeNo = tradeNo;
	}

	public AlipayNotificationEntity getAlipayNotification() {
		return this.alipayNotification;
	}

	public void setAlipayNotification(AlipayNotificationEntity alipayNotificationEntity) {
		this.alipayNotification = alipayNotificationEntity;
	}
	
	public AlipayRefundBatchNotifyEntity getAlipayRefundBatchNotify() {
		return this.alipayRefundBatchNotify;
	}

	public void setAlipayRefundBatchNotify(AlipayRefundBatchNotifyEntity alipayRefundBatchNotifyEntity) {
		this.alipayRefundBatchNotify = alipayRefundBatchNotifyEntity;
	}
	
}