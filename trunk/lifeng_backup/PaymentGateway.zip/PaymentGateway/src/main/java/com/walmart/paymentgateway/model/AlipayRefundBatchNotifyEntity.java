package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_REFUND_BATCH_NOTIFY database table.
 * 
 */
@Entity
@Table(name="ALIPAY_REFUND_BATCH_NOTIFY")
public class AlipayRefundBatchNotifyEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAY_REFUND_BATCH_NOTIFY_PK_GENERATOR", sequenceName = "ALIPAY_REFUND_BATCH_NOTIFY_SEQ"  )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_REFUND_BATCH_NOTIFY_PK_GENERATOR")
	@Column(name="ALIPAY_REFUND_BATCH_NOTIFY_PK")
	private Long alipayRefundBatchNotifyPk;

	@Column(name="SUCCESS_NO")
	private BigDecimal successNo;

	//bi-directional many-to-one association to AlipayRefundBatchEntity
    @ManyToOne
	@JoinColumn(name="ALIPAY_REFUND_BATCH_FK")
	private AlipayRefundBatchEntity alipayRefundBatch;

	//bi-directional many-to-one association to AlipayRefundNotificationEntity
	@OneToMany(mappedBy="alipayRefundBatchNotify")
	private Set<AlipayRefundNotificationEntity> alipayRefundNotifications;

    public AlipayRefundBatchNotifyEntity() {
    }

	public Long getAlipayRefundBatchNotifyPk() {
		return this.alipayRefundBatchNotifyPk;
	}

	public void setAlipayRefundBatchNotifyPk(Long alipayRefundBatchNotifyPk) {
		this.alipayRefundBatchNotifyPk = alipayRefundBatchNotifyPk;
	}

	public BigDecimal getSuccessNo() {
		return this.successNo;
	}

	public void setSuccessNo(BigDecimal successNo) {
		this.successNo = successNo;
	}

	public AlipayRefundBatchEntity getAlipayRefundBatch() {
		return this.alipayRefundBatch;
	}

	public void setAlipayRefundBatch(AlipayRefundBatchEntity alipayRefundBatchEntity) {
		this.alipayRefundBatch = alipayRefundBatchEntity;
	}
	
	public Set<AlipayRefundNotificationEntity> getAlipayRefundNotifications() {
		return this.alipayRefundNotifications;
	}

	public void setAlipayRefundNotifications(Set<AlipayRefundNotificationEntity> alipayRefundNotificationEntities) {
		this.alipayRefundNotifications = alipayRefundNotificationEntities;
	}
	
}