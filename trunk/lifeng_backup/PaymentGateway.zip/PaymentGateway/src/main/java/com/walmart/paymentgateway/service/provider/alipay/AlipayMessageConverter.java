package com.walmart.paymentgateway.service.provider.alipay;

import java.io.StringReader;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.service.provider.alipay.domain.Alipay;

/**
 * This class is responsible for marshalling ALIPAY response XML to JAX objects 
 * Useful for parsing Cancel/Query/Refund response from ALIPAY
 *
 */
@Component("alipayMessageConverter")
public class AlipayMessageConverter {

	@Autowired	
	Jaxb2Marshaller alipayDomainMarshaller = null;
	
	
	public Alipay convertAlipayResponse(String responseXML){
		
		LogSupport.debug(" ALIPAY response XML "+responseXML);
		StringReader reader  = new StringReader(responseXML);
		Source source  = new StreamSource(reader);
		Alipay alipay = (Alipay)alipayDomainMarshaller.unmarshal(source);
		LogSupport.debug(" ALIPAY Object "+alipay);
		return alipay;
		
	}
}
