package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_REFUND_ITEM database table.
 * 
 */
@Entity
@Table(name="ALIPAY_REFUND_ITEM")
public class AlipayRefundItemEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAY_REFUND_ITEM_PK_GENERATOR", sequenceName = "ALIPAY_REFUND_ITEM_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_REFUND_ITEM_PK_GENERATOR")
	@Column(name="ALIPAY_REFUND_ITEM_PK")
	private Long alipayRefundItemPk;

	@Column(name="PARTNER_ID")
	private String partnerId;

	@Column(name="REFUND_REASON")
	private String refundReason;

	@Column(name="REFUND_REQ_DATE")
	private Timestamp refundReqDate;

	@Column(name="REFUND_STATUS")
	private String refundStatus;

	@Column(name="TRADE_NO")
	private BigDecimal tradeNo;

	//bi-directional many-to-one association to TransactionEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_FK")
	private TransactionEntity transaction;

    public AlipayRefundItemEntity() {
    }

	public Long getAlipayRefundItemPk() {
		return this.alipayRefundItemPk;
	}

	public void setAlipayRefundItemPk(Long alipayRefundItemPk) {
		this.alipayRefundItemPk = alipayRefundItemPk;
	}



	public String getPartnerId() {
		return this.partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getRefundReason() {
		return this.refundReason;
	}

	public void setRefundReason(String refundReason) {
		this.refundReason = refundReason;
	}

	public Timestamp getRefundReqDate() {
		return this.refundReqDate;
	}

	public void setRefundReqDate(Timestamp refundReqDate) {
		this.refundReqDate = refundReqDate;
	}

	public String getRefundStatus() {
		return this.refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}


	public BigDecimal getTradeNo() {
		return this.tradeNo;
	}

	public void setTradeNo(BigDecimal tradeNo) {
		this.tradeNo = tradeNo;
	}

	public TransactionEntity getTransaction() {
		return this.transaction;
	}

	public void setTransaction(TransactionEntity transactionEntity) {
		this.transaction = transactionEntity;
	}
	
}