package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the TP_REQ_RES_DETAIL database table.
 * 
 */
@Entity
@Table(name="TP_REQ_RES_DETAIL")
public class TpReqResDetailEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="TP_REQ_RES_DETAIL_PK_GENERATOR", sequenceName="TP_REQ_RES_DETAIL_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TP_REQ_RES_DETAIL_PK_GENERATOR")
	@Column(name="TP_REQ_RES_DETAIL_PK")
	private Long tpReqResDetailPk;

	@Column(name="INT_CORRELATION_ID")
	private String intCorrelationId;

	@Column(name="REQ_TIMESTAMP")
	private Timestamp reqTimestamp;

    @Lob()
	private String request;

	@Column(name="RES_TIMESTAMP")
	private Timestamp resTimestamp;

    @Lob()
	private String response;

	private String status;

	@Column(name="TYPE")
	private String type;

	//bi-directional many-to-one association to TransactionEventEntity
    @ManyToOne
	@JoinColumn(name="TRANSACTION_EVENT_FK")
	private TransactionEventEntity transactionEvent;

    public TpReqResDetailEntity() {
    }

	public Long getTpReqResDetailPk() {
		return this.tpReqResDetailPk;
	}

	public void setTpReqResDetailPk(Long tpReqResDetailPk) {
		this.tpReqResDetailPk = tpReqResDetailPk;
	}


	public String getIntCorrelationId() {
		return this.intCorrelationId;
	}

	public void setIntCorrelationId(String intCorrelationId) {
		this.intCorrelationId = intCorrelationId;
	}


	public Timestamp getReqTimestamp() {
		return this.reqTimestamp;
	}

	public void setReqTimestamp(Timestamp reqTimestamp) {
		this.reqTimestamp = reqTimestamp;
	}

	public String getRequest() {
		return this.request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public Timestamp getResTimestamp() {
		return this.resTimestamp;
	}

	public void setResTimestamp(Timestamp resTimestamp) {
		this.resTimestamp = resTimestamp;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getSoftDelete() {
		return this.softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public TransactionEventEntity getTransactionEvent() {
		return this.transactionEvent;
	}

	public void setTransactionEvent(TransactionEventEntity transactionEventEntity) {
		this.transactionEvent = transactionEventEntity;
	}
	
}