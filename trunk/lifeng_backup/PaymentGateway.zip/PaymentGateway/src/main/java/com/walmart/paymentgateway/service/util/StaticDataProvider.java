package com.walmart.paymentgateway.service.util;

public class StaticDataProvider {

	public static String srvProviderPaycode[] = new String[] { "ALP-DIRECT",
			"ALP-ICBCB2C", "ALP-CMB", "ALP-CCB", "ALP-ABC", "ALP-SPDB",
			"ALP-CIB", "ALP-GDB", "ALP-SDB", "ALP-CMBC", "ALP-COMM",
			"ALP-CITIC", "ALP-BOCB2C", "ALP-CEBBANK", "ALP-HZCBB2C",
			"ALP-SHBANK", "ALP-SPABANK", "ALP-NBBANK", "ALP-BJBANK",
			"ALP-PSBCDEBIT", "ALP-BJRCB", "ALP-FDB", "WAL-COD" };

	public static String requestOrginCode[] = new String[] { "OMS", "ESTORE",
			"CSC" };

	public static String transactionTypeCode[] = new String[] { "PAY", "REF",
			"CANL", "QUERY", "HIST" };
}
