package com.walmart.paymentgateway.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.QueryParameter;
import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.TransactionEventStatusEntity;
import com.walmart.paymentgateway.model.TransactionStatusEntity;
import com.walmart.paymentgateway.model.TransactionTypeLkEntity;

/***
 * 
 * DAO class for Static Look Up Tables
 *
 */
@Repository("staticLookUpDao")
public class StaticLookUpDaoImpl extends GenericDaoImpl implements
		StaticLookUpDao {

	/***
	 * 
	 */
	@Override
	public DomainLkEntity findDomainInfoById(Long pId) throws ServiceDataAccessException{
        final Map<String, Object> parameters = QueryParameter.with("domainPk", pId).and("softDelete", "N").parameters();
		List<DomainLkEntity> domainEntityList= this.findByNamedQuery(DomainLkEntity.class, 
																DomainLkEntity.BY_ID, 
																parameters);
		if (domainEntityList == null || domainEntityList.size() == 0) {
			LogSupport.debug("no DomainLkEntity found when pId = " + pId);
		} else {
			LogSupport.debug("DomainLkEntity found when pId = " + pId);	
		}
		if(domainEntityList.size()>0){
            return domainEntityList.iterator().next();
        }
        return null;
    }

	/***
	 * 
	 */
	@Override
	public DomainLkEntity findDomainInfoByName(String pDomainName) throws ServiceDataAccessException {
        final Map<String, Object> parameters = QueryParameter.with("name", pDomainName).and("softDelete", "N").parameters();
		List<DomainLkEntity> domainEntityList= this.findByNamedQuery(DomainLkEntity.class, 
																DomainLkEntity.BY_NAME, 
																parameters);
		if (domainEntityList == null || domainEntityList.size() == 0) {
			LogSupport.debug("no DomainLkEntity found when pDomainName = " + pDomainName);
		} else {
			LogSupport.debug("DomainLkEntity found when pDomainName = " + pDomainName);	
		}
		if(domainEntityList.size()>0){
            return domainEntityList.iterator().next();
        }
        return null;
    }

	/***
	 * 
	 */
	@Override
	public RequestOriginLkEntity findRequestOriginInfoById(Long pId) throws ServiceDataAccessException {
        final Map<String, Object> parameters = QueryParameter.with("requestOriginPk", pId).and("softDelete", "N").parameters();
		List<RequestOriginLkEntity> reqOriginList= this.findByNamedQuery(RequestOriginLkEntity.class, 
																		RequestOriginLkEntity.BY_ID, 
																		parameters);
		if (reqOriginList == null || reqOriginList.size() == 0) {
			LogSupport.debug("no RequestOriginLkEntity found when pId = " + pId);
		} else {
			LogSupport.debug("RequestOriginLkEntity found when pId = " + pId);	
		}
		if(reqOriginList.size()>0){
            return reqOriginList.iterator().next();
        }
        return null;
    }

	/***
	 * 
	 */
	@Override
	public RequestOriginLkEntity findRequestOriginInfoByName(String pOriginName) throws ServiceDataAccessException {
        final Map<String, Object> parameters = QueryParameter.with("name", pOriginName).and("softDelete", "N").parameters();
		List<RequestOriginLkEntity> reqOriginList= this.findByNamedQuery(RequestOriginLkEntity.class, 
																		RequestOriginLkEntity.BY_NAME, 
																		parameters);
		if (reqOriginList == null || reqOriginList.size() == 0) {
			LogSupport.debug("no RequestOriginLkEntity found when pOriginName = " + pOriginName);
		} else {
			LogSupport.debug("RequestOriginLkEntity found when pOriginName = " + pOriginName);	
		}
		if(reqOriginList.size()>0){
            return reqOriginList.iterator().next();
        }
        return null;
    }

	/**
	 * 
	 */
	@Override
	public SrvProviderPayTypeCodeEntity findServicePayMethodCode(String pPaymethodcode)throws ServiceDataAccessException {
        final Map<String, Object> parameters = QueryParameter.with("intPayCode", pPaymethodcode).and("softDelete", "N").parameters();
		List<SrvProviderPayTypeCodeEntity> paycodeList= this.findByNamedQuery(SrvProviderPayTypeCodeEntity.class, 
																		SrvProviderPayTypeCodeEntity.BY_INT_PAY_CODE, 
																		parameters);
		if (paycodeList == null || paycodeList.size() == 0) {
			LogSupport.debug("no SrvProviderPayTypeCodeEntity found when pPaymentCode = " + pPaymethodcode);
		} else {
			LogSupport.debug("SrvProviderPayTypeCodeEntity found when pPaymentCode = " + pPaymethodcode);	
		}
		if(paycodeList.size()>0){
            return paycodeList.iterator().next();
        }
        return null;
    }

	/***
	 * 
	 */
	@Override
	public ChannelLkEntity findChannelInfoById(Long pId) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("channelPk", pId).and("softDelete", "N").parameters();
		List<ChannelLkEntity> tenantLkEntity = this.findByNamedQuery(ChannelLkEntity.class, 
																	ChannelLkEntity.BY_ID, 
																	parameters);

		if (tenantLkEntity == null || tenantLkEntity.size() == 0) {
			LogSupport.debug("no ChannelLkEntity found when Id = " + pId);
		} else {
			LogSupport.debug("ChannelLkEntity found when Id = " + pId);	
		}
		
		if (tenantLkEntity != null && tenantLkEntity.iterator().hasNext()) {
			return tenantLkEntity.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public ChannelLkEntity findChannelInfoByName(String pChannelName) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("name", pChannelName).and("softDelete", "N").parameters();
		List<ChannelLkEntity> tenantLkEntity = this.findByNamedQuery(ChannelLkEntity.class, 
																	ChannelLkEntity.BY_NAME, 
																	parameters);

		if (tenantLkEntity == null || tenantLkEntity.size() == 0) {
			LogSupport.debug("no ChannelLkEntity found when ChannelName = " + pChannelName);
		} else {
			LogSupport.debug("ChannelLkEntity found when ChannelName = " + pChannelName);	
		}
		
		if (tenantLkEntity != null && tenantLkEntity.iterator().hasNext()) {
			return tenantLkEntity.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public TransactionEventStatusEntity findTransactionEventStatusById(Long pId) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("transactionEventStatusPk", pId).and("softDelete", "N").parameters();
		List<TransactionEventStatusEntity> transEventStatus = this.findByNamedQuery(TransactionEventStatusEntity.class, 
																			TransactionEventStatusEntity.BY_ID, 
																			parameters);

		if (transEventStatus == null || transEventStatus.size() == 0) {
			LogSupport.debug("no TransactionEventStatus found when Id = " + pId);
		} else {
			LogSupport.debug("TransactionEventStatus found when Id = " + pId);	
		}
		
		if (transEventStatus != null && transEventStatus.iterator().hasNext()) {
			return transEventStatus.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public TransactionEventStatusEntity findTransactionEventStatusByName(
			String pStatusName) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("name", pStatusName).and("softDelete", "N").parameters();
		List<TransactionEventStatusEntity> transEventStatus = this.findByNamedQuery(TransactionEventStatusEntity.class, 
																			TransactionEventStatusEntity.BY_NAME, 
																			parameters);

		if (transEventStatus == null || transEventStatus.size() == 0) {
			LogSupport.debug("no TransactionEventStatus found when status = " + pStatusName);
		} else {
			LogSupport.debug("TransactionEventStatus found when status = " + pStatusName);	
		}
		
		if (transEventStatus != null && transEventStatus.iterator().hasNext()) {
			return transEventStatus.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public TransactionTypeLkEntity findTransactionTypeById(Long pId) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("transactionTypePk", pId).and("softDelete", "N").parameters();
		List<TransactionTypeLkEntity> transTypeLkEntity = this.findByNamedQuery(TransactionTypeLkEntity.class, 
																				TransactionTypeLkEntity.BY_ID,
																				parameters);

		if (transTypeLkEntity == null || transTypeLkEntity.size() == 0) {
			LogSupport.debug("no TransactionTypeLkEntity found when Id = " + pId);
		} else {
			LogSupport.debug("TransactionTypeLkEntity found when Id = " + pId);	
		}
		
		if (transTypeLkEntity != null && transTypeLkEntity.iterator().hasNext()) {
			return transTypeLkEntity.iterator().next();
		} else {
			return null;
		}
		
	}

	/***
	 * 
	 */
	@Override
	public TransactionTypeLkEntity findTransactionTypeByName(String pTypeName) throws ServiceDataAccessException {
		final Map<String, Object> parameters = QueryParameter.with("name", pTypeName).and("softDelete", "N").parameters();
		List<TransactionTypeLkEntity> transTypeLkEntity = this.findByNamedQuery(TransactionTypeLkEntity.class, 
																				TransactionTypeLkEntity.BY_NAME, 
																				parameters);

		if (transTypeLkEntity == null || transTypeLkEntity.size() == 0) {
			LogSupport.debug("no TransactionTypeLkEntity found when TypeName = " + pTypeName);
		} else {
			LogSupport.debug("TransactionTypeLkEntity found when TypeName = " + pTypeName);	
		}
		
		if (transTypeLkEntity != null && transTypeLkEntity.iterator().hasNext()) {
			return transTypeLkEntity.iterator().next();
		} else {
			return null;
		}
		
	}
	
	/***
	 * 
	 */
	public TransactionStatusEntity findTransactionStatus(String pStatusName) throws ServiceDataAccessException {

		final Map<String, Object> parameters = QueryParameter.with("name", pStatusName).and("softDelete", "N").parameters();
		List<TransactionStatusEntity> statusList = this.findByNamedQuery(TransactionStatusEntity.class, 
																		 TransactionStatusEntity.BY_NAME, 
																				parameters);

		if (statusList == null || statusList.size() == 0) {
			LogSupport.debug("no TransactionStatusEntity found when status = " + pStatusName);
		} else {
			LogSupport.debug("TransactionStatusEntity found when status = " + pStatusName);	
		}
		
		if (statusList != null && statusList.iterator().hasNext()) {
			return statusList.iterator().next();
		} else {
			return null;
		}
		
	
		
	}
	public List<SrvProviderEntity> findAllServiceProvider()throws ServiceDataAccessException{
		final Map<String, Object> parameters = QueryParameter.with("softDelete", "N").parameters();
		return this.findByNamedQuery(SrvProviderEntity.class, SrvProviderEntity.BY_FETCH_ALL, parameters);


	}
}
