package com.walmart.paymentgateway.model;
/**
 * This class holds providerCode,paymentType,provider payment code information
 * 
 */
public class ProviderPayMethodInfo {

	
	
	private String paymentCode = null;
	private String paymentMethod = null;
	private String providerCode = null;
	private String infoType = null;

	/**
	 * @param providerCode
	 * @param paymentMethod
	 * @param paymentCode
	 * @param infoType
	 */
	public ProviderPayMethodInfo(String providerCode,String paymentMethod,String paymentCode,String infoType){
		
		this.providerCode = providerCode;
		this.paymentMethod = paymentMethod;
		this.paymentCode = paymentCode;
		this.infoType =infoType;
	}
	public String getInfoType() {
		return infoType;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public String getProviderCode() {
		return providerCode;
	}
}
