package com.walmart.paymentgateway.service.util;

public class ReasonCode {

	
	static public final String SUCCESS = "SUCCESS";
	static public final String FAIL = "FAIL";
	static public final String UNSUPPORTED_PROVIDER = "UNSUPPORTED_PROVIDER";
	static public final String UNSUPPORTED_PAYMETHOD = "UNSUPPORTED_PAYMETHOD";
	static public final String INVALID_PARTNER_ID = "INVALID_PARTNER_ID";
	static public final String INVALID_TRANSACTION = "INVALID_TRANSACTION";
	static public final String INVALID_REQUEST = "INVALID_REQUEST";
	static public final String UNKNOW_ERROR = "UNKNOW_ERROR";
	static public final String UNKNOW_ERROR_MSG = "An unknown system exception has happened";
	static public final String MISSING_PARAM = "MISSING_PARAM";
	static public final String PASS = "PASS";
	public static final String ERROR = "ERROR";
	public static final String MISSING_ORDERID = "MISSING_ORDERID";
	public static final String MISSING_CUSTOMER = "MISSING_CUSTOMER";
	public static final String MISSING_RETURNURL = "MISSING_RETURNURL";
	public static final String MISSING_CORRELATIONID = "MISSING_CORRELATIONID";
	public static final String MISSING_DOMAIN = "MISSING_DOMAIN";
	public static final String MISSING_ORIGINATOR = "MISSING_ORIGINATOR";
	public static final String MISSING_CHANNEL = "MISSING_CHANNEL";
	public static final String MISSING_TRANSACTION_REQUEST = "MISSING_TRANSACTION_REQUEST";
	public static final String MISSING_PAYMENTMETHOD_CODE = "MISSING_PAYMENTMETHOD_CODE";
	public static final String MISSING_AMOUNT  = "MISSING_AMOUNT";
	public static final String INVALID_AMOUNT = "INVALID_AMOUNT";
	public static final String INVALID_TRANSACTION_REQUEST = "INVALID_TRANSACTION_REQUEST";
	public static final String PROVIDER_PROCESSOR_NOT_FOUND = "PROVIDER_PROCESSOR_NOT_FOUND";
	public static final String MISSING_PAYSERVICE_CODE = "MISSING_PAYSERVICE_CODE";
	
	public static final String INVALID_NOTIFY_ID = "INVALID_NOTIFY_ID";
	
	public static final String MISSING_CANCEL_TRANSACTION_REQUEST = "MISSING_CANCEL_TRANSACTION_REQUEST";
	public static final String FORCE_REFUND_IS_NULL = "FORCE_REFUND_IS_NULL";
	public static final String MISSING_TRANSACTION_ID = "MISSING_TRANSACTION_ID";
	public static final String INVALID_TRANSACTION_ID = "INVALID_TRANSACTION_ID";
	public static final String COMPLETE = "COMPLETE";
	public static final String CANCEL = "CANCEL";
	public static final String NEW = "NEW";
	public static final String NOT_COMPLETED = "NOT_COMPLETED";
	public static final String MISSING_ORDER = "MISSING_ORDER";
	
	public static final String INVALID_ORDERID = "INVALID ORDER ID";
	
	public static final String ORDER_NOT_FOUND = "ORDER NOT FOUND";
	public static final String TRANSACTION_NOT_FOUND = "TRANSACTION NOT FOUND";
	public static final String TRANSACTION_ALREADY_CANCEL = "TRANSACTION_ALREADY_CANCELED";
	public static final String VALIDATION_FAILED = "INVALID REQUEST";
	public static final String URL_CREATION_FAILED = "URL_CREATION_FAILED";
	public static final String CANCELLED_FAILED = "CANCELLED_FAILED";
	public static final String UNSUPPORTED_CHANNEL = "UNSUPPORTED_CHANNEL";
	public static final String UNSUPPORTED_DOMAIN = "UNSUPPORTED_DOMAIN";
	public static final String UNSUPPORTED_REQUEST_ORIGIN = "UNSUPPORTED_REQUEST_ORIGIN";
	
	public static final String ERR_PARSING_URL = "Error while parsing url parameters";
	
	public static final String ERR_CONNECTION_TIME_OUT = "CONNECTION_FAILURE";
	
}
