package com.walmart.paymentgateway.service.provider.wmcode;


import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.processor.AbstractPaymentProcessor;
import com.walmart.paymentgateway.service.domain.CancelTransactionRequest;
import com.walmart.paymentgateway.service.domain.CancelTransactionResponse;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import com.walmart.paymentgateway.service.domain.PayUrlResponse;
import com.walmart.paymentgateway.service.domain.PaymentRequest;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryRequest;
import com.walmart.paymentgateway.service.domain.SingleTransactionQueryResponse;

/***
 * 
 * @author sgopisetty
 *
 */
@Component("wMPaymentProcessor")
public class WMPaymentProcessor extends AbstractPaymentProcessor{

	@Override
	public void processPaymentRequest(PaymentRequest pRequest,
			PayUrlRequest pPayUrlRequest, PayUrlResponse pPayResponse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processCancelRequest(
			CancelTransactionRequest pCancelTransactionRequest,
			CancelTransactionResponse pCancelTransactionResponse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processSingleQueryRequest(
			SingleTransactionQueryRequest singleQueryRequest,
			SingleTransactionQueryResponse singleQueryResponse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processPaymentNotification(String paymentNotificationMessage,
			PaymentStatus pPaymentStatus) {
		// TODO Auto-generated method stub
		
	}


	

	

	/*CodRequest cod = null;
	PaymentRequest request  = null;
	PayRequest transType  = null;
	PayUrlRequest payUrlType = null;
	String alipayPaymentURL  = null;
	String transactionId = null;
	
	private CodResponse createCodResponse(boolean is_success, PaymentResponse paymetResponse ) {
		
		CodResponse codTypeResponse = null;
		ObjectFactory resFactory = new ObjectFactory();
		codTypeResponse = resFactory.createCodResponse();
		codTypeResponse = resFactory.createCodResponse();
		
		codTypeResponse.setCorrelationId(transType.getCorrelationId());
		if(is_success){
			codTypeResponse.setTransactionStatus("PAYMENT_PENDING");
			codTypeResponse.setTransactionStatusCode(ReasonCode.SUCCESS);
			codTypeResponse.setTransactionId(transactionId);
		}
		else{
			com.walmart.paymentgateway.service.domain.Error err = resFactory.createError();
			err.setCode(ReasonCode.UNKNOW_ERROR);
			err.setDescription(ReasonCode.UNKNOW_ERROR);
			codTypeResponse.setError(err);
			codTypeResponse.setTransactionStatus("NOT COMPLETED");
			codTypeResponse.setTransactionStatusCode("FAIL");
		}
		
		paymetResponse.getPayUrlResponseOrCodResponse().add(codTypeResponse);
		return codTypeResponse;

	}
	@Override
	public SingleQueryResponse processSingleQueryRequest(
			SingleQueryRequest request) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public PayResponse processPaymentRequest(PayRequest request) {

		
		CodResponse codResponse = null;
		PayResponse paymetResponse = super.createPaymentRequest(request);
		
		try{
			//createCodResponse(true, paymetResponse);
		}catch (Exception e) {
			e.printStackTrace();
			//codResponse = createCodResponse(false, paymetResponse);
		}
		
		return (PayResponse)codResponse;
	
	}
	@Override
	public CancelTransactionResponse processCancelRequest(CancelTransactionRequest pCancelTransactionRequest, 
			CancelTransactionResponse pCancelTransactionResponse) {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	
	
	

}
