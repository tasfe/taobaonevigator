package com.walmart.paymentgateway.service.provider.alipay;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.walmart.paymentgateway.common.util.LogSupport;

public class AlipayUtil {
	
	
	public static Timestamp toTimestamp(String pValue) {
	      DateFormat formatter;
	      
	      formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	      java.sql.Timestamp timeStampDate = null;
	      Date date;
		try {
			date = (Date) formatter.parse(pValue);
			timeStampDate  = new Timestamp(date.getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	      return timeStampDate;
	  }
	
	public static BigDecimal toBigDecimal(String pValue) {
		BigDecimal num2 = null;
		num2 = new BigDecimal(pValue);
		return num2;
	}
	


	/**
	 * This will generate the String from key/value pair.
	 * 
	 * @param pParams - contains request parameters
	 * @param pPrivateKey - type of encoding 
	 * @return - returns string as key/value pair along with char set.
	 */
	public static String getContent(Map<String, String> pParams, String pPrivateKey) {

		LogSupport.debug("Entering into AlipayUtil getContent()");

		//Get the list of keys 
		List<String> keys = new ArrayList<String>(pParams.keySet());
		//Sort the keys
		Collections.sort(keys);

		String prestr = AlipayConstant.EMPTY;
		StringBuffer sbPreStr = new StringBuffer();
		int size = keys.size();
		for (int i = 0; i < size ; i++) {
			String key = (String) keys.get(i);
			String value = (String) pParams.get(key);

			LogSupport.debug("Param name is :" + key);
			LogSupport.debug("Param value is :" + value);

			if (i == keys.size() - 1) {
				sbPreStr = sbPreStr.append(key);
				sbPreStr = sbPreStr.append(AlipayConstant.EQUAL_SYMBL);
				sbPreStr = sbPreStr.append(value);
			} else {
				sbPreStr = sbPreStr.append(key);
				sbPreStr = sbPreStr.append(AlipayConstant.EQUAL_SYMBL);
				sbPreStr = sbPreStr.append(value);
				sbPreStr = sbPreStr.append(AlipayConstant.AMPERSAND_SYMBL);
			}
		}
		sbPreStr = sbPreStr.append(pPrivateKey);
		prestr = sbPreStr.toString();

		LogSupport.debug("Generated String is ::" + prestr );
		LogSupport.debug("Exiting from AlipayUtil getContent()");
		return prestr;
	}



}
