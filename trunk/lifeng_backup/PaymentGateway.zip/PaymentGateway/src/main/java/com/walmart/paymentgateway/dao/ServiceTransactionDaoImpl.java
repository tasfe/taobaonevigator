/**
 * 
 */
package com.walmart.paymentgateway.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.QueryParameter;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.model.TransactionEventEntity;

/**
 * @author sgopisetty
 *
 */
@Repository
public class ServiceTransactionDaoImpl extends GenericDaoImpl implements
		ServiceTransactionDao {

	/**
	 * 
	 */
	@Override
	public TransactionEventEntity creatTransactionEvent(
			TransactionEventEntity pTransactionEventEntity) {
		if(null==pTransactionEventEntity.getTransactionEventPk()){
		    LogSupport.debug("persisting the TransactionEventEntity...");
            this.create(pTransactionEventEntity);
		}else{
		    LogSupport.debug("merging the TransactionEventEntity...");
            em.merge(pTransactionEventEntity);
		}
		return pTransactionEventEntity;
    }

	/***
	 * 
	 */
	@Override
	public TransactionEntity createTransaction(TransactionEntity pTransactionEntity) {
		if(null == pTransactionEntity.getTransactionPk()){
		    LogSupport.debug("persisting the TransactionEntity...");
            this.create(pTransactionEntity);
		}else{
		    LogSupport.debug("merging the TransactionEntity...");
            em.merge(pTransactionEntity);
		}
		return pTransactionEntity;
    }

	

	/***
	 * 
	 */
	public TransactionEntity findTransaction(String pProperty, String pValue, String pQueryName) {
		
        final Map<String, Object> parameters = QueryParameter.with(pProperty, pValue).and("softDelete", "N").parameters();
		List<TransactionEntity> transactionList= this.findByNamedQuery(TransactionEntity.class, pQueryName, parameters);
		if (transactionList == null || transactionList.size() == 0) {
			LogSupport.debug("no TransactionEntity found with property"+ pProperty + "and value" + pValue );
		} else {
			LogSupport.debug("TransactionEntity found with property"+ pProperty + "and value" + pValue );	
		}
		if(transactionList.size()>0){
            return transactionList.iterator().next();
        }
        return null;
    }
	
	/***
	 * 
	 */
	public TransactionEntity findTransactionWithExtCorrelation(String pExtCorrelationId) {
		
        final Map<String, Object> parameters = QueryParameter.with("extCorrelationId", pExtCorrelationId).and("softDelete", "N").parameters();
		List<TransactionEntity> transactionList= this.findByNamedQuery(TransactionEntity.class, 
																		 TransactionEntity.BY_EXT_CORRELATION_ID, 
																		 parameters);
		if (transactionList == null || transactionList.size() == 0) {
			LogSupport.debug("no TransactionEntity found when ExtCorrelationId = " + pExtCorrelationId);
		} else {
			LogSupport.debug("TransactionEntity found when ExtCorrelationId = " + pExtCorrelationId);	
		}
		if(transactionList.size()>0){
            return transactionList.iterator().next();
        }
        return null;
    }
	public TransactionEntity findTransactionWithOrderDetails(String pOrderId,BigDecimal transactionAmt,String pExtCorrelationId,String pChannel,String pPaySrvCode) {

		final Map<String, Object> parameters = QueryParameter.with("extOrderId", pOrderId).and("amount", transactionAmt).and("extCorrelationId", pExtCorrelationId).and("name", pChannel).and("intPayCode", pPaySrvCode).and("softDelete", "N").parameters();
		List<TransactionEntity> transactionList= this.findByNamedQuery(TransactionEntity.class, 
																		 TransactionEntity.BY_PAYREQUEST, 
																		 parameters);
		if (transactionList == null || transactionList.size() == 0) {
			LogSupport.debug("no TransactionEntity found when ExtCorrelationId = " + pExtCorrelationId);
		} else {
			LogSupport.debug("TransactionEntity found when ExtCorrelationId = " + pExtCorrelationId);	
		}
		if(transactionList.size()>0){
            return transactionList.iterator().next();
        }
        return null;
    }

	@Override
	public TransactionEntity findTransactionDetailById(Long pId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TransactionEventEntity findTransactionEventDetail(String pStatus) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TransactionEventEntity findTransactionEventDetailById(Long pId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TransactionEventEntity> getAllTransactionEventByStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
