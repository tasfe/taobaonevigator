package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the SRV_PROVIDER_PAY_TYPE database table.
 * 
 */
@Entity
@Table(name="SRV_PROVIDER_PAY_TYPE")
public class SrvProviderPayTypeEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="SRV_PROVIDER_PAY_TYPE_PK_GENERATOR", sequenceName="SRV_PROVIDER_PAY_TYPE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SRV_PROVIDER_PAY_TYPE_PK_GENERATOR")
	@Column(name="SRV_PROVIDER_PAY_TYPE_PK")
	private Long srvProviderPayTypePk;

	private String description;

	private String name;

	//bi-directional many-to-one association to SrvProviderEntity
    @ManyToOne
	@JoinColumn(name="SRV_PROVIDER_FK")
	private SrvProviderEntity srvProvider;

	//bi-directional many-to-one association to SrvProviderPayTypeCodeEntity
	@OneToMany(mappedBy="srvProviderPayType",fetch=FetchType.EAGER)
	private Set<SrvProviderPayTypeCodeEntity> srvProviderPayTypeCodes;

    public SrvProviderPayTypeEntity() {
    }

	public Long getSrvProviderPayTypePk() {
		return this.srvProviderPayTypePk;
	}

	public void setSrvProviderPayTypePk(Long srvProviderPayTypePk) {
		this.srvProviderPayTypePk = srvProviderPayTypePk;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSoftDelete() {
		return this.softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	public SrvProviderEntity getSrvProvider() {
		return this.srvProvider;
	}

	public void setSrvProvider(SrvProviderEntity srvProviderEntity) {
		this.srvProvider = srvProviderEntity;
	}
	
	public Set<SrvProviderPayTypeCodeEntity> getSrvProviderPayTypeCodes() {
		return this.srvProviderPayTypeCodes;
	}

	public void setSrvProviderPayTypeCodes(Set<SrvProviderPayTypeCodeEntity> srvProviderPayTypeCodeEntities) {
		this.srvProviderPayTypeCodes = srvProviderPayTypeCodeEntities;
	}
	
}