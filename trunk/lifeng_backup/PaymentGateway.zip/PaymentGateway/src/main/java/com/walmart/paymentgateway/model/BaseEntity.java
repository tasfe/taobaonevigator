/**
 * 
 */
package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import com.walmart.paymentgateway.common.util.AuditListener;

/**
 * @author sgopisetty
 *
 */
@SuppressWarnings("serial")
@MappedSuperclass
@EntityListeners(AuditListener.class)
public abstract class BaseEntity implements Serializable {

	@Column(name = "created_by", updatable = false)
	protected String createdBy;

	@Column(name = "created_date", updatable = false)
	protected Timestamp createdDate;

	@Column(name = "last_modified_by")
	protected String lastModifiedBy;

	@Column(name = "last_modified_date")
	protected Timestamp lastModifiedDate;

	@Column(name = "soft_delete")
	protected String softDelete;

	@Version // for lock
	@Column(name = "version")
	private Integer version;

	/**
	 * @return Returns name of user or process that created this record
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return Returns date and time when record was created
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return Returns name of user or process which last updated the record.
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return Returns date and time when record was last updated.
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	public Integer getVersion() {
		return version;
	}

/*	@PrePersist
	public void prePersist() {
		setCreatedDate(new Timestamp(System.currentTimeMillis()));
		this.setCreatedBy("System");
		setSoftDelete("N"); //When inserting all records are active 
		setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		setLastModifiedBy("system");
	}

	@PreUpdate
	public void preUpdate() {
		setLastModifiedDate(new Timestamp(System.currentTimeMillis()));
		this.setLastModifiedBy("System");
		
	}

	@PreRemove
	public void preRemove() throws Exception {
		// TODO: Need to define better exception type here.
		throw new Exception("Hard Deletes of database records is not allowed.");
	}
*/	
	/**
	 * check if the entity has been soft deleted
	 * @return soft delete status
	 */
	public boolean isDeleted(){
		return "Y".equalsIgnoreCase(this.getSoftDelete());
	}

}
