package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the ALIPAY_REFUND_BATCH database table.
 * 
 */
@Entity
@Table(name="ALIPAY_REFUND_BATCH")
public class AlipayRefundBatchEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="ALIPAY_REFUND_BATCH_GENERATOR", sequenceName = "ALIPAY_REFUND_BATCH_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALIPAY_REFUND_BATCH_GENERATOR")
	@Column(name="ALIPAY_REFUND_BATCH_PK")
	private Long alipayRefundBatchPk;

	@Column(name="BATCH_NUM")
	private BigDecimal batchNum;

	@Column(name="ERROR_MESSAGE")
	private String errorMessage;

	@Column(name="IS_SUCCESS")
	private String isSuccess;

	@Column(name="NO_OF_RECORDS")
	private BigDecimal noOfRecords;

	//bi-directional many-to-one association to AlipayRefundBatchDetailEntity
	@OneToMany(mappedBy="alipayRefundBatch")
	private Set<AlipayRefundBatchDetailEntity> alipayRefundBatchDetails;

	//bi-directional many-to-one association to AlipayRefundBatchNotifyEntity
	@OneToMany(mappedBy="alipayRefundBatch")
	private Set<AlipayRefundBatchNotifyEntity> alipayRefundBatchNotifys;

    public AlipayRefundBatchEntity() {
    }

	public Long getAlipayRefundBatchPk() {
		return this.alipayRefundBatchPk;
	}

	public void setAlipayRefundBatchPk(Long alipayRefundBatchPk) {
		this.alipayRefundBatchPk = alipayRefundBatchPk;
	}

	public BigDecimal getBatchNum() {
		return this.batchNum;
	}

	public void setBatchNum(BigDecimal batchNum) {
		this.batchNum = batchNum;
	}

	public String getErrorMessage() {
		return this.errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getIsSuccess() {
		return this.isSuccess;
	}

	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}

	public BigDecimal getNoOfRecords() {
		return this.noOfRecords;
	}

	public void setNoOfRecords(BigDecimal noOfRecords) {
		this.noOfRecords = noOfRecords;
	}

	public Set<AlipayRefundBatchDetailEntity> getAlipayRefundBatchDetails() {
		return this.alipayRefundBatchDetails;
	}

	public void setAlipayRefundBatchDetails(Set<AlipayRefundBatchDetailEntity> alipayRefundBatchDetailEntities) {
		this.alipayRefundBatchDetails = alipayRefundBatchDetailEntities;
	}
	
	public Set<AlipayRefundBatchNotifyEntity> getAlipayRefundBatchNotifies() {
		return this.alipayRefundBatchNotifys;
	}

	public void setAlipayRefundBatchNotifies(Set<AlipayRefundBatchNotifyEntity> alipayRefundBatchNotifyEntities) {
		this.alipayRefundBatchNotifys = alipayRefundBatchNotifyEntities;
	}
	
}