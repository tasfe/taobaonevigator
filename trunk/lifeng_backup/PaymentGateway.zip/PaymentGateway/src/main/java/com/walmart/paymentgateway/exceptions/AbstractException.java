package com.walmart.paymentgateway.exceptions;

public abstract class AbstractException extends Exception {
	
	private static final long serialVersionUID = 7537694340408619777L;
	private ErrorCodeEnum errorCodeEnum;

	public AbstractException(ErrorCodeEnum errorCodeEnum) {
		super(errorCodeEnum.getMsg());
		this.errorCodeEnum = errorCodeEnum;
	}

	public AbstractException(ErrorCodeEnum errorCodeEnum, Throwable cause) {
		super(cause);
		this.errorCodeEnum = errorCodeEnum;
	}

	public int getErrorCode() {
		return errorCodeEnum.getErrorCode();
	}

	public String getMsg() {
		return errorCodeEnum.getMsg();
	}

	public String getFullMsg() {
		if (errorCodeEnum != null && errorCodeEnum.getMsg() != null) {
			String errorMsg = errorCodeEnum.getErrorCode() + " - "
					+ errorCodeEnum.getMsg();
			if (getCause() != null)
				return errorMsg + " - " + getCause().getMessage();
			return errorMsg;
		}
		return null;
	}

	public ErrorCodeEnum getErrorCodeEnum() {
		return errorCodeEnum;
	}

	public void setErrorCodeEnum(ErrorCodeEnum errorCodeEnum) {
		this.errorCodeEnum = errorCodeEnum;
	}

}
