/**
 * 
 */
package com.walmart.paymentgateway.dao;

import com.walmart.paymentgateway.model.AccountEntity;

/**
 * @author sgopisetty
 *
 */
public interface AccountDao extends GenericDao {

	/**
	 * 
	 * @param pAccountEntity
	 */
	public AccountEntity createAccount(AccountEntity pAccountEntity);
	
	/**
	 * 
	 * @param pCustomerId
	 * @return
	 */
	public AccountEntity findAccountByName(String pCustomerId);
	
	/**
	 * 
	 * @param pId
	 * @return
	 */
	public AccountEntity findAccountById(Long pId);

}
