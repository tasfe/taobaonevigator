/**
 * 
 */
package com.walmart.paymentgateway.processor;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.builder.RefundRequestBuilder;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.service.domain.RefundRequest;
import com.walmart.paymentgateway.service.domain.RefundTransactionRequest;
import com.walmart.paymentgateway.validator.PaymentRequestValidator;

/**
 * @author sgopisetty
 *
 */
@Component
public class ServiceManager {

	@Autowired
	private PaymentRequestValidator paymentRequestValidator;
	
	@Autowired
	private RefundRequestBuilder refundRequestBuilder;


	/***
	 * 
	 * @param srvPayMethodInfo
	 * @return
	 */
	/*public PaymentProcessor getProcessor(String pProviderName){
		//String providerCode = ServiceProviderHelper.getProvider(payCode);
		return PaymentProcessorFactory.getProcessorInstance(pProviderName);
	}*/

	/***
	 * 
	 * @param pSrvCode
	 * @param pType
	 * @return
	 */
	public String getServiceProvider(String pSrvCode, String pType) {

		return paymentRequestValidator.getServiceProviderInfo(pSrvCode, pType);
	}

	/***
	 * 
	 * @param transactionList
	 * @param ReturnReason
	 * @return
	 */
	public RefundRequest createRefundRequest(List<TransactionEntity> transactionList, String ReturnReason, String pOrigin) {
		LogSupport.debug("inside ServiceManager.createRefundRequest....");
		LogSupport.debug("Creating refund request from origin::"+ pOrigin);
		refundRequestBuilder = new RefundRequestBuilder();
		String orderId = null;
		BigDecimal totalAmount = null;
		String intercorrelationId = null;
		RefundTransactionRequest refundTransRequest = null;
		RefundRequest refundRequest = refundRequestBuilder.getRefundRequest();
		if (!transactionList.isEmpty() && transactionList.size() > 0 ) {
			for (TransactionEntity transactionEntity : transactionList) {
				LogSupport.debug("Refund Request for OrderId::" +orderId);
				LogSupport.debug("Refund Request for TransactionId::" + intercorrelationId);
				
				orderId = transactionEntity.getOrderInfo().getExtOrderId();
				totalAmount = transactionEntity.getAmount().add(totalAmount);
				intercorrelationId = transactionEntity.getIntCorrelationId();
				//originName = transactionEntity.getRequestOriginLk().getName();
				refundTransRequest = refundRequestBuilder.createNewRefundTransactionRequest();
				refundTransRequest.setTransactionId(intercorrelationId);
				refundRequestBuilder.addToRefundRequest(refundTransRequest);
			}
			LogSupport.debug("Refund Request for Amount::" + totalAmount);
			refundRequest.setAmount(totalAmount);
			refundRequest.setOrderId(orderId);
			refundRequest.setOriginator(pOrigin);
			refundRequest.setReason(ReturnReason);
		} else {
			LogSupport.info("Refund Request Cannot be null");
		}
		
		
		return refundRequestBuilder.getRefundRequest();

	}

}
