package com.walmart.paymentgateway.dao;


import java.util.Collection;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.model.AccountEntity;
import com.walmart.paymentgateway.model.ChannelLkEntity;
import com.walmart.paymentgateway.model.DomainLkEntity;
import com.walmart.paymentgateway.model.OrderInfoEntity;
import com.walmart.paymentgateway.model.RequestOriginLkEntity;
import com.walmart.paymentgateway.model.SrvProviderPayTypeCodeEntity;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.model.TransactionEventEntity;
import com.walmart.paymentgateway.model.TransactionEventStatusEntity;
import com.walmart.paymentgateway.model.TransactionStatusEntity;
import com.walmart.paymentgateway.model.TransactionTypeLkEntity;

/***
 * 
 * @author enduser
 *
 */
@Component("transactionalTools")
public class DaoManager {

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private OrderInfoDao orderInfoDao;

	@Autowired
	private ServiceTransactionDao serviceTransactionDao;

	@Autowired
	private StaticLookUpDao staticLookUpDao;

	/***
	 * 
	 * @param pAccEntity
	 * @return
	 */
	public TransactionEntity createOrUpateTransaction(TransactionEntity pTransactionEntity,String pType, String pStatus) {
		TransactionStatusEntity statusEntity = null;
		TransactionTypeLkEntity transactionTypeLkEntity = null;
		if (!StringUtils.isEmpty(pStatus)) {
			statusEntity =  findTransactionStatus(pStatus);
			pTransactionEntity.setTransactionStatus(statusEntity);
		}
		if (!StringUtils.isEmpty(pType)) {
			transactionTypeLkEntity =  findTransactionType(pType);
			pTransactionEntity.setTransactionTypeLk(transactionTypeLkEntity);
		}
		return serviceTransactionDao.createTransaction(pTransactionEntity);
	}

	/***
	 * 
	 * @param pAccEntity
	 * @return
	 */
	public TransactionEventEntity createTransactionEvent(TransactionEventEntity pTransEventEntity, String pStatus) {
		boolean isError = false;
		TransactionEventEntity newTransactionEventItem = null;
		TransactionEventStatusEntity transEventStatus = null;
		if (null == pTransEventEntity) {
			//if null throw exception
		}
		if (!isError) {
			// check for null validation for all required fields
			//throw exception
		}

		if (!isError) {
			if (!StringUtils.isBlank(pStatus)) {
				transEventStatus = staticLookUpDao.findTransactionEventStatusByName(pStatus);
				if (null != transEventStatus) {
					pTransEventEntity.setTransactionEventStatus(transEventStatus);
				}

			}
			newTransactionEventItem = serviceTransactionDao.creatTransactionEvent(pTransEventEntity);
		}

		return newTransactionEventItem;
	}

	public AccountEntity createAccount(AccountEntity pAccountEntity) {
		boolean isError = false;
		AccountEntity newAccountItem = null;
		if (null == pAccountEntity) {
			//if null throw exception
		}
		if (!isError) {
			// check for null validation for all required fields
			//throw exception
		}

		if (!isError) {
			newAccountItem = accountDao.createAccount(pAccountEntity);
		}

		return newAccountItem;
	}

	/***
	 * 
	 * @param pOrderEntity
	 * @return
	 * @throws Exception
	 */
	public OrderInfoEntity createOrder(OrderInfoEntity pOrderEntity)  {
		boolean isError = false;
		OrderInfoEntity newOrderItem = null;
		if (null == pOrderEntity) {
			//if null throw exception
		}
		if (!isError) {
			// do not null validation for all required fields
			//throw exception
		}

		if (!isError) {
			newOrderItem = orderInfoDao.createOrderInfo(pOrderEntity);
		}

		return newOrderItem;
	}

	/***
	 * 
	 * @param pServicePayMethodCode
	 * @return
	 */
	public SrvProviderPayTypeCodeEntity findSrvProviderInfo(String pServicePayMethodCode) {
		return staticLookUpDao.findServicePayMethodCode(pServicePayMethodCode);
	}

	/***
	 * 
	 * @param pInterCorrelationId
	 * @return
	 */
	public String findSrvProviderForTransaction(TransactionEntity pTransactionEntity) {
		String providerName = null;
		SrvProviderPayTypeCodeEntity srvProviderPayTypeCodeEntity  = null; ;
		if ((null != pTransactionEntity) && (null != pTransactionEntity.getSrvProviderPayTypeCode())) {
			srvProviderPayTypeCodeEntity = pTransactionEntity.getSrvProviderPayTypeCode();
			if (null != srvProviderPayTypeCodeEntity.getSrvProviderPayType()) {
				return srvProviderPayTypeCodeEntity.getSrvProviderPayType().getSrvProvider().getName();
			}
		}

		return providerName;
	}

	/***
	 * 
	 * @param pStatusName
	 * @return
	 */
	public TransactionStatusEntity findTransactionStatus(String pStatusName) {
		return staticLookUpDao.findTransactionStatus(pStatusName);
	}

	/***
	 * 
	 * @param pIntCorrelationId
	 * @return
	 */
	public TransactionEntity findTransactionWithIntCorrelationId(String pIntCorrelationId ) {
		LogSupport.debug("Inside TransactionalTools.findTransactionWithIntCorrelationId");
		LogSupport.debug("searching....for pIntCorrelationId::" + pIntCorrelationId);
		String propertyName = "intCorrelationId";
		TransactionEntity transactionEntity = null;
		String QueryName = TransactionEntity.BY_INT_CORRELATION_ID;
		if (!StringUtils.isBlank(pIntCorrelationId)) {
			transactionEntity = serviceTransactionDao.findTransaction(propertyName, pIntCorrelationId, QueryName);
		}
		if (null != transactionEntity) {
			LogSupport.debug("Transaction found for intercorrelationId::" + pIntCorrelationId );
			LogSupport.debug("Transaction Id::"+ transactionEntity.getTransactionPk());
		} else {
			LogSupport.debug("Transaction not found for intercorrelationId::" + pIntCorrelationId);
		}
		LogSupport.debug("return from TransactionalTools.findTransactionWithIntCorrelationId with ::" + transactionEntity);
		return transactionEntity;
	}


	/***
	 * 
	 * @param pIntCorrelationId
	 * @return
	 */
	public TransactionEntity findTransactionWithExtCorrelationId(String pExtCorrelationId ) {

		String propertyName = "extCorrelationId";
		String QueryName = TransactionEntity.BY_EXT_CORRELATION_ID;
		if (!StringUtils.isBlank(pExtCorrelationId)) {
			return serviceTransactionDao.findTransaction(propertyName, pExtCorrelationId, QueryName);
		}

		return null;
	}

	/**
	 * 
	 * @param pOrderId
	 * @param pIntercorrelationId
	 * @return
	 */
	public TransactionEntity findTransactionForOrderId(String pOrderId, String pIntercorrelationId) {
		LogSupport.debug("Inside TransactionalTools.findTransactionForOrderId");
		LogSupport.debug("searching....with pOrderId::"+pOrderId+"::and pIntCorrelationId::" + pIntercorrelationId);

		if (!StringUtils.isEmpty(pOrderId) && !StringUtils.isEmpty(pIntercorrelationId)) {
			OrderInfoEntity orderInfoEntity = null;
			orderInfoEntity = orderInfoDao.findOrderInfo(pOrderId);
			Set<TransactionEntity> transactions = orderInfoEntity.getTransactions();
			if (!CollectionUtils.isEmpty(transactions)) {
				for (TransactionEntity transactionEntity2 : transactions) {
					if (transactionEntity2.getIntCorrelationId().equalsIgnoreCase(pIntercorrelationId)) {
						LogSupport.debug("Transaction found for the order::" + transactionEntity2.getTransactionPk());
						return transactionEntity2;
					}
				}
			}
		}
		LogSupport.debug("return from TransactionalTools.findTransactionForOrderId with null");
		return null;
	}


	/***
	 * 
	 * @param pIntCorrelationId
	 * @return
	 */
	public TransactionEntity findTransactionForOrderId(String pOrderId ) {
		LogSupport.debug("TransactionalTools.findTransactionWithOrderId for orderId::" + pOrderId );
		OrderInfoEntity orderInfoEntity = null;
		TransactionEntity transactionEntity = null;
		orderInfoEntity = orderInfoDao.findOrderInfo(pOrderId);
		LogSupport.debug("orderInfoEntity for orderId::" + orderInfoEntity );
		if (null != orderInfoEntity) {
			Collection<TransactionEntity> transSet = orderInfoEntity.getTransactions();
			if (!transSet.isEmpty() && transSet.iterator().hasNext()) {
				//LogSupport.debug("Transaction for orderId::" + transSet.iterator().next().getIntCorrelationId());
				return transSet.iterator().next();
			}	
		}

		return transactionEntity;
	}

	/***
	 * 
	 * @param pStatus
	 * @return
	 */
	public TransactionEventStatusEntity findTransactionEventStatus(String pStatus) {

		return staticLookUpDao.findTransactionEventStatusByName(pStatus);
	}


	/***
	 * 
	 * @param pCustomerId
	 * @return
	 */
	public AccountEntity findAccount(String pCustomerId) {
		return accountDao.findAccountByName(pCustomerId);

	}

	/***
	 * 
	 * @param pOrderId
	 * @return
	 */
	public OrderInfoEntity findOrder(String pOrderId) {
		return orderInfoDao.findOrderInfo(pOrderId);

	}

	/***
	 * 
	 * @param pDomainName
	 * @return
	 */
	public DomainLkEntity findDomain(String pDomainName) {
		return staticLookUpDao.findDomainInfoByName(pDomainName);

	}

	/***
	 * 
	 * @param pTenantName
	 * @return
	 */
	public ChannelLkEntity findChannel(String pTenantName) {
		return staticLookUpDao.findChannelInfoByName(pTenantName);
	}

	/***
	 * 
	 * @param pId
	 * @return
	 */
	public ChannelLkEntity findChannel(Long pId) {
		return staticLookUpDao.findChannelInfoById(pId);
	}

	/***
	 * 
	 * @param pRequestOrigin
	 * @return
	 */
	public RequestOriginLkEntity findRequestOrigin(String pRequestOrigin) {
		return staticLookUpDao.findRequestOriginInfoByName(pRequestOrigin);
	}

	/***
	 * 
	 * @param pTypeName
	 * @return
	 */
	public TransactionTypeLkEntity findTransactionType(String pTypeName) {
		return staticLookUpDao.findTransactionTypeByName(pTypeName);
	}



}
