package com.walmart.paymentgateway.service.provider.alipay;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.TransactionConstant;
import com.walmart.paymentgateway.common.util.UriToMapUtil;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.service.domain.Error;
import com.walmart.paymentgateway.service.domain.PaymentStatus;
import com.walmart.paymentgateway.service.util.ReasonCode;


@Component("alipayPaymentNotification")
public class AlipayNotification implements TransactionConstant, AlipayConstant {

	enum AlipayResponseParam {body, buyer_email, buyer_id, exterface,is_success,notify_id,
		notify_time,notify_type,out_trade_no,payment_type,seller_email,seller_id
		,subject,total_fee,trade_no,trade_status,sign,sign_type}

	@Autowired @Qualifier("alipayTransactionTools")
	private AlipayDaoManager alipayTransactionalTools;
	@Autowired @Qualifier("alipayServiceTransLoger")
	private AlipayTransactionLogger alipaylogger;
	
	private Map<String, String> paramMap;
	@Autowired
	UriToMapUtil  uriToMapUtil;

	public void setParamMap(final Map<String, String> map){

		this.paramMap = map;
	}
	public Map<String, String> getParamMap() {
		return paramMap;
	}
	public String getValue(String key){

		return paramMap.get(key);
	}
	public void processPaymentNotification(String paymentNotificationMessage, PaymentStatus pPaymentStatus) {

		LogSupport.debug("Inside AlipayNotification.processPaymentNotification... ");
		TransactionEntity transactionItem = null;
		String out_tradNo = null;
		String trade_no = null;
		String trade_status = null;
		//String orderId = null;
		String buyerEmail = null;
		String buyerId =  null;
		BigDecimal transactedAmt = null;
		String transactioneventStatus = EVENT_ERROR;
		try {
			paramMap = uriToMapUtil.convertUriToMap(paymentNotificationMessage,AlipayConstant.UTF8);
			out_tradNo = getValue("out_trade_no");
			trade_status = getValue("trade_status");
			buyerEmail = getValue("buyer_email");
			buyerId = getValue("buyer_id");
			transactedAmt = AlipayUtil.toBigDecimal(getValue("total_fee"));
			trade_no = getValue("trade_no");
			if (!alipayTransactionalTools.isTradeExist(trade_no)) {
				pPaymentStatus.setBuyerEmail(buyerEmail);
				pPaymentStatus.setBuyerId(buyerId);
				pPaymentStatus.setOrderId(out_tradNo);
				pPaymentStatus.setTransactedAmount(transactedAmt);
				
				//commenting since for temporarily out_tradeNo is orderId for I8 relase
				//pPaymentStatus.setTransactionId(out_tradNo);
				//transactionItem = alipayTransactionalTools.findTransactionWithIntCorrelationId(out_tradNo);
				transactionItem = alipayTransactionalTools.findTransactionForOrderId(out_tradNo);
				if (null != transactionItem) {
					//orderId = transactionItem.getOrderInfo().getExtOrderId();
					LogSupport.debug("TransactionId :: " + transactionItem.getIntCorrelationId());
					String intercorrelationId = transactionItem.getIntCorrelationId();
					pPaymentStatus.setOrderId(out_tradNo);
					pPaymentStatus.setTransactionId(intercorrelationId);
					
					LogSupport.debug("::Notification is logged into Notification and pay notification::");
					LogSupport.debug("Alipay Trade Status for out_trade_no"+ out_tradNo+ "is" + trade_status );
					if (trade_status.equalsIgnoreCase(TRADE_FINISHED) || trade_status.equalsIgnoreCase(TRADE_SUCCESS)) {
						transactioneventStatus = EVENT_PAYMENT_NOTIFICATION_RECEIVED ;
						pPaymentStatus.setTransactionStatus(ReasonCode.SUCCESS);
						pPaymentStatus.setTransactionStatusCode(ReasonCode.COMPLETE);
						//Step 1 Log Data to Alipay Notification Table
						alipaylogger.logPayNotification(paramMap);
						alipayTransactionalTools.createOrUpateTransaction(transactionItem,null, STATUS_COMPLETE);

					} else if (trade_status.equalsIgnoreCase(TRADE_CLOSED)) {
						transactioneventStatus = EVENT_CANCELLED;
						pPaymentStatus.setTransactionStatus(ReasonCode.SUCCESS);
						pPaymentStatus.setTransactionStatusCode(ReasonCode.CANCEL);
						//Step 1 Log Data to Alipay Notification Table
						alipaylogger.logPayNotification(paramMap);
						alipayTransactionalTools.createOrUpateTransaction(transactionItem, null, STATUS_CANCEL);
					} else {
						LogSupport.error("Unknown trade status to processPaymentNotification");
						transactioneventStatus = EVENT_ERROR;
						pPaymentStatus.setTransactionStatus(ReasonCode.FAIL);
						pPaymentStatus.setTransactionStatusCode(ReasonCode.FAIL);
					}
					
					alipaylogger.logTransactionEvent(transactionItem, transactioneventStatus, trade_status);

				} else {
					LogSupport.debug("No Transaction is found for out trade number ::" + out_tradNo);
					buildErrorPaymentStatus(pPaymentStatus, ReasonCode.INVALID_TRANSACTION_ID, ReasonCode.TRANSACTION_NOT_FOUND);
				}
			} else {
				LogSupport.info("Duplicate Trade number for out_trade::" + out_tradNo);
			}
			

		} catch (Exception e) {
			 e.printStackTrace();
			buildErrorPaymentStatus(pPaymentStatus,ReasonCode.ERROR, "exception Occured while processing");
			LogSupport.error("Exception occured while processPaymentNotification ::" + e);
		}


		LogSupport.debug("End processPaymentNotification () ");

	}
	
	/***
	 * 
	 * @param paymentStatus
	 * @param pCode
	 * @param pDescription
	 */
	private void buildErrorPaymentStatus(PaymentStatus paymentStatus , String  pCode, String pDescription) {
		LogSupport.debug("inside AlipayNotification.buildErrorPaymentStatus..." );
		LogSupport.debug("buildErrorPaymentStatus :: Error Code ::" + pCode);
		LogSupport.debug("buildErrorPaymentStatus :: Error Description ::" +pDescription);
		Error error = new Error();
		error.setCode(pCode);
		error.setDescription(pDescription);
		paymentStatus.setError(error);
		paymentStatus.setTransactionStatus(ReasonCode.FAIL);
		paymentStatus.setTransactionStatusCode(ReasonCode.FAIL);
		LogSupport.debug("Exist from AlipayNotification.buildErrorPaymentStatus..." );
	}


}
