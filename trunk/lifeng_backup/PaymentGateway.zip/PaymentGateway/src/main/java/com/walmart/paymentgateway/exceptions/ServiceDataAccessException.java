package com.walmart.paymentgateway.exceptions;

public class ServiceDataAccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	public ServiceDataAccessException() {
		super();
	}

	public ServiceDataAccessException(String msg) {
		super(msg);
	}

	public ServiceDataAccessException(Throwable cause) {
		super(cause);
	}

	public ServiceDataAccessException(String msg, Throwable cause) {
		super(msg, cause);
	}


}
