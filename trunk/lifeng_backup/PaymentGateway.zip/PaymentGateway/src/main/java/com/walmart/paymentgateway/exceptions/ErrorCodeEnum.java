package com.walmart.paymentgateway.exceptions;

public enum ErrorCodeEnum {
	
	
	// Database exceptions should start from 20001...2nnnn
	GENERIC_DATABASE_EXCEPTION(20001,"Generic database exception"),
	HARD_DELETE_NOT_ALLOWED (20002,"Hard Delete is not allowed"),
	CANNOT_CREATE_RECORD (20003,"Cannot create record in database"),
	CANNOT_UPDATE_RECORD (20004,"Cannot update record in database"),
	CANNOT_FETCH_RECORD (20005,"Cannot fetch record from database"),
	CANNOT_DELETE_RECORD (20006,"Cannot delete record from database"),
	CANNOT_RECORD_FETCH_BY_NAMED_QUERY (20007,"Cannot fetch record from database with named query"),
	DUPLICATE_RECORD (20008,"Duplicate record found in database"),
	NO_RECORD (20009,"No records found in database"),
	
	// System exceptions should start from 30001...3nnnn
	GENERIC_SYSTEM_EXCEPTION(30001,"Generic system exception"),
	XML_PARSE_ENCODING_EXCEPTION(30002,"Failed to parse xml due to encoding"),
	XML_MARSHALL_UNMARSHALL_EXCEPTION(30003,"Failed to marshal/unmarshal xml");
	
	
	private int errorCode;
	private String msg;

	private ErrorCodeEnum(int errorCode, String msg) {
		this.errorCode = errorCode;
		this.msg = msg;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
