package com.walmart.paymentgateway.exceptions;

public class PaymentServiceException extends AbstractException {

	private static final long serialVersionUID = -4435411327128449872L;

	public PaymentServiceException(ErrorCodeEnum errorCodeEnum) {
		super(errorCodeEnum);
	}
	public PaymentServiceException(ErrorCodeEnum errorCodeEnum,Throwable cause) {
		super(errorCodeEnum,cause);
	}
}
