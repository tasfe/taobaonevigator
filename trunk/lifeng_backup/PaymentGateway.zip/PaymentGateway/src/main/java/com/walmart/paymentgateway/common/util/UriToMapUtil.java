package com.walmart.paymentgateway.common.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.stereotype.Component;
/**
 * 
 * This class is responsible to converting uri( query string from URL) data to Map.
 * If string contains CDATA element it will be removed.  
 *
 */
@Component("uriToMapUtil")
public class UriToMapUtil {

	
	static String QUESTION_MARK_SYMBL ="?";
	static String AMPERSAND__EQUAL_SYMBL="&=";
	static String SIGN="sign";
	static String SIGNTYPE="signtype";
	/**
	 * 
	 * @param uri
	 * @param uri_charset
	 * @return Map<String, String>
	 */
	public Map<String, String> convertUriToMap(String uri,String uri_charset) {
		LogSupport.debug("Start UriToMapUtil convertUriToMap()");
		LogSupport.debug(" uri : " + uri);
		LogSupport.debug(" uri_charset : " + uri_charset);

		Map<String, String> map = new HashMap<String, String>();
		String stringUri = null;
		if(uri!= null){
			uri = stripCDATA(uri);
		}
		if(uri!= null && uri.contains(QUESTION_MARK_SYMBL)){
			StringTokenizer stTokenizer = new StringTokenizer(uri, QUESTION_MARK_SYMBL);
			LogSupport.debug("stTokenizer: " + stTokenizer.countTokens());
			//Get last token
			while(stTokenizer.hasMoreTokens()) {
				stringUri = stTokenizer.nextToken();
				LogSupport.debug("Useful Token ::" + stringUri);
			}
		} else {
			stringUri = uri;
		}
		if(stringUri != null){
			
			StringTokenizer stringTokenizer = new StringTokenizer(stringUri, AMPERSAND__EQUAL_SYMBL);
			while(stringTokenizer.hasMoreTokens()) {
				String paramName = stringTokenizer.nextToken();
				String paramValue = stringTokenizer.nextToken();
				try {
					String decodeParamValue = URLDecoder.decode(paramValue, uri_charset);
					map.put(paramName, decodeParamValue);
					LogSupport.debug("Param name is ::" + paramName);
					LogSupport.debug("Param value is :::" + paramValue);
					LogSupport.debug("Decoded Param value is  :::" + decodeParamValue);
				} catch (UnsupportedEncodingException pUnsupportedEncodingException) {
					LogSupport.error("Unsupported encoding Error occur in SignatureVerification getSign ",
							pUnsupportedEncodingException);
				}
			}
		}
		
		return map;
	}
	private  String stripCDATA(String str) {
		str = str.trim();
	    if (str.startsWith("<![CDATA[")) {
	      str = str.substring(9);
	      int i = str.indexOf("]]>");
	      if (i == -1) {
	        throw new IllegalStateException(
	            "argument starts with <![CDATA[ but cannot find pairing ]]>");
	      }
	      str = str.substring(0, i);
	    }
	    return str;
	  }


}
