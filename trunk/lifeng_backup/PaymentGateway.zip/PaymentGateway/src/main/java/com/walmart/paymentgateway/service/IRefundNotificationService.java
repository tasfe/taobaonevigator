package com.walmart.paymentgateway.service;

import com.walmart.paymentgateway.service.domain.RefundNotification;
import com.walmart.paymentgateway.service.domain.RefundResponse;
/**
 * Interface for Refund Notification Service handling.
 * @author Raju Thomas
 *
 */
public interface IRefundNotificationService {

	public RefundResponse handleRefundNotification(RefundNotification notification);

}
