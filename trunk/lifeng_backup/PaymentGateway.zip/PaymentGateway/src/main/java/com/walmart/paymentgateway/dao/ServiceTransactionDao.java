package com.walmart.paymentgateway.dao;

import java.math.BigDecimal;
import java.util.List;

import com.walmart.paymentgateway.exceptions.ServiceDataAccessException;
import com.walmart.paymentgateway.model.TransactionEntity;
import com.walmart.paymentgateway.model.TransactionEventEntity;

/***
 * 
 * @author sgopisetty
 *
 */
public interface ServiceTransactionDao extends GenericDao {
	
	public TransactionEntity createTransaction(TransactionEntity pTransactionEntity) throws ServiceDataAccessException;
	
	public TransactionEntity findTransactionDetailById(Long pId);

	public TransactionEntity findTransaction(String pProperty, String pValue, String pQueryName);
	
	public TransactionEntity findTransactionWithExtCorrelation(String pExtCorrelationId);
	
	
	
	public TransactionEventEntity creatTransactionEvent(TransactionEventEntity pTransactionEventEntity)throws ServiceDataAccessException;
	
	public TransactionEventEntity findTransactionEventDetailById(Long pId);
	
	public TransactionEventEntity findTransactionEventDetail(String pStatus);
	
	public List<TransactionEventEntity> getAllTransactionEventByStatus();
	
	public TransactionEntity findTransactionWithOrderDetails(String pOrderId,BigDecimal transactionAmt,String pExtCorrelationId,String pChannel,String pPaySrvCode);

}
