package com.walmart.paymentgateway.service.provider.alipay;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.walmart.paymentgateway.model.AlipayAccountConfigEntity;
import com.walmart.paymentgateway.model.ProviderPayMethodInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.walmart.paymentgateway.common.util.LogSupport;
import com.walmart.paymentgateway.common.util.PayMethodHolder;
import com.walmart.paymentgateway.exceptions.ServiceRunTimeException;
import com.walmart.paymentgateway.service.domain.PayUrlRequest;
import org.springframework.util.StringUtils;
/***
 * 
 * This class is responsible for creating alipay specific service URLs
 *
 */
@Component("alipayServiceManager")
public class AlipayServiceManager {
	
	
	@Autowired
	private AlipayConfigHolder alipayConfigHolder;
	private AlipayAccountConfigEntity alipayConfig = null;
	@Autowired
	private PayMethodHolder payMethodHolder;
	/**
	 * Create ALIPAY payment interface URL
	 * @param pOrderId
	 * @param request
	 * @param pTransactionId
	 * @return
	 */
	public String createPaymentURL(String pOrderId, PayUrlRequest request, String pTransactionId)  {
		
		
		LogSupport.debug("Start AlipayServiceManager createPaymentURL() ");
		LogSupport.debug("TransactionId "+pTransactionId);

		String paymentURL = null;
		alipayConfig = alipayConfigHolder.getAlipayConfigParam(request.getChannel());
		LogSupport.debug(" alipayConfig "+alipayConfig);

		String input_charset = alipayConfig.getInputCharSet();
		String show_url = alipayConfig.getShowUrl(); 
		String body=alipayConfig.getBody() + "( "+pOrderId+" )";
		String payment_type= alipayConfig.getPaymentType();
		String seller_email= alipayConfig.getSellerEmailId();
		String subject= alipayConfig.getSubject() + "( "+pOrderId+" )";
		String notify_url= alipayConfig.getNotifyUrl(); 
		String partner=  alipayConfig.getPatnerId();

		String fee  = request.getAmount().toString();
		String return_url= request.getReturnUrl();
		// This code has been modified to support estore request for getting orderid from return URL. 
		return_url =return_url+"?orderId="+pOrderId; 
		
		LogSupport.debug(" body "+body);
		LogSupport.debug(" subject "+subject);
		//LogSupport.debug(" out_trade_no "+pTransactionId);
		LogSupport.debug(" out_trade_no "+pOrderId);
		LogSupport.debug(" total_fee "+fee);
		LogSupport.debug(" return_url "+return_url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("service", AlipayConstant.ALIPAY_PAYMENT_SERVICE_INTERFACE);
		params.put("partner", partner);
		params.put("subject", subject);
		params.put("body", body);
		params.put("out_trade_no", pTransactionId);
		//params.put("out_trade_no", pOrderId);
		params.put("total_fee", fee);
		if(StringUtils.hasText(show_url)){
			params.put("show_url", show_url);
		}
		params.put("payment_type",payment_type);
		params.put("seller_email", seller_email);
		
		if(StringUtils.hasText(return_url)){
			params.put("return_url", return_url);
		}
		params.put("notify_url", notify_url);
		params.put("_input_charset", input_charset);

		
		ProviderPayMethodInfo providerPayMethodInfo = payMethodHolder.getProviderPayMethodInfo(request.getPayURLServiceCode());

		LogSupport.debug("PaymentCode "+providerPayMethodInfo.getPaymentCode());
		LogSupport.debug("PaymentMethod "+providerPayMethodInfo.getPaymentMethod());
		LogSupport.debug("ProviderCode "+providerPayMethodInfo.getProviderCode());

		String 	paymethod = providerPayMethodInfo.getPaymentMethod();

		if(paymethod != null && !paymethod.trim().equalsIgnoreCase("")){

			if (paymethod.equals(AlipayConstant.DIRECTPAY)){
				params.put("paymethod", "directPay");
			}
			else if (paymethod.equals(AlipayConstant.BANKPAY)){
				params.put("paymethod", "bankPay");
				params.put("defaultbank", providerPayMethodInfo.getPaymentCode());
			}
			else if (paymethod.equals("cartoon")){
				params.put("paymethod", "cartoon");
			}
			else{
				
				throw new ServiceRunTimeException("Payment Method is not supported by Alipay");
			}
		}
		else{
			
			throw new ServiceRunTimeException("Payment Method could not be determined. Could be a configuration Issue ");
		}
		
		paymentURL =  createServiceURL(params);
		LogSupport.debug("ALIPAY PAYMENT URL :"+paymentURL);
		LogSupport.debug("End AlipayServiceManager createPaymentURL() ");
		return paymentURL;
	}
	
	
	/**
	 * Create ALIPAY cancel interface URL
	 * @param pOutTradeNo
	 * @return
	 */
	public String createCancelURL(String pOutTradeNo){		

		LogSupport.debug("Start AlipayServiceManager createCancelTrade()");
		LogSupport.debug("OutTrade Number (TransactionID) "+pOutTradeNo);
		String l_sChannel = "ONLINE.ESTORE";
		alipayConfig = alipayConfigHolder.getAlipayConfigParam(l_sChannel);
		LogSupport.debug(" alipayConfig "+alipayConfig);
		
		String l_sInput_charset = alipayConfig.getInputCharSet();
		String l_sPartner=  alipayConfig.getPatnerId();
		String l_sService = AlipayConstant.ALIPAY_CANCEL_SERVICE_INTERFACE;

		LogSupport.debug("pOutTrandNo ::: " + pOutTradeNo);
		LogSupport.debug("l_sService ::: " + l_sService);
		LogSupport.debug("l_sPartner ::: " + l_sPartner);
		LogSupport.debug("l_sInput_charset ::: " + l_sInput_charset);

		Map<String, String> params = new HashMap<String, String>();
		params.put("_input_charset", l_sInput_charset);
		params.put("service", l_sService);
		params.put("partner", l_sPartner);
		params.put("out_order_no", pOutTradeNo);
		
		LogSupport.debug("End AlipayServiceManager createCancelTrade()");
		return createServiceURL(params);
	}
	/*
	private CancelTransactionResponse createCancelResponse(boolean is_success, String pErrorMessage, String pInterCorrelationId) {
		
		CancelTransactionResponse cancelTransactionResponse = new CancelTransactionResponse();
		cancelTransactionResponse.setTransactionId(pInterCorrelationId);		
			if(is_success){
				cancelTransactionResponse.setTransactionStatus(ReasonCode.SUCCESS);
				cancelTransactionResponse.setTransactionStatusCode(ReasonCode.CANCEL);	
			} else if (StringUtils.hasText(pErrorMessage)){
				cancelTransactionResponse.setTransactionStatus(ReasonCode.NOT_COMPLETED);
				cancelTransactionResponse.setTransactionStatusCode(pErrorMessage);				
			}

		return cancelTransactionResponse; 

	}
	*/

	/**
	 * 
	 */
	public void createQueryURL(String pOrderNo) {
		
		/*

		//LogSupport.debug("Entering into AlipayQueryProcessor createQueryURL method");
		String mTradeQueryURL  = null;

		//Payment gateway URL
		String paygateway = AlipayConfig.paygateway;
		//Type of encoding
		String input_charset = AlipayConfig.input_charset;
		//key value for generating sign
		String key = AlipayConfig.key;
		//Type of sign
		String sign_type = AlipayConfig.sign_type;

		//LogSupport.debug("Payment gate way URL is :: " + paygateway);
		//LogSupport.debug("Encoding charset is :: " + input_charset);
		//LogSupport.debug("Key value ::" + key);
		//LogSupport.debug("Sign type is ::" + sign_type);

		Map<String, String> params = new HashMap<String, String>();
		//Putting required parameter for the trade query in to the map.
		params.put("service", AlipayConfig.tradequery);
		params.put("partner", AlipayConfig.partnerID);
		params.put("out_trade_no", pOrderNo);
		params.put("_input_charset", input_charset);

		//Generate the encrypt sign Using MD5 of required parameters 
		String sign = AlipayMd5Encrypt.md5(getContent(params, key));
		//LogSupport.debug("Sign is ::" + sign);

		StringBuffer queryURL = new StringBuffer();
		//Constructing the URL with required parameters along with sign and signtype.
		queryURL = queryURL.append(paygateway);

		List<String> keys = new ArrayList<String>(params.keySet());
		int size = keys.size();
		for (int i = 0; i < size; i++) {
			try {
				queryURL = queryURL.append(keys.get(i));
				queryURL = queryURL.append(AlipayConstant.EQUAL_SYMBL);
				queryURL = queryURL.append(URLEncoder.encode((String) params.get(keys.get(i)), input_charset));
				queryURL = queryURL.append(AlipayConstant.AMPERSAND_SYMBL);

				//LogSupport.debug("Parameter name is ::" + keys.get(i));
				//LogSupport.debug("Parameter value is ::" + params.get(keys.get(i)));
				//LogSupport.debug("Encoded Parameter value is ::"  + URLEncoder.encode((String) params.get(keys.get(i)), input_charset));

			} catch (UnsupportedEncodingException pUnsupportedEncodingException) {
				//LogSupport.error("Unsupported encoding Error occur in AlipayQueryProcessor createQueryURL ", pUnsupportedEncodingException);
			}
		}
		queryURL = queryURL.append(AlipayConstant.SIGN_EQUAL);
		queryURL = queryURL.append(sign);
		queryURL = queryURL.append(AlipayConstant.SIGNTYPE_SYMBOLS);
		queryURL = queryURL.append(sign_type);

		mTradeQueryURL = queryURL.toString();

		//LogSupport.debug("Trade Query URL is ::" + mTradeQueryURL);
		//LogSupport.debug("Exiting from AlipayQueryProcessor createQueryURL method");
		 */
	}
	

	/**
	 * 
	 * @param pParamsMap
	 * @return
	 */
	private String createServiceURL(Map<String, String>  pParamsMap){

		LogSupport.debug("Start AlipayServiceManager createServiceURL()");
		
		String l_sPaygateway = alipayConfig.getGatewayUrl();
		String l_sSign_type=alipayConfig.getSignType();
		String l_sKey = alipayConfig.getKey();
		String l_sInput_charset = alipayConfig.getInputCharSet();
		String maptoStr = AlipayUtil.getContent(pParamsMap, l_sKey);
		String l_sSign = AlipayMd5Encrypt.md5(maptoStr,l_sInput_charset);

		String serviceURL = l_sPaygateway;
		List<String> keys = new ArrayList<String>(pParamsMap.keySet());

		for (int i = 0; i < keys.size(); i++) {
			LogSupport.debug(keys.get(i));
			try {
				serviceURL = serviceURL + keys.get(i) + AlipayConstant.EQUAL_SYMBL
						+ URLEncoder.encode((String) pParamsMap.get(keys.get(i)), l_sInput_charset) + "&";
			} catch (UnsupportedEncodingException e) {

				LogSupport.error(e.getMessage());
				throw new ServiceRunTimeException("Error while creating payment URL for Alipay "+e.getMessage(),e);
			}
		}

		serviceURL = serviceURL + AlipayConstant.SIGN_EQUAL + l_sSign + AlipayConstant.SIGNTYPE_SYMBOLS + l_sSign_type;
		LogSupport.debug("ALIPAY Service URL created "+serviceURL);
		LogSupport.debug("End AlipayServiceManager createServiceURL()");
		return serviceURL;

	}
}
