package com.walmart.paymentgateway.message.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;

public abstract class AbstractMessageSender implements MessageSender {

	@Autowired 
	protected JmsTemplate jmsTemplate; 
	
	@Override
	public void sendQueue(Object targetObject) {
		sendMessage(targetObject);
	}
	
    public abstract void sendMessage(final Object targetObject);  

	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

}
