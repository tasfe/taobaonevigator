package com.walmart.paymentgateway.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



/**
 * The persistent class for the SRV_PROVIDER_PAY_TYPE_CODE database table.
 * 
 */
@Entity
@Table(name="SRV_PROVIDER_PAY_TYPE_CODE")
public class SrvProviderPayTypeCodeEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	public final static String BY_INT_PAY_CODE = "BY_INT_PAY_CODE";
	public final static String BY_NAME = "BY_NAME";
	public final static String BY_ID = "BY_ID";

	@Id
	@SequenceGenerator(name="SRV_PROVIDER_PAY_TYPE_CODE_PK_GENERATOR", sequenceName="SRV_PROVIDER_PAY_TYPE_CODE_SEQ" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SRV_PROVIDER_PAY_TYPE_CODE_PK_GENERATOR")
	@Column(name="SRV_PROVIDER_PAY_TYPE_CODE_PK")
	private Long srvProviderPayTypeCodePk;

	@Column(name="EXT_PAY_CODE")
	private String extPayCode;

	@Column(name="EXT_PAY_CODE_DESC")
	private String extPayCodeDesc;

	@Column(name="INT_PAY_CODE")
	private String intPayCode;

	@Column(name="INT_PAY_CODE_DESC")
	private String intPayCodeDesc;

	//bi-directional many-to-one association to SrvProviderPayTypeEntity
    @ManyToOne
	@JoinColumn(name="SRV_PROVIDER_PAY_TYPE_FK")
	private SrvProviderPayTypeEntity srvProviderPayType;

	//bi-directional many-to-one association to TransactionEntity
	@OneToMany(mappedBy="srvProviderPayTypeCode")
	private Set<TransactionEntity> transactions;

    public SrvProviderPayTypeCodeEntity() {
    }

	public long getSrvProviderPayTypeCodePk() {
		return this.srvProviderPayTypeCodePk;
	}

	public void setSrvProviderPayTypeCodePk(long srvProviderPayTypeCodePk) {
		this.srvProviderPayTypeCodePk = srvProviderPayTypeCodePk;
	}

	public String getExtPayCode() {
		return this.extPayCode;
	}

	public void setExtPayCode(String extPayCode) {
		this.extPayCode = extPayCode;
	}

	public String getExtPayCodeDesc() {
		return this.extPayCodeDesc;
	}

	public void setExtPayCodeDesc(String extPayCodeDesc) {
		this.extPayCodeDesc = extPayCodeDesc;
	}

	public String getIntPayCode() {
		return this.intPayCode;
	}

	public void setIntPayCode(String intPayCode) {
		this.intPayCode = intPayCode;
	}

	public String getIntPayCodeDesc() {
		return this.intPayCodeDesc;
	}

	public void setIntPayCodeDesc(String intPayCodeDesc) {
		this.intPayCodeDesc = intPayCodeDesc;
	}


	public SrvProviderPayTypeEntity getSrvProviderPayType() {
		return this.srvProviderPayType;
	}

	public void setSrvProviderPayType(SrvProviderPayTypeEntity srvProviderPayTypeEntity) {
		this.srvProviderPayType = srvProviderPayTypeEntity;
	}
	
	public Set<TransactionEntity> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<TransactionEntity> transactionEntities) {
		this.transactions = transactionEntities;
	}
	
}