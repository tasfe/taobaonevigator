var jsonObj = {};
jsonObj.Rows = [
    { id: 1, name: "林三", sex: "男", birthday: "1989/01/12",score:63.3 },
    { id: 2, name: "陈丽", sex: "女", birthday: "1989/01/12", score: 72.2 },
    { id: 3, name: "啊群", sex: "男", birthday: "1981/12/12", score: 43.4 },
    { id: 4, name: "表帮", sex: "男", birthday: "1983/01/12", score: 73.2 },
    { id: 5, name: "陈丽", sex: "女", birthday: "1989/01/12", score: 74.5 },
    { id: 6, name: "成钱", sex: "男", birthday: "1989/11/13", score: 73.3 },
    { id: 7, name: "都讯", sex: "女", birthday: "1989/04/2", score: 83.2 },
    { id: 8, name: "顾玩", sex: "男", birthday: "1999/05/5", score: 93.2 },
    { id: 9, name: "林会", sex: "男", birthday: "1969/02/2", score: 73.4 },
    { id: 10, name: "王开", sex: "男", birthday: "1989/01/2", score: 33.3 },
    { id: 11, name: "刘盈", sex: "女", birthday: "1989/04/2", score: 53.3 },
    { id: 12, name: "鄂韵", sex: "男", birthday: "1999/05/5", score: 43.5 },
    { id: 13, name: "林豪", sex: "男", birthday: "1969/02/21", score: 83.6 },
    { id: 14, name: "王开", sex: "男", birthday: "1989/01/2", score: 93.7 },
    { id: 15, name: "鄂酷", sex: "男", birthday: "1999/05/5", score: 61.1 },
    { id: 16, name: "林豪", sex: "男", birthday: "1969/02/21", score: 73.3 },
    { id: 17, name: "王开", sex: "男", birthday: "1989/01/2", score: 41.6 }
];